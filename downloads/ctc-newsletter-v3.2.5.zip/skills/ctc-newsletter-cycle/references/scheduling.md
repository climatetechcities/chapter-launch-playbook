# The weekly schedule: the run that starts itself

The lead should not have to remember to start the newsletter. With their one-time yes, Claude creates a scheduled task on their Claude account that starts the weekly run the day before the send day. The lead's week then begins with a notification and a review message already waiting.

Claude creates the task. The lead never builds an automation by hand.

## What gets scheduled, and what does not

| Part of the week | Scheduled? |
|---|---|
| Refreshing the opportunities when they are a month old | Yes. It happens inside the weekly run, before collection |
| Collecting the events and checking them | Yes |
| Proposing the cut, the picks and the opportunities, and sending the review message with the spreadsheet | Yes |
| The lead's reply to the review | No. It is their decision |
| Building the issue | Starts as soon as they reply |
| Rewriting the three blocks and sending | No. Theirs |

One task is enough. Do not create a separate monthly or quarterly task: the weekly run already does the monthly refresh when it is due and offers the quarterly one.

## When to offer it

- **At a chapter's first run**, as the third yes-or-no question in the one setup message (`references/first-run.md`).
- **When the chapter log says `Not asked`** (a chapter that started before this existed): one line in a review message, once.
- **Any time the lead asks**: "schedule this", "make it automatic", "can it start itself".

Never ask when the log says `No`. Record the answer: `chapter_log.py set schedule yes|no`.

## Creating the task

Do this once, after the chapter's first issue has been built, so the first scheduled run is never also a first run.

1. **Find the scheduling tool.** Sessions differ. Look for a tool that creates a scheduled task (search the session's tools for "schedule" or "trigger" if it is not already loaded). If the session can list existing scheduled tasks, list them first and do not create a second one for this city.
2. **Work out the time. One run a week.** The day before the send day in the settings file, early afternoon in the chapter's timezone, at a minute that is not on the hour or half hour (13:40, not 13:00). Use the chapter's IANA zone, never a guessed offset. Do not add extra runs to catch a computer that was off: if a run misses, the lead starts it themselves from the Scheduled section ("Run now") or by saying "run the newsletter". A chapter on every two weeks uses the same weekly schedule; in its off weeks the run sees from the chapter log that no issue is due and stops silently.
3. **Name it** `CTC newsletter: <City>`.
4. **It needs the lead's computer.** The collection reads Luma and Eventbrite through a browser on the lead's computer. Where the scheduling tool has a way to say a task needs the computer, say so. Create the task from a chat inside the chapter's project, so its runs can reach the chapter's files.
5. **Give it this prompt**, with the city filled in. Every run starts with no memory of any chat, so the prompt has to stand on its own:

   > Run this week's Climate Tech Cities newsletter for <City>, using the ctc-newsletter-cycle skill from the ctc-newsletter plugin. This is a scheduled run and nobody is watching it. Follow that skill's "Scheduled runs" section exactly (it points to references/scheduling.md): read the chapter's settings and log from the project, collect this week's events, send the review message with the events spreadsheet, then stop and wait for the chapter lead's reply. Do not build or send anything before they reply. If the chapter's files or a browser cannot be reached, do not collect; say in one short message what is missing and that the lead can open Claude and say "run the newsletter".

6. **Record it:** `chapter_log.py set schedule yes`, and save the log.
7. **Tell the lead, in a few lines:** what was created, when it runs, that they will get a notification with the review waiting, that their computer needs to be on with Claude open at that time so the event calendars can be read, and that if it ever misses (computer off, Claude closed) they can open the Scheduled section in Claude and press "Run now" on the task, or just say "run the newsletter". The tool reports whether the task's runs will go ahead without stopping for approval; pass that on in one sentence, and if runs will stop to ask, say they can switch the task to approve automatically in its settings.

**If the session has no scheduling tool**, say so plainly and give the lead the three things to enter themselves in Claude's Scheduled section: the name, the time, and the prompt above. Record `schedule no` only if they decline; otherwise leave it `Not asked` and offer again next week.

## Keeping it right

- **A task made by version 3.2.1** fires six times a week. When the lead says "update my newsletter schedule", or the first time a run sees this, change it to the single weekly time above.

- **The send day or cadence changes:** update the task to match, the same day the settings file changes. Rebuild the calendar (`scripts/schedule_calendar.py`) and hand over the new one.
- **The lead says stop:** pause or delete the task if the session can, otherwise tell them where to do it, and set `schedule no`.
- **Never create a second task** for the same city. If one exists and looks wrong, update it.

## What can go wrong

| Situation | What the scheduled run does |
|---|---|
| The lead's computer is off, or no browser can be reached | Does not collect; a list of event names with no dates is worse than no list. Sends one short message: the week could not be collected because the computer or browser was not reachable, and they can press "Run now" on the task in the Scheduled section, or say "run the newsletter", once they are at their computer |
| The lead already started this week's run by hand, or pressed "Run now" twice | The log or the saved events show this week is handled. Stops silently. No message |
| A chapter on every two weeks, in its off week | The log shows the last issue was sent less than two weeks before this send date. Stops silently |
| The chapter's files cannot be read | Same: one short message, no collection |
| The log's browser answer is not `Yes` | Same. A scheduled run never asks a question |
| Last week's review is still unanswered | Starts this week's run anyway and says in one line that last week's was never answered. Missed weeks are not chased |
| The lead already ran this week's issue by hand | The log shows an issue for this send date. Stops silently |
| The run stops to ask for approval | Nobody is there to give it. The lead sees it when they open Claude; tell them once how to switch the task to approve automatically |

## Scheduled runs: how an unattended run behaves

When the weekly schedule is set up (`references/scheduling.md`), the run starts by itself once a week, the day before the send day. Nobody is watching it. It does exactly what a run started by hand does up to the review. If it misses because the computer was off, the lead starts it again from the Scheduled section ("Run now") or by saying "run the newsletter". The differences from a run started by hand:

- **First, is this week already handled?** Work out the send date (the next send day on or after today). If the chapter log already has an issue for that date, or `CTC_Events_<City>_latest.json` in the project is for that send date (a review is already waiting, or the issue is built), stop silently: no message, no file. For a chapter on every two weeks, also stop silently when the log's last issue was sent less than two weeks before this send date.

- **It asks nothing.** Every standing answer comes from the settings file and the chapter log. If one it needs is missing, it does not guess and does not ask: it says what is missing in one short message and stops.
- **It checks three things before collecting:** the chapter's settings, source list and log can be read from the project; the log's browser answer is `Yes`; and a browser can actually be reached. If any of the three fails, it does not collect; a list of event names with no dates is worse than no list. It sends one short message: what was missing, and that the lead can press "Run now" on the task in the Scheduled section, or say "run the newsletter", once they are at their computer.
- **It never does a first run.** No settings file or no source list means a short message and a stop.
- **It stops at the review, always.** It sends the review message with the spreadsheet attached and waits. It never builds an issue, and nothing it does can send or publish anything.
- **If last week's review was never answered,** it starts this week anyway and says so in one line.

When the lead replies to the review, in that session or a new chat, the run carries on from Stage 2's "Reading the reply" as usual.
