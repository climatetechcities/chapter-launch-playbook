# Platform fallbacks

Read this only when the planner prints `PLATFORM READ LOOKS BROKEN`, the first-batch check in SKILL.md Step 3 fails, or no browser is available. A normal week never needs it.

## When a platform read looks broken

The helpers read Luma and Eventbrite from the pages' own structured data, and those pages change without notice. When they do, the failure is quiet: a calendar comes back `ok` with no events, or events come back with no dates. Two checks catch it early, the planner's `PLATFORM READ LOOKS BROKEN` line and the first-batch check in SKILL.md Step 3. When either fires:

1. **Look at one source by eye.** Open one registered calendar or organizer of that platform in the tab. If the page itself shows no upcoming events, the read was right and the week is quiet for that source; check a second one before believing it for the whole platform.
2. **If the page shows events the helper did not return, the page shape moved.** Do not run the remaining batches. Fall back, in this order:
   - the direct `__NEXT_DATA__` read shown under Luma above, one calendar at a time;
   - reading the rendered page: navigate to each calendar, read the page text for each event's name and link, then open each event page and read its date, time and address from what is on screen. Slower, and it is the same information;
   - for a source that will not read either way, ask the lead to open it and paste the page, and record the failure.
3. **Say so in the run report**, by platform: that the structured read failed, which fallback was used, and that the toolkit's helper needs updating. That last line is for the Climate Tech Cities team, and the lead should pass it on.

A fallback read fills the same rows under the same rules: every event's own page, no constructed links, `page_checks` on every record. Never ship a thin sheet without saying why it is thin.

## When the browser is not available

Tier 2 is the reliable path for Luma and Eventbrite, so a lead with no browser Claude can drive (the Claude in Chrome extension, or the desktop app's built-in browser) is not running a degraded harvest, they are running a broken one. Say so rather than producing a sheet full of blanks.

The submission form is the exception: an Airtable tool or connector reads it without any browser at all. Where the session has one, that source keeps working and only the calendar sources are affected.

Three honest options, in order:

1. **Install the Claude in Chrome extension, or run the newsletter from the Claude desktop app, which has a browser built in.** It fixes every week from now on. This is the answer for anyone planning to keep sending.
2. **Paste per source.** The lead opens each Luma calendar and pastes the page. Workable for a source list of five, miserable at twenty.
3. **Harvest the server-rendered sources only** and say plainly which sources were skipped and roughly what share of a normal week they represent. A thin issue with a known cause is recoverable. A thin issue with an unknown cause is what makes a lead quit.

Never pick option 3 silently.
