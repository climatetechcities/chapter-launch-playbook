---
name: ctc-source-map
description: Build the event source list for a Climate Tech Cities chapter in a given city, either from calendar links the user already has, from online research, or both. Finds the Luma calendars, Eventbrite organizers, university calendars, and local organizations that consistently post climate tech events there, verifies every one before registering it, and adds the CTC event submission form as a standing source. Use this skill whenever the user names a city and wants event sources, has their own list of calendars they want registered, asks to build or refresh a source map or source list, asks "where should we pull events from" or "what climate calendars exist in [city]", is launching a newsletter for a new chapter, or says the weekly harvest keeps missing events. Always use this skill even if the user only names one city or asks for "just a few calendars to start". Do NOT use it to collect this week's events, which is the harvest skill's job.
---

# CTC Source Map

Research a city and return a verified list of the places its climate events get announced. The weekly harvest reads that list, so every future issue is only as good as this file.

## Find your files first

Every path in this skill (`scripts/...`, `references/...`, `../ctc-<other skill>/...`) is relative to **this skill's own folder inside the installed plugin**, not to the working directory. Locate it before anything else, once per session:

```bash
find / -xdev -type d -path "*/ctc-newsletter*/skills/ctc-source-map" -not -path "*/.trash/*" 2>/dev/null | head -1
```

Call the result `$SKILL`. The plugin's other skills are its siblings (`$SKILL/../ctc-assemble`, `$SKILL/../ctc-harvest`, and so on). Run scripts as `python3 $SKILL/scripts/<name>.py` and read references as `$SKILL/references/<name>.md`. If the search returns nothing, the plugin's files did not install; say so and stop, rather than rebuilding any script by hand or inventing a URL the files were supposed to carry.

## What you will get back

One text file, `CTC_Source_List_<City>.md`, which Claude saves to the lead's project: one table, one row per source, eleven columns. A three-row excerpt:

| Source Name | URL | Platform | Method | Tier | Category | Cadence | Last Event | Confidence | Origin | Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| CTC event submissions (all chapters) | (shared view) | airtable | auto | core | submissions | continuous | 2026-08-04 | verified | ctc | Standing row in every source list. Never delete. |
| Cascadia Cleantech Alliance | https://www.eventbrite.com/o/... | eventbrite | auto | core | eventbrite | weekly in term time | 2026-08-06 | verified | research | Largest single source by volume. Organizer page, not an event page. |
| Portland Art Museum | https://example.org/pam/calendar | web | manual | occasional | arts | 4 to 6 climate items a year | 2026-05-14 | verified | research | Whole-museum calendar. A human picks out the climate programming. |

The build script names any missing required field and any unverified row. The chat summary gives the count per category including the empty ones, what was rejected and why, and what a local should check. A full sample is `references/sample-output/CTC_Source_List_SAMPLE.md`. A lead who wants a spreadsheet gets one on request (`--xlsx`: teal header band, unverified rows shaded, gaps in red); a sample of that is `CTC_Source_Registry_SAMPLE.xlsx` beside it, and `references/example-registry.csv` is the same data as text.

## What this is for

Two readers, wanting different things.

**A machine reads it every week.** `ctc-harvest` walks the rows and fetches each one. That is why `url`, `platform`, and `method` have to be accurate rather than optimistic: an overclaimed `auto` source fails silently in the weekly sweep, the issue comes out thin, and nobody works out why.

**A person reads it about four times a year.** The chapter lead, on the quarterly refresh, deciding what died and what to add. That is why `cadence`, `last_event`, `origin`, and `notes` exist.

The list is finished when someone who lives in that city and works in climate could read it without naming an obvious omission. **Prefer 25 verified sources to 60 guesses.** A missing source is invisible; a bad source silently pollutes every future issue.

Do not use the words config, registry, schema, or pipeline with the lead. Say source list, spreadsheet, and the weekly cycle.

One machine-read token is the only exception, and it is never spoken aloud: the `Source` value `registry` on an event row, which `build_sheet.py` validates. Everything the lead reads says source list, including the Notes text inside the file. (A chapter set up before version 3 has `CTC_Source_Registry_<City>.xlsx` in its project instead; it is read the same way and replaced by the text file at the next refresh.)

## Input

A city name. Optionally, calendar links the lead already has (Step 0). The scope rule, from section 2 of the chapter settings file; if there is no settings file, establish it in Step 1. On a refresh, the current source list, read from the project as `../ctc-newsletter-cycle/references/chapter-files.md` describes.

## What this is and is not

**A once-per-city research job, rerun every three months.** It finds which calendars exist. `ctc-harvest` pulls this week's events from them.

Never use open web search to collect a week's events. Search offers no completeness guarantee and returns different results week to week. A registered calendar returns everything on it, every time. That difference is the reason this list exists.

Do not tell the lead how long anything will take. Say what is happening and what comes next.

## Exclusions

**Never register Climate Tech Cities' own properties as event sources.** The list is where other people announce events:

- `climatetechcities.com` and every chapter subdomain
- Any chapter's Substack, including this one. Registering the chapter's own newsletter would re-harvest last week's listings forever
- Other chapters' newsletters
- Typeform, Google Docs, Drive, and social links

**The one CTC property that is always registered** is the event submission form's shared view, as the standing `submissions` row (see Step 5). It is an intake readers use to send the chapter events, which is the opposite of the circular case above.

**Do not assume a calendar belongs to CTC because its name resembles a chapter's.** A Luma calendar named "Seattle Climate Tech" was once excluded as the chapter's own; it was run by Work on Climate, My Climate Journey, and Climate Changemakers. Check who runs it. Excluding a real source is a permanent, invisible loss.

**CTC partner organizations are external sources.** My Climate Journey, Women and Climate, Climatebase, SOSV, Climate Draft, Newlab, and ClimateRaise run their own events. Register them normally where they have local programming.

## Read this first

- `references/search-playbook.md`: concrete queries for all nine categories, the verification checks, and the coverage check to run before finishing. The most common failure of this skill is running two searches and stopping.
- `references/example-registry.csv`: a valid source list for a fictional chapter, trimmed to 15 rows so it can be read in one pass. It covers all nine categories, all three tiers, all three pull methods, one `unverified` row, and the standing submissions row. A live one runs 25 to 30 external sources, so the script will warn on this file's count; that is expected for the example and not for a real city.
- `references/verifier.md`: the second-pass check run on the finished file before it is saved.
- `../ctc-newsletter-cycle/references/chapter-files.md`: how to read and save chapter files and use the chapter log.

## Environment

Web search and page fetching are required. A browser Claude can drive (the Claude in Chrome extension, or the desktop app's built-in browser) is needed to verify Luma and Eventbrite pages, which return an empty shell to a plain fetch; a page that would not load has not been verified. The chapter log holds the lead's standing answer on using their browser; follow it, and ask once if it says `Not asked`. `openpyxl` is needed only when the lead asks for a spreadsheet.

The sandbox restricts outbound access from `bash` to a package-manager allowlist, so `curl` fails on event sites that are healthy. Use the fetch tool or the browser, and never record a source as dead because a shell command could not reach it.

## Step 0. Ask for the lead's own sources first

Before any searching, ask whether they already have calendar links. A lead usually knows five or ten off the top of their head, and those are the highest-quality rows because a real person already vouched for them.

Present all three options in full, every time, in plain language:

> Before I start, do you already have event calendars you want in the source list? Luma calendars, Eventbrite organizer pages, university calendars, anything you already check by hand.
>
> Either way works:
>
> **A. Paste your links, then I research too.** I verify yours, follow their cross-links, and work the full nine-category search on top. Best coverage. This is what I'd recommend for a new chapter.
>
> **B. Paste your links only.** I verify what you give me and stop there. Fastest, and a good choice if you already know your city's scene and just want the file built.
>
> **C. I research from scratch.** No links needed. I go find them and bring back a verified list for you to review.
>
> Paste your links, or just say which option you want.

Then follow the choice. **A:** take the links into Step 1, verify them in Step 3, run the full Step 2 research pass, and use their Luma calendars as cross-link seeds. **B:** verify their links, skip Step 2, and produce the file from those alone, saying plainly what the count and category coverage came to; offer the research pass as a later step and do not run it uninvited. **C:** straight to Step 1 and the full research pass.

**Skip the question whenever the answer is already in front of you**, which is most of the time: `ctc-newsletter-cycle` asked for calendars at the chapter's first run (links pasted there are option A; "go" is option C), the lead opened with links, or the lead said "just research it". Confirm the read in one line and get on with it. On a refresh started by the weekly run, do not ask at all: re-verify what is registered, research on top, and take any links the lead mentions.

**A user-supplied link is a candidate, not a registered source.** It goes through all five gates in Step 3. When one fails, say which gate and why rather than dropping it silently, and register it `unverified` with a note if it is worth keeping.

## Step 1. Scope the city

Establish and write down before searching:

- **Geographic boundary.** From the settings file, or ask. New York's stated rule is roughly 95% the city proper, but its published issues carry Jersey City and Hoboken, so the working rule is closer to "anywhere a subscriber would travel on a weeknight."
- **Neighboring place names** that count as local. These become search terms.

## Step 2. Research the nine categories

Skip this step only under option B.

Run it as extended research, not ordinary searching: many searches, following leads between them, cross-referencing. Work every category, every time, and **report the empty ones**. An empty category is a finding, not a gap to hide.

**Split the search, keep the gates central.** Where the session has a subagent tool, run the nine categories as three parallel subagents, three categories each (1 to 3, 4 to 6, 7 to 9), each given the scope from Step 1, the queries for its categories from `references/search-playbook.md`, and the lead's links sorted into its categories. Each returns candidates only: name, URL, platform guess, what it saw, and the cross-links it noticed, including Luma calendars it found that belong to another subagent's category. Searching and plain fetching have no shared state, so this is safe. **No subagent registers anything and no subagent opens the browser.** The five gates in Step 3 run afterward, in one place, so every candidate is judged the same way and the Luma and Eventbrite checks go through one tab. Without a subagent tool, work the nine categories in order as before.

1. **Luma calendars.** Structured, machine-readable, complete. Highest yield. Three entry points in order: Luma's discovery pages (`luma.com/{city}`, `luma.com/climate`, used to find calendars and never as sources themselves), keyword search (`site:lu.ma`, `site:luma.com` with the city plus climate, energy, sustainability, cleantech), and cross-links, which routinely yield four more calendars from one.
2. **Eventbrite organizers.** The largest single source by volume in mature chapters. Search organizer pages, not individual events.
3. **Universities and research centers.** Several separate calendars per university is normal: sustainability office, engineering school, business school entrepreneurship center, energy or environment institute. Include large public systems.
4. **Incubators, accelerators, coworking spaces.** Climate-focused first, general tech second.
5. **City government and utilities.** Sustainability offices, economic development corporations, energy authorities, utility program pages.
6. **Professional and affinity groups.** Young professionals in energy, women in renewables, LGBTQ+ climate networks, engineering societies, green building councils. Reliably recurring and easy to miss.
7. **Adjacent newsletters and meetups**, including ones that compete. Reading the competition is the cheapest completeness check available.
8. **Climate community organizations with local presence**, including CTC's partner organizations where they run local programming.
9. **Arts, culture, civic venues.** Museums, galleries, botanical gardens, libraries, parks organizations. A tech-focused search never surfaces these, and roughly 40% of CTC's audience is not yet working in climate.

If the lead supplied links in Step 0, sort them into the nine categories first. Leads tend to know the Luma and meetup scene well and the government, university, and arts categories barely at all; that tells you where to spend the search effort.

### How many sources, one rule

**The target for a new chapter is 25 to 30 verified external sources, weighted toward `core`. The sweep is finished when all nine categories have been worked and every cross-link followed, not when a number is reached.**

Reaching the target from scratch is roughly 30 to 50 searches plus a page open for every candidate that survives. A first pass that returns a dozen candidates has finished category one, not the job. If, after all nine categories and the cross-links, the count is below 25, deliver the file, report the count and the empty categories, and let the lead decide whether to add sources they know about. Under option B the count will often land below the target on its own; report it, name the empty categories, and offer the research pass. **Never pad.** Every source still passes all five gates, and one bad source pollutes every issue from now on.

The 25 to 30 figure is a working default carried in the CTC playbook, not a measured standard. Whether a city's event volume supports a weekly issue is decided in `ctc-newsletter-cycle` after the first harvests, not here.

## Step 3. Verification gates

Open every candidate and check all five. A source failing any gate does not go in as `auto`. This applies to user-supplied links too, with no softening.

Open the Luma and Eventbrite candidates in batches rather than one at a time: one tab on luma.com, inject `../ctc-harvest/scripts/harvest_helpers.js`, `__ENUM_LUMA([...every Luma candidate...])`; one tab on eventbrite.com, `__ENUM_EB([...every organizer candidate...])`. Each record comes back with whether the page loaded, how many events it lists and their dates, which is Gates 1 to 3 in one read. Read the result the way `../ctc-harvest/references/platform-notes.md` describes. Gate 4 still needs you to look at what the events are, and a candidate whose record came back `ok: false` **or with zero items** is opened in the tab by eye before any gate ruling: the batch read lists upcoming events only, so a calendar with recent past events and nothing scheduled this week looks empty as data and is alive by Gate 2. Web candidates are plain fetches and can be checked in parallel subagents; the gate rulings are still made here.

**Gate 1. It loads.** Never register a page you could not open. Behind a login: record it `unverified` with a note.

**Gate 2. It is active.** At least one event in the last 90 days. A calendar whose most recent event is from 2023 is dead. The exception is a term-time source checked in July, which is a season; check whether it was active the previous spring.

**Gate 3. It is consistent.** Look at past events, not just upcoming. A repeating pattern: a monthly meetup, a weekly series, a seasonal program. Four events in three years is a `manual` check at best. Record the observed cadence.

**Gate 4. It is reputable and relevant.** A real named organization, events that actually happen, climate-adjacent rather than one green-themed event a year. The recurring cases:

| Situation | Ruling |
|---|---|
| Reseller running generic "ESG & Sustainability Strategy: 1 Day Training" listings across dozens of cities | Reject. Syndicated spam that recurs in every issue forever |
| Museum or library whose calendar is 95% non-climate but carries four or five climate events a year | Register as `occasional` and `manual` |
| A competing local climate newsletter | Register as `occasional`, method `email`. A completeness check, not a feed |
| National organization with a genuine local chapter running local events | Register the local chapter page |
| National organization with a local landing page and no local events | Reject |
| A single recurring event with its own page, no organizer page | Register the event page, `occasional`, note why |
| An organization whose calendar is entirely webinars | Register as `secondary` |
| Calendar named like a CTC chapter, run by someone else | Register it normally |
| Corporate marketing calendar with one greenwashed event a year | Reject |

The principle: would a subscriber be glad this event reached them, and does this URL produce such events on a repeating pattern? Both halves have to be true.

**Gate 5. Stable URL.** An organizer or calendar page, not a filtered search result. Will it work in six months?

## Step 4. Tier and classify

**Tier** by expected weekly contribution: `core` (several events most weeks), `secondary` (a few a month), `occasional` (worth checking, rarely fires).

**Method**, accurately rather than optimistically: `auto` (structured and machine-readable: Luma, Eventbrite organizer pages, server-rendered listing pages, the submissions view), `manual` (a human checks it: JavaScript-rendered calendars, PDF listings, events announced in prose, whole-venue calendars), `email` (arrives in the lead's inbox from a named contact; record the contact). When unsure, mark `manual`.

## Step 5. Add the standing submissions row

Every registry carries one row that is the same for every chapter: the CTC event submission form's shared view. Readers of any chapter's newsletter submit events through one form with a city dropdown; the harvest reads this chapter's rows from the shared view each week. Write the row exactly as in `references/example-registry.csv`: `platform = airtable`, `method = auto`, `tier = core`, `category = submissions`, `origin = ctc`, and the URL from `../ctc-assemble/references/ctc-links.md`. The build script writes nothing and exits with an error when the row is missing. It does not count toward the 25 to 30 target and it is never deleted on a refresh.

## Output

Write the file with the bundled script, never by hand:

```bash
python3 $SKILL/scripts/build_registry.py sources.json --md CTC_Source_List_<City>.md \
    --xlsx "<outputs folder>/CTC_Source_List_<City>.xlsx"
```

The text file is what Claude keeps in the project. The spreadsheet is the copy the lead reads; build both every time (unless the chapter log says the lead does not want spreadsheets).

`sources.json` is `{"city": "...", "sources": [ ... ]}` with one object per source keyed by the column names in the example file. The script exists so the columns come out identical every time for `ctc-harvest`, and its report names every source missing a required field, every unverified row, the count per category including the empty ones, and the external count against the target. It warns (and still writes the file) under 25 external sources or over about 35; it writes nothing and exits with an error only when the submissions row is missing. Read the output before going on. Fix every named gap and re-run; a file with a gap in it is not saved.

| Column | Contents |
|---|---|
| `name` | Organization or calendar name |
| `url` | Stable page URL |
| `platform` | `luma` / `eventbrite` / `web` / `email` / `airtable` |
| `method` | `auto` / `manual` / `email`. For `email`, the named contact goes in `notes` |
| `tier` | `core` / `secondary` / `occasional` |
| `category` | `luma` / `eventbrite` / `university` / `incubator` / `government` / `professional` / `adjacent` / `climate org` / `arts` (the nine, in Step 2 order), or `submissions` |
| `cadence` | Observed: "monthly meetup", "weekly", "continuous" |
| `last_event` | Date of the most recent event seen |
| `confidence` | `verified` / `unverified` |
| `origin` | `user` / `research` / `ctc` |
| `notes` | Who runs it, why it is `manual`, term-time only, what makes it worth the slot. "Good calendar" is not a note |

`origin` earns its place on the quarterly refresh: a `user` row that has gone quiet is worth asking the lead about before deleting; a `research` row that has gone quiet can just go; a `ctc` row is never deleted.

### Verify, show it, then save it

Run `references/verifier.md` on the built file: a fresh, adversarial pass that re-opens every row, checks that every `auto` claim is honest, reverses any exclusion made on a name match, and confirms the standing submissions row. That file says how to run it as a subagent where the session has one and as a separate step where it does not. Fix `sources.json` and re-run the build script.

**Show it, then save it.** The source list does not go into the project until the lead has read it. A person who lives in the city is the only check on what the research missed, and that check comes first.

1. **Hand over the spreadsheet** and give the summary in chat: how many sources came from the lead versus research; any user-supplied link that failed a gate, with the gate named; total verified sources by method and tier; count per category including the empty ones; candidates rejected and why; which sources will carry the most volume; what a local person should check. The verifier's findings are one paragraph of it.
2. **Ask, and wait:**

   > That is your source list, [N] sources across [M] categories, plus the Climate Tech Cities submission form. Read it before I save it. You live there and the research does not, so tell me what to add and what to drop: the meetup everyone goes to that is not here, a calendar that looks dead to you. If it looks right, say so.

3. **Apply what they say.** A source they add is a candidate: verify it through the same gates and name any gate it fails. A source they drop is dropped, no argument. If they marked up the spreadsheet and sent it back, read it in with `chapter_files.py sources-import`. Rebuild, and show them what changed in a line or two. One round is normal; do not loop asking "anything else".
4. **Save, once they say it looks right.** Save `CTC_Source_List_<City>.md` to the project, set the date in the log, and save the log (`chapter-files.md`):

   ```bash
   python3 $SKILL/../ctc-newsletter-cycle/scripts/chapter_log.py set CTC_Chapter_Log_<City>.md sources-built <today>
   ```

   Tell them in one line that it is saved, and hand over the final spreadsheet if it changed.

At a chapter's first run, `ctc-newsletter-cycle` gives the prompt in step 2 itself, together with the opportunities; do not ask twice. The rule is the same either way: nothing is saved, and no harvest runs, before the lead has answered.

## Refresh

Rerun every three months. The weekly run offers it when the chapter log shows the list is that old. Sources die quietly and nobody notices until the newsletter has been thin for two months.

Start from the current list rather than from nothing:

```bash
python3 $SKILL/../ctc-newsletter-cycle/scripts/chapter_files.py sources-import <the current list> sources.json
```

An older spreadsheet does not carry the city; set `"city"` in `sources.json` before rebuilding, or the build stops and says so.

The lead has been reading the scene for three months and will have picked up calendars the last pass missed; take any they mention. **Re-verify existing rows before hunting for new ones.** A dead core source costs more than a missing new one. Report both what died and what is new. Keep the submissions row.

## Failure modes

**Two searches and a stop.** The single most common failure. A list built from one category looks finished and the gaps are invisible forever after.

**Excluding a real source on a name match.** Check who runs a calendar before excluding it.

**Registering an individual event page as a source.** It fires once and returns nothing forever. Register the organizer.

**Optimistic `auto` classification.** A JavaScript calendar recorded as `auto` returns nothing in the weekly harvest without erroring. Mark `manual` when unsure.

**Syndicated training spam accepted.** If the same title appears in three cities, it is a reseller.

**Arts, government, and utility categories skipped.** The least glamorous searches and among the most reliable sources.

**Forgetting the submissions row.** The script catches it, but a source list without it means reader submissions never reach the issue and nobody knows why.

**Reporting only what was found.** The empty categories, the rejections, and the unverifiable candidates are half the value of the summary.
