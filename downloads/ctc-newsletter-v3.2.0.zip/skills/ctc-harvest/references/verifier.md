# Harvest verifier

A second, adversarial pass over the checked rows before the lead sees them in the review. It covers what `build_sheet.py --check-only` cannot: whether a row belongs to this city and this window, whether two rows are one event, whether the times are in the right zone, and whether the descriptions say only what the page said.

**What is not here, and where it went.** Re-fetching every registration link and comparing it field by field is `ctc-assemble`'s job now ("Re-check every link that ships" in its SKILL.md and Part 2 of its verifier). It runs on the rows the lead kept, immediately before the issue is built. Every link that ships is still fetched twice; the second fetch is later and on fewer rows. Do not repeat it here, and do not skip it there.

## How to run it

Run this as a fresh pass with no memory of the sweep. If the session has a subagent or task tool, launch one with exactly this file, `events.json`, `events_raw.json` (for `landed_url`, `page_checks` and the page's own description text), `plan.json` (for the probable duplicates and the dropped list), and the scope rule. Nothing from the sweep's conversation. If the session has no subagent tool, run it yourself as a separate step: read this file first, open `events.json` cold, and work every row as though someone else harvested it. Fix `events.json`, re-run `build_sheet.py --check-only`, and only then go to the review.

Do every row, `upcoming` included.

## Pages opened in the tab, by eye

These are the only browser opens in this pass. One agent, one tab, paced, exactly as in the sweep.

- **Three Luma rows and three Eventbrite rows chosen at random**, read for the rendered local start time. The sweep converts times in code, and a zone or daylight-saving error is invisible in the data (check 8). Fewer than three of a platform: all of them.
- **Every `Source = submitted` row.** A submitted link is no more trusted than a scraped one.
- **Every row the check script warned about**, and every row with a `page_checks` value that is false or missing.
- **Every off-platform row whose page returned no structured date** (no JSON-LD start date). These are where a wrong row hides.

## Checks, per row

1. **The link is an event page**, not a calendar, a homepage, or a listing index (`/events`, `/calendar`, `/upcoming`, `/whats-on`). The script flags the obvious ones; catch the rest by eye. The `Registration Link` equals the row's `landed_url`.
2. **Start Time, Location, Access, Host** are filled or carry a resolved-unknown value. A row with two or more of these blank was written from a listing page and needs the page opened.
3. **Scope.** The event's own location is inside the scope rule. Multi-city calendars and the submission form both let out-of-town events through. A row outside the rule is not deleted here; it stays, and the review proposes cutting it with that reason.
4. **Block.** `this_week` rows fall inside the this-week window, `upcoming` rows after it. A row on the wrong side of the boundary lands in the wrong listing.
5. **Description.** Present on every `this_week` row and empty on `upcoming` rows. Two to three sentences, 40 to 70 words, from the page, in the shape `../../ctc-assemble/references/voice.md` section 6 sets. No banned phrases from voice.md section 5, no invented speaker, venue, or price, no why-go sentence. Compare each against the page's own text in `events_raw.json`: nothing in the description that is not in the source. This column is printed in the issue.
6. **Categories** are one to three from the controlled list, and fit the event.
7. **Submitted rows.** There is a `Source = submitted` row for every submission in the shared view for this city and these windows. None were dropped. Where the form and the page disagreed, the page won and the report says so.

## Checks, whole list

8. **Times.** The six rows read by eye match their cells. If one is off by hours, every row from that platform is off (UTC not converted, or the wrong zone); fix all of them.
9. **Duplicates.** Same date plus similar name plus same venue is one event. The planner's `probable_duplicates` list names the pairs it could not settle; each has a ruling in the report. Merge per the dedupe table in SKILL.md, keeping the organizer's link. A pair you cannot settle stays as two rows, and the review says so.
10. **Completeness.** The check script reports every row has every field it needs, or each exception is named in the report with what the page showed.
11. **Count.** The total against the chapter's normal (the chapter log has the last three issues), and the zero-return sources named. Three of the planner's dropped-as-out-of-window candidates are spot-checked, to confirm their listing dates really were outside the window.

## What to report

Rows fixed (by name, with the check number), duplicates merged, which rows were opened in the tab and why, any row outside the scope rule or with an unsettled duplicate (for the review's proposal), and a one-line verdict: ready for the review, or not.
