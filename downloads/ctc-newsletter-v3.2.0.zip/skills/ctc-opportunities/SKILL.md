---
name: ctc-opportunities
description: Find grants, fellowships, accelerators, and calls for applications for a Climate Tech Cities chapter newsletter, and keep them in a rolling list that is refreshed monthly. Use this skill whenever the user wants opportunities for their newsletter, asks for grants, fellowships, accelerators, incubators, funding, or calls for applications, says "run the monthly opportunities" or "refresh the opportunities", asks what to put in the opportunities block, or is starting a new month of the newsletter cycle. Always use it even if they only want one or two to fill a gap. Do NOT use it to find events, which is ctc-harvest, or to find partner organizations, which is the ctc-partner-map plugin.
---

# CTC Opportunities

Runs once a month, started by `ctc-newsletter-cycle` when the list is a month old. Finds grants, fellowships, accelerators, and open calls, and keeps them in a rolling list (the queue) the newsletter draws on every week. With the lead, call it "your opportunities list".

The opportunities block is why founders stay subscribed through a quiet week. It is also the block that gets skipped, because nothing collects it. This is what collects it.

## Find your files first

Every path in this skill (`scripts/...`, `references/...`, `../ctc-<other skill>/...`) is relative to **this skill's own folder inside the installed plugin**, not to the working directory. Locate it before anything else, once per session:

```bash
find / -xdev -type d -path "*/ctc-newsletter*/skills/ctc-opportunities" -not -path "*/.trash/*" 2>/dev/null | head -1
```

Call the result `$SKILL`. The plugin's other skills are its siblings (`$SKILL/../ctc-assemble`, `$SKILL/../ctc-harvest`, and so on). Run scripts as `python3 $SKILL/scripts/<name>.py` and read references as `$SKILL/references/<name>.md`. If the search returns nothing, the plugin's files did not install; say so and stop, rather than rebuilding any script by hand or inventing a URL the files were supposed to carry.

## What you will get back

One text file, `CTC_Opportunities_<City>.md`, which Claude saves to the lead's project: an `Open` table, most local entries first, and a `Closed` table once anything has closed. Eight columns: `Opportunity`, `Organization`, `Type`, `Deadline`, `Who it is for`, `Scope`, `Description`, `URL`. A three-row excerpt of Open (columns cut for width):

| Opportunity | Organization | Type | Deadline | Who it is for | Scope | Description |
|---|---|---|---|---|---|---|
| Oregon BEST Early Commercialization Grant | Oregon BEST | Grant | 2026-09-15 | Hardware startups with an Oregon presence | Oregon | Non-dilutive grants for moving from prototype to pilot, with a university lab match for testing. |
| Activate Fellowship | Activate | Fellowship | 2026-10-15 | Scientists founding a hardware company | National | Two-year fellowship with a salary, lab access, and a cohort, for scientists leaving research to start a company. |
| Elemental Impact | Elemental Impact | Accelerator | Rolling | Climate startups at first deployment | National | Project funding and deployment support for first-of-a-kind climate projects. |

The list records what is open. **How soon each one closes, and which ones already ran in an issue, are worked out fresh every week** by `scripts/read_queue.py`, from the send date and the chapter log, so neither is stored here to go stale and the lead keeps no tally. The chat summary says how many are open, how many are new this month, and what closes soon. A full sample is `references/sample-output/CTC_Opportunities_SAMPLE.md`. A lead who wants a spreadsheet gets one on request (`--xlsx`); a sample of that is `Opportunities_SAMPLE.xlsx` beside it.

## Input

The city, read from the chapter settings file. The current list, `CTC_Opportunities_<City>.md` (or an older chapter's `Opportunities_<City>.xlsx`), read from the project as `../ctc-newsletter-cycle/references/chapter-files.md` describes. The lead uploads nothing. The chapter log's standing answer on LinkedIn.

## Output

`CTC_Opportunities_<City>.md`, saved to the project by Claude, replacing the previous one, and the log's `opportunities-refreshed` date set to today. `ctc-assemble` reads the list every week from there. If the session cannot write to the project, hand the file over the way `chapter-files.md` says.

Do not tell the lead how long a run will take.

---

## The bar

The lead opens the file, picks two, and pastes them into the issue without checking anything. Which means every deadline in it has to be right.

---

## Read this first

`references/sources.md` holds the four source tiers, the scope rule, what qualifies, and the four verification checks. Read it before searching.

`../ctc-assemble/references/voice.md`, section 6 "Opportunity descriptions", is how the description column is written. It is the plugin's one copy of the voice file.

`references/verifier.md` is the second-pass check run on the finished file before it is handed over.

`scripts/build_queue.py` builds and prunes the list. Do not hand-roll the file, and never rebuild the list from scratch when a previous one exists. `scripts/read_queue.py` is the weekly read that `ctc-newsletter-cycle` runs.

`../ctc-newsletter-cycle/references/chapter-files.md` says how to read and save chapter files and how to use the chapter log.

---

## Step 0. Start from what the lead already gave

**No menu.** The default is to research every tier and add anything the lead named on top. Work out which case this is from what is in front of you, and ask nothing you do not have to.

| What the lead has given | What to do |
|---|---|
| Programs or links, pasted here or at the chapter's first run | Verify each one, then run the full search on top |
| "Just use mine", or anything that plainly means it | Verify what they gave and stop there. Do not quietly run the research pass anyway; say what the count and mix came to |
| Nothing, or "go" | Run the full search |

A name a real person vouched for is better than anything research returns. **Whatever they give is a candidate, not an entry.** It goes through the same verification as anything found by research. When one fails a check, name the check it failed rather than dropping it silently, and let them decide whether to keep it anyway.

**The LinkedIn pass has a standing answer.** Tier 3 reads what the lead's own LinkedIn network has posted about open programs, in their signed-in browser, so it only ever runs with their explicit yes. That yes is asked for once and kept in the chapter log:

- `Yes`: run the tier, and say in one line that you are.
- `No`: skip it, and say in one line that it was skipped at their request.
- `Not asked`: ask once, in one message, and wait: say what the tier is, that it uses their signed-in browser, and what it usually adds. Record the answer with `chapter_log.py set linkedin yes|no`.

**Never decide for the lead and never skip the tier without saying so.** If no browser is available in the session, say so plainly and note the tier was skipped for that reason; that does not change their standing answer.

## Step 1. Read the current list

Read `CTC_Opportunities_<City>.md` from the project into the working folder. That path is what `--existing` takes in Step 4.

**With a current list this run is short.** Most entries carry over untouched, a few close, and you are looking for what is new since last month.

**Without one**, this is the first run and the sweep starts from nothing. Say so, so the lead is not surprised.

Never rebuild from scratch when a list exists. Carrying it forward is what keeps the Closed table's history, keeps every entry a person once vetted, and keeps the run short.

## Step 2. Sweep the four tiers

**The queue holds at least fifteen open opportunities after every run.** That is the total in the Open table, carried entries included, not the number found this month. Under fifteen means a tier was skipped, and the script reports the queue as not ready. Keep working the tiers until the total clears it.

**Tier 1 alone should produce most of that**, and most of it runs rolling intake, which counts (`references/sources.md` lists the programs and says how `Rolling` is recorded). Excluding rolling programs is what produces a queue of five fellowships.

**A queue of one type is a failed sweep.** Five fellowships and nothing else is not a month with no accelerators open, it is a search that stopped at the first source type. Accelerators, grants, competitions, and calls for proposals all exist in every month of the year at national level. The script reports the queue as not ready when any single type exceeds half of it, or when Accelerator, Grant, or Fellowship is entirely absent.

**Scope mix is the other check.** A healthy queue leads with local and regional programs and carries national and global ones below them. All four tiers contribute, and the file is sorted so the most exclusive opportunities are the first thing the lead sees.

Work the four tiers in `references/sources.md`. Tiers 1, 2 and 4 are plain fetches with no shared state: where the session has a subagent tool, run them as three parallel subagents, each given `references/sources.md`, the city and scope, and (for Tier 4) the partner map workbook, each returning candidates with the program's own URL, the deadline as the page states it, eligibility, and type. Tier 3 is the lead's signed-in browser and runs after them, alone, from one tab. Without a subagent tool, work the tiers in order. **The four checks in Step 3 run centrally on everything that comes back**, so a candidate from an aggregator and the same candidate from a program page are judged once, against the program page.

1. **Program pages and public funders.** The backbone. No browser needed.
2. **Aggregators.** Highest yield per fetch. Always confirm the deadline on the program's own page, because aggregators leave dead listings up.
3. **LinkedIn.** Browser only, and only with the lead's standing yes (Step 0). A lead who said no, or a session with no browser, makes skipping this tier a good run, not a broken one; a tier skipped when the answer was never asked for is a broken run. If no browser is available, say so and say what the tier usually contributes. Never run this tier from a subagent; it is the lead's own browser.
4. **Local, from the partner map.** If a `CTC_Partner_Map` or `CTC_City_Resources` workbook exists, read it and check each organization's programs page rather than researching the city again. This tier produces the entries no other newsletter in the city has.

**Set the `scope` field precisely, because it decides the order of the file.** The values, the radius (wider than the events scope rule, on purpose), and the sort are in `references/sources.md`, "Scope" and "Radius". Readers subscribed to their city's newsletter, and an opportunity only they can apply for is the one thing this block offers that a national list cannot.

**A queue with nothing local or regional in it means Tier 4 was skipped.** The script reports it as not ready. Work the partner map and the state energy authority.

## Step 3. Check every candidate

Run the four checks in `references/sources.md`, "Verification", on every candidate, all four, before anything enters the queue. They are stated there once. The deadline is the field that matters; everything else is description.

## Step 4. Build the queue

Write the findings as JSON, `{"city": "<City>", "opportunities": [ ... ]}` with one object per entry (name, org, type, deadline, url, who, scope, description), then:

```bash
python3 $SKILL/scripts/build_queue.py opportunities_<city>.json --md CTC_Opportunities_<City>.md \
    --existing <the current list from Step 1> \
    --xlsx "<outputs folder>/CTC_Opportunities_<City>.xlsx"
```

Omit `--existing` only on a first run. The text file is what Claude keeps in the project; the spreadsheet is the copy the lead reads. Build both every time (unless the chapter log says the lead does not want spreadsheets) and hand the spreadsheet over when you report.

The script merges by URL, refreshing a carried entry's details from the new findings, moves anything past its deadline to the Closed table, and drops any entry whose deadline is not a date, `Rolling`, `Unconfirmed`, or `TBC` (which it stores as unconfirmed). It always writes the file; it then prints `NOT READY` when the Open table is under fifteen, has nothing local or regional, has one type over half, or lacks an Accelerator, Grant, or Fellowship, and `QA FAILURES` for a blank required field, a non-https URL, a duplicate URL, or an em dash or en dash in the name or description. Either line means fix and re-run, not deliver, **and not save**: only a file with neither line goes to the project.

Read its output. It reports how many carried, how many are new, and how many closed.

### Missing information is named, never left silent

The script names every entry that is missing a required field, and which field. Fix them and re-run rather than saving a file with a gap in it.

## Step 4b. Verify the file

Run `references/verifier.md` on the built file: a fresh pass that re-opens every URL in the Open table, carried rows included, and confirms the deadline, eligibility, scope, and type against the program's own page. That file says how to run it as a subagent where the session has one and as a separate step where it does not. Fix the JSON, re-run `build_queue.py --existing`, and only then save.

## Step 5. Save and report

Save `CTC_Opportunities_<City>.md` to the project, set the date in the log, and save the log:

```bash
python3 $SKILL/../ctc-newsletter-cycle/scripts/chapter_log.py set CTC_Chapter_Log_<City>.md opportunities-refreshed <today>
```

Then, in a few lines:

- How many are open, how many are new this month, how many closed.
- What is closing within three weeks, by name. This is the useful part.
- Anything registered with an unconfirmed deadline.
- Which tiers were skipped and why.
- That the list is saved to their project. If it could not be saved, the hand-over wording from `chapter-files.md`.

When `ctc-newsletter-cycle` started this run on the way to a harvest, give those lines and carry straight on; do not stop for a reply.

---

## House rules

**Never invent a deadline.** If the program's own page does not publish one, record `Rolling` or `Unconfirmed` as `references/sources.md`, "Deadlines: three kinds", defines them. Both are supported by the build script and both list fine in the issue. Never guess a date.

**Never carry a closed opportunity into the Open table.** The script prunes by date, so do not work around it.

**Never drop a lead-added entry.** If the lead added something by hand and it fails a check, keep it, name the failed check, and tell them.

**Never list a job posting.** A job is not an opportunity here and the newsletter has no jobs block.

**Never list anything with an application fee.**

**No dollar figures in descriptions.** Award sizes change and the file is meant to survive a year.

**Descriptions run 25 to 40 words**, in the shape `../ctc-assemble/references/voice.md` section 6, "Opportunity descriptions", sets. The script warns over 45. The block in the newsletter is emoji, linked title, short description, bolded deadline.

---

## Failure modes

**A thin month.** Some months add only three new entries. Say so plainly. That is fine as long as the Open table still holds fifteen, because the queue carries the rest. If it does not, the tiers were not worked; rolling Tier 1 programs are listable and are usually what is missing.

**An aggregator's deadline disagrees with the program page.** The program page wins, always.

**No browser in the session.** Skip Tier 3, name it, carry on. The other three tiers are most of the value.

**No partner map workbook.** Do one research pass over the city's incubators, universities, and economic development bodies. Say once, at delivery, that running `ctc-city-resources` and then `ctc-partner-list` for this city first would make Tier 4 substantially cheaper every month, because most of that research is the same research.

**The lead asks mid-month for more.** Fine. Run the tiers again, then rebuild the file with `--existing` so the new entries are in the list rather than in a one-off, and save it to the project. This is the one skill that writes the list; `ctc-assemble` hands mid-month finds here for exactly this reason. Anything found mid-month should be there for the following weeks too.

**Two chapters ask for the same national programs.** Expected. Most of this queue is national and will look similar across cities. The local tier is what makes each one different, which is why it is worth the effort.
