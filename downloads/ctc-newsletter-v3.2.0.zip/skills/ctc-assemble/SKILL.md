---
name: ctc-assemble
description: Assemble a Climate Tech Cities weekly newsletter draft from the events the chapter lead kept, building all ten blocks in house order, ready to paste into Substack. Use this skill whenever the user wants to build, assemble, draft, or write a city newsletter issue, has reviewed their events (or has an events sheet) and wants the newsletter made from it, asks for "this week's issue", wants the picks or opportunities or event listings written up, or is at the drafting stage of the weekly newsletter cycle. Always use this skill even if the user only wants one block, such as just the picks or just the listings. Do NOT use it to collect events, which is the harvest skill's job.
---

# CTC Assemble

Turn the events the lead kept into a complete newsletter draft in house style. Output is one HTML file, ready to paste into the Substack editor.

## Find your files first

Every path in this skill (`scripts/...`, `references/...`, `../ctc-<other skill>/...`) is relative to **this skill's own folder inside the installed plugin**, not to the working directory. Locate it before anything else, once per session:

```bash
find / -xdev -type d -path "*/ctc-newsletter*/skills/ctc-assemble" -not -path "*/.trash/*" 2>/dev/null | head -1
```

Call the result `$SKILL`. The plugin's other skills are its siblings (`$SKILL/../ctc-assemble`, `$SKILL/../ctc-harvest`, and so on). Run scripts as `python3 $SKILL/scripts/<name>.py` and read references as `$SKILL/references/<name>.md`. If the search returns nothing, the plugin's files did not install; say so and stop, rather than rebuilding any script by hand or inventing a URL the files were supposed to carry.

## What you will get back

One file, named for the chapter and the window, for example `Portland_Climate_Tech_Aug_11-Aug_18.html`. It carries every link, emoji, and day header, in this order:

| # | Block | Who finishes it |
|---|---|---|
| 1 | Title and subtitle | Claude |
| 2 | Opening note | Claude drafts, you rewrite |
| 3 | Picks of the week | Claude drafts from your choices, you add the asides |
| 4 | Housekeeping and sign-off | Claude drafts from what you tell it, you rewrite |
| 5 | Climate Tech Cities and Streetlife Ventures platforms block | Fixed text, never changes |
| 6 | Opportunities | Claude drafts from the queue, you confirm |
| 7 | This Week's Events | Claude, complete |
| 8 | Upcoming Events | Claude, complete |
| 9 | This Week in Detail | Claude, complete, one entry per this-week event |
| 10 | Join the fun: submit events and volunteer | Fixed text, never changes |

Blocks 2, 3, and 4 come back with a yellow line above them reading `[REWRITE IN YOUR OWN WORDS, then delete this line]`. Nothing ships until every one of those lines is gone. A Word copy of the same issue is built only when the lead asks for one. A rendered example of the whole thing is `references/sample-output/Portland_Climate_Tech_Aug_11-Aug_18.html`, built from `references/example-issue.json`; a published New York issue as text is `references/example-issue.md`.

## What this is for

The issue goes to a few hundred to a few thousand people in one city, by email, on the morning of the send day. Most of them scan it once, looking for one thing: is there anything on this week I should go to?

Roughly 40% of the audience does not yet work in climate. That decides ties: free and newcomer-friendly wins, in-person beats webinar, and the arts and volunteering listings are not filler.

A mature issue runs about 3,000 words, of which fewer than 150 are the lead's own. Those words are why anyone subscribes. Everything else is listings, and the tool's job is to make the listings free so the words get written.

## Read this first

- `references/voice.md`, the CTC voice file. Read it before writing any prose. Section 6 says what each block needs. It is the only place banned words live.
- `references/house-style.md`, the formatting spec, the ten blocks with worked examples, emoji vocabulary, and scale expectations.
- `references/example-issue.md`, one complete issue end to end in the current order, so proportions are concrete.
- `references/personal-voice.md`, when the project holds `CTC_Voice_<City>.md` or the lead has just sent writing samples. It says how the lead's own voice file is built and how it combines with the house voice.
- `references/example-issue.json`, a complete valid input file for the build scripts. Read its `picks` array before writing your own; the segment array is the part people get wrong.
- `scripts/draft_issue.py`, which writes the listing blocks from the kept rows and checks the finished issue against them, and `scripts/issue_checks.js`, the date and deadline checks both build scripts run. The header of each says what it does.
- `references/verifier.md`, the second-pass check run before the issue is handed over, and `scripts/check_voice.js`, the banned-phrase scanner it starts with.
- `../ctc-newsletter-cycle/references/chapter-files.md`, for reading the chapter's files from the project and handing the issue over.
- `references/ctc-links.md`, the fixed CTC links. You should never need to type one: the build scripts insert blocks 5 and 10 themselves.

## Environment

| Dependency | Needed for | If it is missing |
|---|---|---|
| Node.js, Python and code execution | Every script | Ask the user to enable code execution in Claude settings. Without it, output the issue as markdown and say plainly that the file was not built and the lead will have to re-attach links by hand |
| A browser Claude can drive | Re-checking Luma and Eventbrite links before the build | Re-check what a plain fetch can reach, and name every row that could not be re-checked in the delivery message |
| `docx` npm package | Only when the lead asks for a Word copy | `npm install docx`. Handle it yourself |

`build_issue_html.js` has no dependencies beyond Node.

## Input

- **The rows the lead kept**, `events_final.json`, written by `../ctc-newsletter-cycle/scripts/review.py` from the lead's reply to the review (or from the spreadsheet they edited). Each row carries the fourteen columns, `Block`, `Source`, `Pick`, and `page_checks`. Never build from `events.json`, which still holds the rows the lead cut. If only the harvest's file exists, the review has not happened: go back to `ctc-newsletter-cycle`, Stage 2.
- **The chapter settings file**, from the project: city, chapter name, timezone from section 1; send day, cadence, scope rule, sign-off from section 2. Read it rather than asking.
- **The opportunities the lead chose**, by number, from `open.json` (written by `../ctc-opportunities/scripts/read_queue.py`).
- **The lead's voice file**, `CTC_Voice_<City>.md`, if the project has one. Optional.
- **What the calendars cannot know**, in the lead's words from their reply: the raw material for the opening note and the housekeeping.
- **The send date and the window.** Seven days from the send day for a weekly chapter, fourteen for one that has moved to every two weeks.

## The gate: an opportunities list must exist

**This skill does not build an issue unless the chapter has an opportunities list**, `CTC_Opportunities_<City>.md` (or the older `Opportunities_<City>.xlsx`), in the project or built in this conversation. `ctc-newsletter-cycle` checks for it before the harvest, so reaching this point without one means the cycle was skipped. Say so, offer to run `ctc-opportunities` now, and build nothing until the list exists. If the lead asks to skip it, decline once, plainly.

A list that exists with nothing open in it is different: the block is omitted for this issue, and the monthly refresh is due.

## What must be settled before building

When this skill is run by `ctc-newsletter-cycle`, the lead's reply to the review has already settled all three of these and **this skill asks nothing**. When it is run on its own, ask for whatever is missing in one message, wait, and proceed with what comes back.

**1. Which events are the picks.** The rows with `Pick` set in `events_final.json`. Four to six, roughly one per day that has events. More than six and the block stops being a recommendation and turns into a second listing. Build what the lead chose, even outside that range, and say so once.

**2. Which opportunities.** Fellowships, accelerators, grants, calls for applications; these never come from the events. The lead chose from the numbered list `read_queue.py` printed, which had already dropped every lapsed deadline and marked what ran before. Two to four. If they chose none, use the three it marked as proposed and say so. The lead can also add one of their own (take name, link, deadline, draft it for this issue, and tell them it will be added to the list at the next monthly refresh) or ask you to go and find some (only on request; run the research pass from `ctc-opportunities`). Never research automatically.

An entry recurring across issues until it closes is correct rather than lazy; the chapter log's record of what ran is for spacing, not exclusion.

**3. Anything the calendars cannot know.** The chapter's own upcoming event, a postponement, a call for submissions, something that happened in the city this week, anything the lead wants to say. If the lead gave nothing, draft from what the rows show and the season; the marker still goes on.

## Re-check every link that ships

Before any block is written, fetch every row in `events_final.json` again and compare it with the row. This is the second look every published link gets, and it happens here, on the rows that are going out, as close to the send as the build allows.

- **Luma and Eventbrite rows:** `__PULL_LUMA` and `__PULL_EB` from `../ctc-harvest/scripts/harvest_helpers.js`, ten per call from one tab, read as `../ctc-harvest/references/platform-notes.md` describes. One agent in the browser, paced.
- **Everything else:** a plain fetch of the event page; these can be split across subagents.

For each row, the fresh page must: load (not a 404, not a challenge page); be this event; show the same date; show the same start time after timezone conversion; agree on location and on price; and not say the event has ended or been cancelled.

**The page wins, and every difference is acted on:**

| What the fresh page shows | What to do |
|---|---|
| A different time, venue, or price | Correct the row |
| A different date, still inside a window | Correct the row and its `Block` |
| A date outside both windows, or the event cancelled or ended | Drop the row. If it was a pick, the issue has one pick fewer; do not substitute one |
| The link redirects to a different event, or is dead | Find the event's real page; if there is none, drop the row |
| Sold out | Keep the row; say so in the description |

Record the result on each row as `link_recheck` (`{"ok": true}` or `{"ok": true, "changed": "start time 18:00 to 18:30"}`), and list every change and every dropped row in the delivery message, one line each. The lead approved a list; they are owed what moved after they approved it.

If a row cannot be re-fetched (no browser in this session, a site that blocks), leave `link_recheck` off it and name it in the delivery message as not re-checked.

## The editorial blocks: draft fully, then mark

Blocks 2, 3, and 4 are written by a person before they ship. The house position is that generated commentary reads as generated and readers notice. That is not a reason to leave the blocks empty. **Draft every one of them completely**, from what the lead told you and what the rows show: in the lead's own voice when the project holds `CTC_Voice_<City>.md` (read `references/personal-voice.md`, "Drafting with it", for how it combines with the house rules), and in the house voice from `references/voice.md` when it does not. Either way, and put this line on its own, directly above each drafted block:

```
[REWRITE IN YOUR OWN WORDS, then delete this line]
```

Square brackets, because the pre-send check is "search the document for a square bracket; nothing in brackets ships." Both build scripts render that line as a yellow band so it cannot be missed, and both count how many are left.

A full draft the lead edits down is less work for them than a blank they have to fill, and it shows them the shape. What the draft cannot contain is anything invented: no weather they did not mention, no verdict on an event nobody attended, no reason for excitement the lead did not give. Where a fact is missing, write around it rather than making one up.

If the lead asks you to skip the rewrite and ship your draft, say once that the issue reads better in their words, then build it as asked with the markers left in. The markers are their decision to remove.

## The ten blocks, in publication order

### 1. Title and subtitle

**Title:** `[Chapter name]: [Month D] - [Month D]`, the send window. Never an issue number.

> Portland Climate Tech: Aug 11 - Aug 18

**Subtitle:** comma-separated topics drawn from the picks and opportunities, closing with `and more upcoming events`. Doubles as the email subject line, so front-load the most interesting item. Six or seven topics, lowercase except proper nouns. Build it after the picks are settled.

### 2. Opening note

Greeting, length, and the two-paragraph shape are set in `references/voice.md` section 6, "Newsletter opening note draft"; the hook comes from what the lead said the calendars cannot know. The marker line sits between the greeting and the first paragraph, so the greeting is never inside the bracket.

### 3. Picks of the week

One bullet per day that has picks, in date order, in the shape `references/voice.md` section 6, "Picks", sets (the emoji sits inside the link with the title). Day words: `Today`, `Tomorrow`, weekday names, `Next Tuesday` for the one case of an event just past the window. Every pick must also appear in block 7 or block 8; a `Next Tuesday` pick sits in Upcoming and that is the only case where a pick is not in This Week's Events.

Selection is the lead's: the rows with `Pick` set. Build only what they chose. `draft_issue.py start` writes `_picks_to_write` into `issue.json` with each pick's title, link, date and the correct day word; take all four from there and write only the prose around them. A pick from Upcoming has no description on its row; write its lead-in from that event's own page, which the link re-check has just read, and from nothing else.

Draft the bullets in full, including one aside where the material supports it, and put the marker line above the block. The asides are what make it sound like a person, and the lead will replace yours with theirs.

### 4. Housekeeping and sign-off

Postponements, calls for submissions, whatever the lead needs to say, from their reply. Reader asks in **bold** inline, written as `**...**` in the JSON; the scripts render the bold. Then the sign-off from the settings file, `Til next week!` on one line and the names on the next (variants are in `references/house-style.md`).

If the lead gave nothing for housekeeping, omit the paragraphs and keep the sign-off. Never invent an announcement.

### 5. Platforms block

Fixed text with two fixed Typeform links, the same in every issue of every chapter. Both build scripts insert it when `platforms` is absent from the JSON. Leave it absent. It sits here, after the sign-off and before Opportunities, and nowhere else.

### 6. Opportunities

The items the lead chose. Linked emoji heading, then the description from the opportunities list in a blockquote, then the deadline in bold at the end of the description: `Applications due August 1.` Take the deadline line and the ISO `deadline_date` from the entry in `open.json` rather than retyping either; a rolling program reads `Rolling applications`. A shorter variant puts the deadline in the heading itself. Items recur across issues until they close, which is correct rather than lazy. Anything past its deadline is dropped, and if nothing is open the block is omitted.

### 7. This Week's Events

Every `this_week` row, grouped under day headers, chronological, titles only. The day header carries the date. Event names exactly as harvested. `draft_issue.py start` writes this block, block 8 and block 9 from the rows; do not retype them.

```
#### Wednesday, Aug 12
[emoji] [Event Name](Registration Link)
```

### 8. Upcoming Events

Every `upcoming` row, with one hard rule: **a recurring event appears once per issue, at its earliest date only.** When the rows carry the same event on several dates (same name, same host: a weekly workday, a monthly cleanup, a multi-date sale), print only the earliest in-window date and none of the later ones. If its earliest date already puts it in This Week's Events, it does not appear in Upcoming at all. Nothing is lost: the later dates are still harvested each week, and each surfaces in a later issue once the dates before it have passed. Both build scripts flag a title that appears twice in Upcoming, or in both listing blocks.

Otherwise: flat, chronological, no day headers, date appended after the link in `Mon D` form. Runs to the end of the harvest window.

### 9. This Week in Detail

**One entry for every event in block 7, no exceptions.** Readers use this section so they do not have to click into each event, and the lead has already made the cut, so everything left in `this_week` is worth the space. Upcoming events do not get entries.

Per event: the linked emoji heading exactly as in block 7, then When, Where, then the description in a blockquote.

```
### [emoji] [Event Name](Registration Link)

**When:** Wednesday, Aug 12

**Where:** Ecotrust Building, 721 NW 9th Ave, Portland

[Two to three sentences from the row's Description.]
```

**The When line is the date only, in exactly the day-header form: `Wednesday, Aug 12`.** Never append a start time, a year, or anything else; the published NYC issues carry no times anywhere in the listings, and both build scripts flag a When line that carries more than the date.

The description comes from the row's `Description`, which `ctc-harvest` wrote from the event's own page at 40 to 70 words in the shape voice.md section 6 sets. Tidy it and do not rewrite it freely. A this-week row with no description (an event the lead added, or one whose date moved into this week at the re-check) gets one now, written from its own page the same way. For an online event, Where is `Online`.

Both build scripts compare this block against block 7 and print any event that is missing an entry. Fix those before delivering.

### 10. Join the fun

Fixed text with two fixed links: submit an event (the Climate Tech Cities intake form, one form for every chapter) and volunteer. Both scripts insert it when `footer` is absent from the JSON. Leave it absent. This is the last block of the issue.

## Emoji

Every event in every listing block gets one, placed before the title and inside the link. How to choose it, the fallbacks, and the reuse rules are in `references/house-style.md` section 3. Put it on each row of `events_final.json` as `Emoji` before drafting; the same event then carries the same emoji in every block.

## Building the issue

Five steps, in this order. Each script stops with a named reason when something is wrong; fix what it names and run it again. Never work around a stop.

**1. Draft the listing blocks from the rows.**

```bash
python3 $SKILL/scripts/draft_issue.py start events_final.json issue.json \
    --send-date <YYYY-MM-DD> --chapter "<title name, e.g. Portland Climate Tech>" [--cadence biweekly]
```

It writes the title, the send date, blocks 7, 8 and 9, and `_picks_to_write`, every date in both its printed and its ISO form, with the recurring-event rule applied. It refuses to run if a row has no emoji, no link, or a date that does not fit its block. The title name is the chapter's name in the `[City] Climate Tech` form (`references/house-style.md` section 5).

**2. Write the rest into `issue.json`:** `subtitle`, `opening_note`, `picks`, `housekeeping`, `signoff`, `opportunities`. Leave `picks_intro` as written. Tidy a block 9 description only where it needs it. Do not touch the titles, links or dates the script wrote.

**3. Check the issue against the rows.**

```bash
python3 $SKILL/scripts/draft_issue.py verify issue.json events_final.json
```

It confirms every row the lead kept is listed with its own name, link and date, nothing is listed that the lead did not keep, every this-week event has its detail entry, and every pick the lead chose is in the picks block and nothing else is.

**4. Build.**

```bash
node $SKILL/scripts/build_issue_html.js issue.json "<outputs folder>/<City>_Climate_Tech_<date range>.html"
```

Name it the way `references/sample-output/` is named, for example `Portland_Climate_Tech_Aug_11-Aug_18.html`. The script runs the date checks first: an event before the send date, a lapsed deadline, a day header or a When line that does not match its date, a wrong day word on a pick, or a missing date **stops the build and writes nothing**. Then it prints block counts, how many bracketed markers remain, and a `CHECK BEFORE DELIVERING` list. Fix everything on that list and rebuild. A missing or placeholder fixed link also stops the build; the fix is to remove `platforms` and `footer` from the JSON so the standard blocks are inserted.

**5. Verify.** Run `references/verifier.md`: the voice checker (`node $SKILL/scripts/check_voice.js issue.json`, which reads the banned list from voice.md section 5) and the fresh read of the built HTML. Fix, rebuild, re-run.

Then hand over the `.html`, and nothing else, as `chapter-files.md` describes. The JSON is scratch. The lead pastes from the HTML file: open it in a browser, click before the first word, drag to the bottom, copy, paste into a new Substack post. That carries formatting and links across, which a copy button does not.

**A Word copy, only when the lead asks for one:** `node $SKILL/scripts/build_issue.js issue.json "<outputs folder>/<same name>.docx"`. It runs the same checks.

### issue.json

```json
{
  "send_date": "2026-08-11",
  "cadence": "weekly",
  "title": "Portland Climate Tech: Aug 11 - Aug 18",
  "subtitle": "topics, comma separated, and more upcoming events",
  "opening_note": ["Hi all,", "[REWRITE IN YOUR OWN WORDS, then delete this line]", "paragraph", "paragraph ending Here are our picks for the week:"],
  "picks_intro": "[REWRITE IN YOUR OWN WORDS, then delete this line]",
  "picks": [
    {"day": "Tomorrow", "date_iso": "2026-08-12", "segments": [
      {"text": "get into the weeds on interconnection queues at "},
      {"text": "⚡ Grid Interconnection 101", "link": "https://..."}
    ]}
  ],
  "housekeeping": ["[REWRITE IN YOUR OWN WORDS, then delete this line]", "paragraph with a **bolded reader ask**"],
  "signoff": ["Til next week!", "Names, and the Climate Tech Cities team"],
  "opportunities": [
    {"title": "💡 Name", "url": "https://...", "description": "...", "deadline": "Applications due August 1.", "deadline_date": "2026-08-01"}
  ],
  "this_week": [
    {"day": "Wednesday, Aug 12", "date": "2026-08-12", "events": [{"title": "⚡ Name", "url": "https://..."}]}
  ],
  "upcoming": [{"title": "♻️ Name", "url": "https://...", "date": "Aug 26", "date_iso": "2026-08-26"}],
  "this_week_in_detail": [
    {"title": "⚡ Name", "url": "https://...", "when": "Wednesday, Aug 12", "date_iso": "2026-08-12", "where": "Address", "description": "Two to three sentences."}
  ]
}
```

A segment is `{text}` for plain runs or `{text, link}` for hyperlinked ones, so a pick bullet interleaves prose and linked titles. A paragraph string that is exactly a bracketed line renders as the yellow marker; `picks_intro` is the one slot for block 3's marker, rendered above the bullets, and the marker for block 2 sits in `opening_note` after the greeting and for block 4 at the top of `housekeeping`. `**text**` inside a paragraph renders bold. Omit any block with no content and it is skipped, except blocks 5 and 10, which are inserted whether or not the JSON mentions them. Keys beginning with an underscore are ignored by the build.

**The date fields are what the checks run on.** `send_date` is required. Each This Week day carries `date`; each upcoming event, detail entry and pick bullet carries `date_iso`; each opportunity carries `deadline_date`, which is an ISO date, `Rolling`, or `Unconfirmed`. The script writes most of them; the pick bullets' `date_iso` and day word come from `_picks_to_write`, and each opportunity's `deadline_date` from `open.json`. One pick bullet covers one date; two picks on the same day share a bullet, joined the way `references/voice.md` section 6 shows.

## After the build

Record the issue and clear the week's working copy, as `../ctc-newsletter-cycle/SKILL.md`, Stage 5, sets out (`chapter_log.py record-issue`, then `chapter_files.py events-pack --built`), and save both to the project. Recording the issue is what lets next week's review say which opportunities already ran. Do this even when this skill was run on its own.

Then report in chat, briefly:

- Event counts per listing block, and confirmation that block 9 has one entry per this-week event
- Anything the link re-check changed or dropped, one line each, and any row that could not be re-checked
- Which blocks carry a rewrite marker
- Opportunities included
- Later dates of recurring events held back for later issues
- Emoji assigned by fallback rather than by topic

## What the lead still checks

The scripts and the verifier have checked dates, deadlines, duplicates, detail entries, block order, fixed links, and every link's page. What is left for the lead is what only they can do, and the delivery message says exactly this much:

- Rewrite the three marked blocks and delete the yellow lines. Search for a square bracket; nothing in brackets ships
- Read it once top to bottom as a subscriber would, clicking two or three links on the way

## Failure modes

**Building from the wrong rows.** `events.json` still holds the rows the lead cut. Build from `events_final.json`, and run `draft_issue.py verify` before every build; it is the check that nothing cut came back and nothing kept went missing.

**Retyping a listing.** A name, link or date typed by hand is where a wrong link ships. The listing blocks come from `draft_issue.py start`; the picks' titles and links from `_picks_to_write`.

**Skipping the link re-check because the harvest was recent.** The re-check is the only second look the published links get. Run it on every row, every build.

**Working around a stopped build.** A date check that fails is telling the truth about the issue. Fix `issue.json`; never edit a date field to make the check pass without correcting what it prints.

**Skipping block 9, or filling it for some events only.** Every this-week event gets a detail entry. The scripts stop on a mismatch.

**The platforms block at the bottom.** It sits after the sign-off and before Opportunities. The last block is Join the fun.

**Dropping the marker because the draft is in the lead's voice.** A voice file makes the draft closer; it does not make it theirs. All three markers stay.

**Letting the lead's voice into the listings.** The voice file applies to blocks 2, 3 and 4 only. Block 9, the opportunities and every listing stay in the house voice.

**Shipping a marker.** The bracket lines are for the lead to delete after rewriting. Say so at delivery, every time.

**Inventing material for the note.** A draft is built from what the lead said and what the rows show. If there is nothing topical, draft the seasonal version and say it is thin, rather than making up weather or news.

**Pick bullets that break the shape.** A list of names, or same-day picks joined with "and". The shape is in `references/voice.md` section 6 and the weak-and-strong pairs are in `references/house-style.md`.

**Padding Opportunities.** Two real ones beat four with filler, and a lapsed deadline is worse than an empty block.

**Rewriting descriptions in block 9.** They were written from the event's own page. Tidy and condense; do not add.

**Shipping markdown instead of the file.** The deliverable is the `.html`. Markdown in chat means the lead re-attaches every link by hand.
