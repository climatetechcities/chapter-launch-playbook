# The weekly schedule: the run that starts itself

The lead should not have to remember to start the newsletter. With their one-time yes, Claude creates a scheduled task on their Claude account that starts the weekly run the day before the send day. The lead's week then begins with a notification and a review message already waiting.

Claude creates the task. The lead never builds an automation by hand.

## What gets scheduled, and what does not

| Part of the week | Scheduled? |
|---|---|
| Refreshing the opportunities when they are a month old | Yes. It happens inside the weekly run, before collection |
| Collecting the events and checking them | Yes |
| Proposing the cut, the picks and the opportunities, and sending the review message with the spreadsheet | Yes |
| The lead's reply to the review | No. It is their decision |
| Building the issue | Starts as soon as they reply |
| Rewriting the three blocks and sending | No. Theirs |

One task is enough. Do not create a separate monthly or quarterly task: the weekly run already does the monthly refresh when it is due and offers the quarterly one.

## When to offer it

- **At a chapter's first run**, as the third yes-or-no question in the one setup message (SKILL.md, "First run").
- **When the chapter log says `Not asked`** (a chapter that started before this existed): one line in a review message, once.
- **Any time the lead asks**: "schedule this", "make it automatic", "can it start itself".

Never ask when the log says `No`. Record the answer: `chapter_log.py set schedule yes|no`.

## Creating the task

Do this once, after the chapter's first issue has been built, so the first scheduled run is never also a first run.

1. **Find the scheduling tool.** Sessions differ. Look for a tool that creates a scheduled task (search the session's tools for "schedule" or "trigger" if it is not already loaded). If the session can list existing scheduled tasks, list them first and do not create a second one for this city.
2. **Work out the time.** The day before the send day in the settings file, early afternoon in the chapter's timezone, at a minute that is not on the hour or half hour (13:40, not 13:00). Use the chapter's IANA zone, never a guessed offset. A weekly chapter runs every week; a chapter on every two weeks runs every second week, counted from its next send date.
3. **Name it** `CTC newsletter: <City>`.
4. **It needs the lead's computer.** The collection reads Luma and Eventbrite through a browser on the lead's computer. Where the scheduling tool has a way to say a task needs the computer, say so. Create the task from a chat inside the chapter's project, so its runs can reach the chapter's files.
5. **Give it this prompt**, with the city filled in. Every run starts with no memory of any chat, so the prompt has to stand on its own:

   > Run this week's Climate Tech Cities newsletter for <City>, using the ctc-newsletter-cycle skill from the ctc-newsletter plugin. This is a scheduled run and nobody is watching it. Follow that skill's "Scheduled runs" section exactly: read the chapter's settings and log from the project, collect this week's events, send the review message with the events spreadsheet, then stop and wait for the chapter lead's reply. Do not build or send anything before they reply. If the chapter's files or a browser cannot be reached, do not collect; say in one short message what is missing and that the lead can open Claude and say "run the newsletter".

6. **Record it:** `chapter_log.py set schedule yes`, and save the log.
7. **Tell the lead, in a few lines:** what was created, when it runs, that they will get a notification with the review waiting, that their computer needs to be on with Claude open at that time for the event calendars to be read, and where to find it (the Scheduled list in Claude) if they want to pause or change it. The tool reports whether the task's runs will go ahead without stopping for approval; pass that on in one sentence, and if runs will stop to ask, say they can switch the task to approve automatically in its settings.

**If the session has no scheduling tool**, say so plainly and give the lead the three things to enter themselves in Claude's Scheduled section: the name, the time, and the prompt above. Record `schedule no` only if they decline; otherwise leave it `Not asked` and offer again next week.

## Keeping it right

- **The send day or cadence changes:** update the task to match, the same day the settings file changes.
- **The lead says stop:** pause or delete the task if the session can, otherwise tell them where to do it, and set `schedule no`.
- **Never create a second task** for the same city. If one exists and looks wrong, update it.

## What can go wrong

| Situation | What the scheduled run does |
|---|---|
| The lead's computer is off, or no browser can be reached | Does not collect. Sends one short message saying so and that they can say "run the newsletter" when they are at their computer. A thin list with no dates is worse than no list |
| The chapter's files cannot be read | Same: one short message, no collection |
| The log's browser answer is not `Yes` | Same. A scheduled run never asks a question |
| Last week's review is still unanswered | Starts this week's run anyway and says in one line that last week's was never answered. Missed weeks are not chased |
| The lead already ran this week's issue by hand | The log shows an issue for this send date. Says so in one line and stops |
| The run stops to ask for approval | Nobody is there to give it. The lead sees it when they open Claude; tell them once how to switch the task to approve automatically |
