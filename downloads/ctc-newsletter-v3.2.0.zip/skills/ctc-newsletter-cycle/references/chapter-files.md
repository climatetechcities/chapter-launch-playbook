# Chapter files: where they live, how to read them, how to save them

Every skill in this plugin reads this file before it reads or writes a chapter file. The point of it: **the lead never carries a file.** Claude keeps the chapter's files in the lead's Claude project and updates them there.

## The files

| File | What it is | Written by | Read by |
|---|---|---|---|
| `CTC_Settings_<City>.md` | City, timezone, send day, cadence, scope rule, sign-off | `ctc-chapter-setup` | every skill |
| `CTC_Source_List_<City>.md` | Every place events get announced | `ctc-source-map` | `ctc-harvest` |
| `CTC_Opportunities_<City>.md` | Open grants, fellowships, accelerators; a Closed section below | `ctc-opportunities` | `ctc-assemble` |
| `CTC_Chapter_Log_<City>.md` | Last-built dates, standing answers, one line per issue, which opportunities ran | `ctc-newsletter-cycle` | every skill |
| `CTC_Voice_<City>.md` | How the lead writes, built from their samples. Optional | `ctc-assemble` (`references/personal-voice.md`) | `ctc-assemble` |
| `CTC_Events_<City>_latest.json` | This week's harvested events, so a review can be finished in a later chat | `ctc-harvest` | `ctc-newsletter-cycle`, `ctc-assemble` |

`<City>` is the city with anything that is not a letter or digit turned into an underscore (`New_York`). All but the last are plain markdown with ordinary tables, so the lead can open them in the project and read them.

With the lead, call these "your settings", "your source list", "your opportunities list", "your chapter log" and "your writing style". Never say config, registry, schema or pipeline.

## Reading a chapter file

1. Look at the list of documents in the attached project. A file may sit at the top level or under a `claude/` folder; check both.
2. Read it with the session's project tool. If the tool returns the text, write it to a file of the same name in your working folder so the scripts can open it. If it returns a path, use that path.
3. If the project has no such file, check whether the lead attached it to this conversation.
4. If it is nowhere, the stage that builds it has not run. Say which, and run it.

**Older chapters.** A chapter set up before version 3 has `Chapter_Settings_<City>.docx`, `CTC_Source_Registry_<City>.xlsx` and `Opportunities_<City>.xlsx` in its project instead. They are still good. Read them as they are; `chapter_files.py sources-import` and `queue-import` open the two spreadsheets directly. The next time one of them is rebuilt, write the new text file, save it, and tell the lead once that the old spreadsheet can be removed from the project. If both the old and the new file exist, the text file is current.

## Saving a chapter file

**The source list is saved only after the lead has read it and said it looks right.** It is the one chapter file a person approves before it goes into the project (`ctc-source-map`, "Show it, then save it"). Every other file is saved as soon as its checks pass.

Save only a file a script has just written and whose checks passed. Never save a file with a failed check, a half-written file, or text you typed out by hand in place of a script's output.

**When the session can write to the project** (it has a project tool with a write method, and a project is attached):

- Save the file under its exact name. If you read it from a path such as `claude/CTC_Source_List_Boston.md`, write it back to that same path so it replaces the old one. A file saved under a second name leaves two versions, and the next run cannot tell which is current.
- Pass the file's path on disk where the tool accepts one, so nothing is retyped.
- Tell the lead in one short line what was saved: "Saved your source list to the project."
- Never delete a project document.

**When it cannot** (no project attached, no write tool, or the save fails):

- Hand the file to the lead with the session's file tool and say, in close to these words:

  > I could not save this to your project from here, so here is the file. Add it to your project as a context file: open the project, then project settings, then add files. If an older copy is there, remove it. Do not attach it to a chat; a file attached to one chat is not there in the next one.

- Say once, the first time this happens, that starting chats from inside the project lets Claude keep these files itself.
- Carry on. A failed save is never a reason to stop a run that already has what it needs.

## The chapter log

`chapter_log.py` (in this skill's `scripts/`) is the only thing that writes the log. After any command that changes it, save the log back to the project.

| When | Command |
|---|---|
| Start of any run | `status` to see what is due and what the lead has already answered |
| No log exists | `init --city <City>` |
| Source list built or refreshed | `set sources-built <YYYY-MM-DD>` |
| Opportunities built or refreshed | `set opportunities-refreshed <YYYY-MM-DD>` |
| Lead answers a standing question | `set browser yes|no`, `set linkedin yes|no` |
| Lead gives writing samples (voice file built), or declines | `set voice yes`, `set voice no` |
| Lead agrees to the weekly schedule and the task is created, or declines | `set schedule yes`, `set schedule no` |
| Lead says they do not want spreadsheets | `set spreadsheets no` |
| An issue is built | `record-issue --issue issue.json --submitted <N>` |
| Lead reports last issue's numbers | `numbers --send-date <date> --sent yes --subscribers <N> --open-rate "<x>%"` |

A standing answer is asked once and never again. If the log says `Yes` or `No`, that is the answer; do not re-ask, and say in one line what you are doing because of it. If the lead changes their mind, set it again.

## The weekly events file

`CTC_Events_<City>_latest.json` exists so a lead who gets the review today and answers tomorrow, in this chat or a new one, does not need a second harvest. One file, overwritten each week:

- After the harvest and before the review message: `chapter_files.py events-pack events.json CTC_Events_<City>_latest.json --city ... --send-date ... --tz ...`, run **after** `review.py render` so the row numbers are in it, then save it to the project.
- When the lead replies: if `events.json` is still in the working folder, use it. If it is not, read the project copy, save it as `events.json`, and apply the reply to that. Check its `send_date` is the issue being built; if it is an older week's, harvest again.
- After the issue is built: run the same command with `--built` and save again. That leaves a one-line file, so the project is not carrying a week of events it no longer needs.

If the session cannot write to the project, skip this file. The review then has to be answered in the same chat; say so in the review message.

## Working files and files for the lead

Work in the session's working folder. A file the lead is meant to open (the built issue, a spreadsheet they asked for, the launch plan) goes to `/mnt/user-data/outputs/` where that folder exists and the working folder where it does not, and is then handed over with the session's file tool. If the turn ends without the file handed over, the task is not done.

## Spreadsheets: sent every time

The text files in the project are what Claude reads. The lead also gets each list as a spreadsheet, because a spreadsheet is what a person wants to look at:

| When | Spreadsheet handed to the lead | Built by |
|---|---|---|
| The source list is built or refreshed | `CTC_Source_List_<City>.xlsx` | `build_registry.py --xlsx` |
| The opportunities are built or refreshed | `CTC_Opportunities_<City>.xlsx` | `build_queue.py --xlsx` |
| Every week, with the review message | `CTC_Events_<City>_<send date>.xlsx` | `build_sheet.py <out.xlsx>` |

Build each one in the same command that writes the text file, and hand it over with the session's file tool. These are copies for reading and marking up; nothing has to be uploaded back. A lead who says they do not want them gets `chapter_log.py set spreadsheets no`, and from then on they are built only when asked for. `Not asked` means send them.

If a lead edits a spreadsheet and sends it back, read their edits into the text file and save that (`chapter_files.py sources-import`, `queue-import`, or `review.py from-sheet` for the weekly events). The text file in the project is always the working copy; never keep a spreadsheet as a second one.
