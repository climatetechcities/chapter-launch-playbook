# CTC Newsletter (version 3)

Everything a Climate Tech Cities chapter lead needs to run a weekly events newsletter.

## What the lead does

1. **Once:** create a project in Claude for the chapter, open a chat inside it, and say "run the newsletter". Answer the setup questions, and paste a few samples of your own writing when asked so drafts sound like you (optional, recommended).
2. **Every week:** say "run the newsletter", or say yes to the weekly schedule at setup and Claude starts by itself the day before the send day. Reply once to the review message. Rewrite the three marked blocks, paste into Substack, send.

Claude does the rest: collects the events, proposes the cut and the picks, refreshes the opportunities monthly, builds the issue, checks every date and link, and keeps the chapter's files in the project.

## What needs to be in place

- A paid Claude account, with code execution turned on (Settings, Capabilities).
- This plugin installed.
- A project for the chapter. Chats started inside it let Claude keep the chapter's files there.
- A browser Claude can drive, for Luma and Eventbrite: the Claude in Chrome extension (tested), or the Claude desktop app's built-in browser (not yet tested with this toolkit).
- Optional: an Airtable connector, for reading the reader submission form without the browser.

## The skills

| Skill | When it runs | What it does |
|---|---|---|
| `ctc-newsletter-cycle` | Every week; the only one the lead needs to name | Runs everything below in order and stops once, for the lead's review |
| `ctc-chapter-setup` | Once | Eight questions, then the chapter's settings and a two week launch plan |
| `ctc-source-map` | Once, refreshed every three months | Builds the list of places events get announced |
| `ctc-opportunities` | Monthly | Keeps the list of grants, fellowships and accelerators |
| `ctc-harvest` | Weekly | Sweeps the source list and the submission form |
| `ctc-assemble` | Weekly | Builds the ten-block issue, ready to paste into Substack |

## The chapter's files

Claude keeps these in the project and updates them itself. The lead reads and approves the source list before it is saved. The source list, the opportunities and each week's events are also handed to the lead as spreadsheets.

- `CTC_Settings_<City>.md`
- `CTC_Source_List_<City>.md`
- `CTC_Opportunities_<City>.md`
- `CTC_Chapter_Log_<City>.md`
- `CTC_Voice_<City>.md` (optional: how the lead writes, built from samples they share)
- `CTC_Events_<City>_latest.json` (the week's events, only while a review is waiting)

A chapter set up on an earlier version keeps working: its Word settings file and its two spreadsheets are still read.

## For maintainers

`CHANGELOG.md` has what changed in each version and what has and has not been tested. `skills/ctc-newsletter-cycle/references/chapter-files.md` is the single description of how chapter files are read and saved.
