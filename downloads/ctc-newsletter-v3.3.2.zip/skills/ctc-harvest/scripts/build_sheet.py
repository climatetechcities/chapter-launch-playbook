#!/usr/bin/env python3
"""Check the harvested events, and write the events spreadsheet when one is wanted.

Usage:
    python3 build_sheet.py events.json --tz America/New_York --block --check-only
    python3 build_sheet.py events.json out.xlsx --tz America/New_York --block

--check-only runs every check and prints the report without writing a file.
That is the weekly path: the lead reviews the events in chat, so the
spreadsheet is only built when they ask for one.

--tz is required. Give the chapter's IANA zone from its settings file
(America/New_York); the column header's abbreviation (EDT, EST) is worked out
from the event dates, so it is right on both sides of a clock change. A bare
abbreviation is still accepted and used as given.

In --block mode a Description is required on this_week rows only. Upcoming
rows print no description in the issue, so none is written for them until the
event reaches the this-week window.

events.json is a list of objects keyed by the column names below (without the
timezone suffix on the time fields, so "Start Time" and "End Time").

--block is the newsletter mode. It appends two columns after the fourteen:
  Block   this_week / upcoming, which listing block the event lands in
  Source  registry / submitted / lead, where the row came from
          (registry = a source in the registry, submitted = the CTC event
          intake form, lead = the chapter lead typed it in)
A missing key becomes a blank cell, which the completeness report then names
and shades red. Blanks are prompts for a human, never data.
"""

import re
import argparse
import json
import sys
import urllib.parse
from datetime import date, datetime

BASE_COLUMNS = [
    "Event Name",
    "Date",
    "Start Time",
    "End Time",
    "Registration Link",
    "Event Type",
    "Access",
    "Location",
    "City / Neighborhood",
    "Google Maps",
    "Format",
    "Host Organization(s)",
    "Description",
    "Categories",
]

WIDTHS = [42, 12, 14, 14, 40, 12, 32, 46, 22, 40, 26, 34, 70, 34, 12, 12]

CATEGORIES = {
    "Adaptation", "AI & Data", "Arts & Culture", "Biodiversity & Nature",
    "Buildings", "Circular Economy & Waste Management", "Cities",
    "Climate Tech & Startups", "Communications", "Corporate Sustainability",
    "Energy", "Environmental Justice", "Finance", "Food & Agriculture",
    "Fun for Kids", "Get Outside", "Health", "Mobility & Logistics",
    "Philanthropy", "Policy", "Social", "Water",
}

EVENT_TYPES = {"In-person", "Hybrid", "Online"}

ACCESS = {
    "Free",
    "Free — register to view address",
    "Ticketed (Paid)",
    "Ticketed (Paid) — register to view address",
    # The organizer published no price at all. Common for garden programs,
    # committee meetings and museum listings. Recording this is not the same
    # as guessing "Free", and it is not the same as leaving the cell blank.
    "Not stated",
}

# Values that mean "this is genuinely resolved, just not a normal value".
# A row carrying one of these is complete and must not be flagged.
RESOLVED_UNKNOWNS = {
    "Location": {"Shared after registration", "To be announced"},
    "Start Time": {"All day"},
    "Google Maps": set(),
}


def maps_url(location):
    loc = (location or "").strip()
    # No map for an online event, and none for an address the organizer
    # withholds until registration: a map link to "To be announced" is a
    # wrong link that ships.
    if not loc or loc.lower() == "online" or loc in RESOLVED_UNKNOWNS["Location"]:
        return ""
    return (
        "https://www.google.com/maps/search/?api=1&query="
        + urllib.parse.quote(location.strip())
    )


def derive(rows):
    """Fill everything the script can compute, before anything inspects a row.

    Google Maps is derived from Location. It used to be computed inside the
    writer, which meant validation and the completeness report ran against the
    raw input and announced the column as empty on every physical row. The
    sheet was correct and the report was wrong, which is worse than either
    problem alone: it sends whoever is running the harvest off to fix
    something that was never broken.

    Derive once, here, and everything downstream sees the same rows.
    """
    out = []
    for r in rows:
        record = dict(r)
        if not (record.get("Google Maps") or "").strip():
            m = maps_url(record.get("Location", ""))
            if not m:
                # No map can exist for an online event or a withheld address.
                # Write that down rather than leaving a blank: every empty
                # cell ships red, and a cell that can never be filled must
                # not sit red forever.
                loc = (record.get("Location") or "").strip()
                if loc.lower() == "online":
                    m = "n/a (online)"
                elif loc in RESOLVED_UNKNOWNS["Location"]:
                    m = "n/a (address withheld)"
            record["Google Maps"] = m
        out.append(record)
    return out


def validate(rows):
    """Return a list of human-readable warnings. Never raises -- a warning is a
    prompt for the editor, not a reason to refuse to write the sheet."""
    warnings = []
    unchecked = []
    for i, r in enumerate(rows, start=2):
        name = (r.get("Event Name") or "").strip() or f"<row {i}>"
        for field in ("Event Name", "Date", "Registration Link"):
            if not (r.get(field) or "").strip():
                warnings.append(f"row {i} ({name}): missing {field}")
        et = (r.get("Event Type") or "").strip()
        if et and et not in EVENT_TYPES:
            warnings.append(f"row {i} ({name}): Event Type '{et}' not in controlled list")
        ac = (r.get("Access") or "").strip()
        if ac and ac not in ACCESS:
            warnings.append(f"row {i} ({name}): Access '{ac}' not in controlled list")
        bl = (r.get("Block") or "").strip()
        if bl and bl not in {"this_week", "upcoming"}:
            warnings.append(f"row {i} ({name}): Block '{bl}' must be this_week or upcoming")
        import re as _re
        if _re.search(r"sold[\s-]?out|wait ?list|registration closed", (r.get("Event Name") or ""), _re.I):
            warnings.append(f"row {i} ({name}): Event Name carries a status tag. Strip it from the name; the fact belongs in the Description.")
        so = (r.get("Source") or "").strip()
        if so and so not in {"registry", "submitted", "lead"}:
            warnings.append(f"row {i} ({name}): Source '{so}' must be registry, submitted, or lead")
        for cat in [c.strip() for c in (r.get("Categories") or "").split(",") if c.strip()]:
            if cat not in CATEGORIES:
                warnings.append(f"row {i} ({name}): category '{cat}' not in controlled list")

        # --- landing page detection -------------------------------------
        # A link to a calendar index means the event's own page was never
        # opened, so time, address and access were never available to read.
        link = (r.get("Registration Link") or "").strip()
        if link and _is_listing_page(link):
            warnings.append(
                f"row {i} ({name}): Registration Link looks like a listing page, "
                f"not an event page -> {link}. Open the event's own page and "
                f"re-read time, location and access."
            )

        # --- per-row completeness ---------------------------------------
        thin = [f for f in ("Start Time", "Location", "Access")
                if not (r.get(f) or "").strip()]
        if len(thin) >= 2:
            warnings.append(
                f"row {i} ({name}): missing {', '.join(thin)}. Two or more of "
                f"these usually means the listing page was read instead of the "
                f"event page."
            )

        # --- page checks ------------------------------------------------
        # The extraction step records, per event, the three things SKILL.md
        # says to confirm on the event's own page. A row without them was
        # written from a listing or from memory; a row with one false must
        # not ship as it stands. These are warnings, like everything else
        # here, but the run report has to name each one.
        pc = r.get("page_checks")
        if not isinstance(pc, dict):
            unchecked.append(f"row {i} ({name})")
        else:
            failed = [k for k in ("is_this_event", "date_matches", "not_passed")
                      if not pc.get(k)]
            if failed:
                warnings.append(
                    f"row {i} ({name}): page check failed: {', '.join(failed)} "
                    f"(landed on {pc.get('landed_url') or 'unknown'}). Fix the link, "
                    f"fix the date, or drop the row."
                )
            landed = (pc.get("landed_url") or "").strip()
            if landed and link and landed.split("?")[0].rstrip("/") != link.split("?")[0].rstrip("/"):
                warnings.append(
                    f"row {i} ({name}): Registration Link differs from the page the "
                    f"extractor landed on ({landed}). The link must be the page you "
                    f"landed on; use that one."
                )
    if unchecked:
        warnings.append(
            f"{len(unchecked)} row(s) have no page_checks recorded, so the event's "
            f"own page was not read through the extractor. Open each and record "
            f"is_this_event, date_matches, not_passed: " + "; ".join(unchecked)
        )
    return warnings


LISTING_TAILS = (
    "/events", "/events/", "/calendar", "/calendar/", "/boards", "/boards/",
    "/whats-on", "/programs", "/programs/", "/news-events", "/upcoming",
)


def _is_listing_page(url):
    """True when the URL points at an index rather than one event."""
    u = url.lower().rstrip("/")
    for tail in LISTING_TAILS:
        if u.endswith(tail.rstrip("/")):
            return True
    return False


ALWAYS_REQUIRED = [
    "Event Name", "Date", "Start Time", "Registration Link", "Event Type",
    "Access", "City / Neighborhood", "Format", "Host Organization(s)",
    "Description", "Categories",
]

# Only meaningful when the event has a physical venue.
PHYSICAL_ONLY = ["Location", "Google Maps"]

# Plenty of organizers never publish an end time, so an empty End Time does
# not block delivery -- but it ships RED like every other empty cell, and the
# run report names each one. House rule: no blank cell goes unmarked.
NON_BLOCKING = ["End Time"]


def _is_upcoming(row):
    """Upcoming rows print no description in the issue, so none is required."""
    return (row.get("Block") or "").strip() == "upcoming"


def tz_label(tz, rows):
    """The abbreviation for the time column headers.

    An IANA zone is resolved against the event dates, so a sheet that spans a
    clock change reads "EDT/EST" rather than naming the wrong one."""
    if "/" not in tz:
        return tz
    from zoneinfo import ZoneInfo
    zone = ZoneInfo(tz)
    names = []
    days = []
    for r in rows:
        try:
            days.append(date.fromisoformat(str(r.get("Date") or "")[:10]))
        except ValueError:
            pass
    for d in sorted(set(days)) or [date.today()]:
        n = datetime(d.year, d.month, d.day, 12, tzinfo=zone).tzname()
        if n not in names:
            names.append(n)
    return "/".join(names)


def _is_physical(row):
    """True when the event has a venue, so Location and Maps are required."""
    et = (row.get("Event Type") or "").strip().lower()
    return et not in ("online", "virtual", "remote")


def _address_withheld(row):
    """True when the venue is deliberately not published until registration."""
    loc = (row.get("Location") or "").strip()
    acc = (row.get("Access") or "").strip()
    return (loc in RESOLVED_UNKNOWNS["Location"]
            or "register to view address" in acc.lower())


def row_gaps(row):
    """Required fields this row is missing, given its Event Type.

    A field carrying a resolved-unknown value is present, not missing. The
    organizer withholding the address until registration is an answer, and
    flagging it red sends someone hunting for something that does not exist.
    """
    missing = [f for f in ALWAYS_REQUIRED if not (row.get(f) or "").strip()]
    if "Description" in missing and _is_upcoming(row):
        missing.remove("Description")
    if _is_physical(row) and not _address_withheld(row):
        missing += [f for f in PHYSICAL_ONLY if not (row.get(f) or "").strip()]
    return missing


def row_reds(row):
    """Every empty cell in the row, blocking or not. All of these ship red.

    row_gaps() decides whether the sheet is ready; this decides what is
    shaded. The difference is End Time: an organizer that publishes no end
    time leaves a red cell the report explains, not a defect that blocks."""
    reds = list(row_gaps(row))
    reds += [f for f in NON_BLOCKING if not (row.get(f) or "").strip()]
    return reds



def link_defects(rows):
    """Structural link problems detectable without fetching.

    These catch container fallbacks and copy errors. They CANNOT catch a link
    that resolves to the wrong event, a past event, or a 404, which is most of
    the real damage. Only opening the page catches those, which is why the
    skill requires it. Treat a clean report here as "no obvious defects",
    never as "links verified".
    """
    from collections import defaultdict
    problems = []

    # 1. One URL used by two differently-named events. Almost always a
    #    listing page written in place of two missing event pages.
    by_url = defaultdict(list)
    for i, r in enumerate(rows, start=2):
        u = (r.get("Registration Link") or "").strip()
        if u:
            by_url[u].append((i, (r.get("Event Name") or "").strip()))
    for u, entries in by_url.items():
        names = {n for _, n in entries}
        if len(names) > 1:
            rowlist = ", ".join(str(i) for i, _ in entries)
            problems.append(
                f"rows {rowlist}: {len(names)} different events share one URL "
                f"-> {u}. This is a listing page written in place of missing "
                f"event pages. Leave the link empty instead.")

    # 2. Bare domain or a known index path.
    INDEXES = ("/", "/events", "/events/", "/calendar", "/calendar/",
               "/whats-on", "/programs", "/upcoming", "/boards")
    for i, r in enumerate(rows, start=2):
        u = (r.get("Registration Link") or "").strip()
        if not u:
            continue
        m = re.match(r"^https?://[^/]+(/.*)?$", u)
        path = (m.group(1) or "/") if m else "/"
        if path.rstrip("/") in [p.rstrip("/") for p in INDEXES] or path == "/":
            problems.append(
                f"row {i} ({(r.get('Event Name') or '')[:40]}): link is a site "
                f"index, not an event page -> {u}")

    # 3. A PAST year in the URL. Only past years are suspicious: a redirect to
    #    a superseded event carries last year's date. A future year is usually
    #    just the name of next year's conference and must not be flagged.
    for i, r in enumerate(rows, start=2):
        u = (r.get("Registration Link") or "").strip()
        d = str(r.get("Date") or "")
        if not u or not re.match(r"^\d{4}-", d):
            continue
        year = d[:4]
        years = set(re.findall(r"/(20\d{2})[/-]|[-/](20\d{2})/", u))
        found = {y for pair in years for y in (pair if isinstance(pair, tuple) else (pair,)) if y}
        past = {y for y in found if y < year}
        if past:
            problems.append(
                f"row {i} ({(r.get('Event Name') or '')[:40]}): URL contains "
                f"{'/'.join(sorted(past))} but the event is dated {d}. That is "
                f"the signature of a redirect to a superseded event. Open the "
                f"link and record where it actually lands.")
    return problems

def completeness(rows):
    """Per-column fill rate, aware of which fields each row actually needs.

    An online event with no Google Maps link is complete. An in-person event
    with no Location is not. Counting them the same way produces a warning
    nobody can act on, which is worse than no warning at all.
    """
    if not rows:
        return [], ["no rows to write"], []

    n = len(rows)
    # Rows whose venue is withheld until registration need no Location or
    # map, so they leave the pool rather than showing as "missing".
    physical = [r for r in rows if _is_physical(r) and not _address_withheld(r)]
    lines, failures = [], []

    for field in ALWAYS_REQUIRED + PHYSICAL_ONLY + NON_BLOCKING:
        if field in PHYSICAL_ONLY:
            pool, label = physical, " (in-person only)"
        elif field == "Description" and any(_is_upcoming(r) for r in rows):
            pool, label = [r for r in rows if not _is_upcoming(r)], " (this week only)"
        else:
            pool, label = rows, ""
        if not pool:
            continue
        filled = sum(1 for r in pool if (r.get(field) or "").strip())
        pct = round(100 * filled / len(pool))
        floor = 60 if field in NON_BLOCKING else 100
        bar = "#" * (pct // 7)
        flag = "" if pct >= floor else f"   <- {len(pool) - filled} missing"
        lines.append(f"  {field + label:<34} {filled:>3}/{len(pool)}  {pct:>3}%  {bar}{flag}")

    # Row-level: every required field must be present.
    bad = [(i, r, row_gaps(r)) for i, r in enumerate(rows, start=2) if row_gaps(r)]
    if bad:
        failures.append(
            f"{len(bad)} of {n} rows are missing a required field. "
            f"Every one is findable on the event's own page."
        )
    return lines, failures, bad


def build(rows, out_path, tz, include_block):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    headers = list(BASE_COLUMNS)
    headers[2] = f"Start Time ({tz})"
    headers[3] = f"End Time ({tz})"
    if include_block:
        headers.append("Block")
        headers.append("Source")
    headers.append("Missing Info")

    wb = Workbook()
    ws = wb.active
    ws.title = "Events"

    head_font = Font(name="Arial", size=10, bold=True, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="2E7D32")  # matches the CTC events house green
    body_font = Font(name="Arial", size=10)

    ws.append(headers)
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=c)
        cell.font = head_font
        cell.fill = head_fill
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 27.75

    for record in rows:
        line = [
            record.get("Event Name", ""),
            record.get("Date", ""),
            record.get("Start Time", ""),
            record.get("End Time", ""),
            record.get("Registration Link", ""),
            record.get("Event Type", ""),
            record.get("Access", ""),
            record.get("Location", ""),
            record.get("City / Neighborhood", ""),
            record.get("Google Maps", ""),
            record.get("Format", ""),
            record.get("Host Organization(s)", ""),
            record.get("Description", ""),
            record.get("Categories", ""),
        ]
        if include_block:
            line.append(record.get("Block", ""))
            line.append(record.get("Source", "registry"))
        reds = row_reds(record)
        line.append(", ".join(reds) if reds else "")
        ws.append(line)

    # Red only the cells that are actually empty, plus the Gaps cell naming
    # them. A whole red row makes an event with one missing field look as
    # broken as one with five, and a sheet that is mostly red stops being read.
    #
    # This should rarely fire. Most apparent gaps have a valid value: see the
    # resolved-unknown vocabulary above.
    gap_fill = PatternFill("solid", fgColor="F8CBCB")
    col_of = {h.split(" (")[0]: i for i, h in enumerate(headers, start=1)}
    for r_i, record in enumerate(rows, start=2):
        gaps = row_reds(record)
        if not gaps:
            continue
        for field in gaps:
            c = col_of.get(field)
            if c:
                ws.cell(row=r_i, column=c).fill = gap_fill
        if "Missing Info" in col_of:
            ws.cell(row=r_i, column=col_of["Missing Info"]).fill = gap_fill

    widths = list(WIDTHS[: len(headers)])
    while len(widths) < len(headers):
        widths.append(30)
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = body_font
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    wb.save(out_path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("events_json")
    ap.add_argument("out_xlsx", nargs="?")
    ap.add_argument("--tz", required=True,
                    help="the chapter's IANA zone (America/New_York); the header abbreviation is derived")
    ap.add_argument("--check-only", action="store_true",
                    help="run every check and print the report; write no spreadsheet")
    ap.add_argument("--block", action="store_true",
                    help="newsletter mode: add the Block and Source columns")
    args = ap.parse_args()

    if not args.check_only and not args.out_xlsx:
        sys.exit("give an output .xlsx path, or pass --check-only to run the checks without writing one")

    with open(args.events_json, encoding="utf-8") as fh:
        rows = json.load(fh)
    if isinstance(rows, dict):
        rows = rows.get("events", [])

    rows = derive(rows)
    warnings = validate(rows)
    label = tz_label(args.tz, rows)
    if args.check_only:
        print(f"checked {len(rows)} events (times are {label}); no spreadsheet written")
    else:
        build(rows, args.out_xlsx, label, args.block)
        print(f"wrote {len(rows)} events to {args.out_xlsx} (times are {label})")

    lines, failures, bad = completeness(rows)
    et_reds = [(i, r) for i, r in enumerate(rows, start=2)
               if not (r.get("End Time") or "").strip()]
    if et_reds:
        print(f"{len(et_reds)} row(s) have no published End Time. Those cells "
              f"ship RED so every blank is visible, and they do not block "
              f"delivery -- an organizer that publishes no end time is a "
              f"fact, not a defect:")
        for i, r in et_reds[:25]:
            nm = (r.get("Event Name") or "<unnamed>")[:46]
            print(f"  row {i:>3}  {nm}")
        print()
    print("\nCOMPLETENESS")
    for ln in lines:
        print(ln)

    if bad:
        print("\nTHE SHEET IS NOT READY.")
        print(f"{len(bad)} of {len(rows)} rows are missing a required field.")
        print("In the spreadsheet those cells are shaded red and named in the Missing Info column.\n")
        for i, r, gaps in bad[:25]:
            nm = (r.get("Event Name") or "")[:44]
            print(f"  row {i:>3}  {nm:<46} missing: {', '.join(gaps)}")
        if len(bad) > 25:
            print(f"  ... and {len(bad) - 25} more")
        print("\n  Before browsing again, check whether the organizer simply has not")
        print("  published it. There is a valid value for each of those cases and")
        print("  a blank is not one of them:")
        print("    no price stated anywhere  -> Access = Not stated")
        print("    address given on register -> Location = Shared after registration")
        print("    venue not announced yet   -> Location = To be announced")
        print("    runs all day              -> Start Time = All day")
        print("  Otherwise the value is on the event's own page. Open it and read it.")
        print("  Go back, fill them, re-run. Do not hand this over as it is.")
    else:
        print("\nCompleteness: every row has every field it needs.")

    defects = link_defects(rows)
    if defects:
        print(f"\nLINK DEFECTS ({len(defects)}), fix before delivering:")
        for d in defects:
            print("  X", d)
        print("\n  These are structural only. A clean report here does NOT mean")
        print("  the links resolve. Wrong-event, past-event and 404 links are")
        print("  invisible here and only a page visit catches them.")

    if warnings:
        print(f"\n{len(warnings)} warning(s):")
        for w in warnings:
            print("  -", w)
    else:
        print("\nno warnings")


if __name__ == "__main__":
    main()
