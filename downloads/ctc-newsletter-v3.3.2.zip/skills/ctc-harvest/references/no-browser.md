# Collecting without the browser

Read this when the chapter log's browser answer is `No`, or when it is `Yes` and no browser can be reached in this session. A chapter collecting through the browser never needs it.

*Each reader below was tested live on single pages on 22 Nov 2026, after a first whole run for Chicago showed where the first version failed. "What was tested" at the end says exactly what was and was not.*

## What changes and what does not

Nothing about the rows changes. Every row is still written from the event's own record and never from a bare listing. The link is still the page the read landed on. `page_checks` is still filled on every record. A row with no date read from the event's own record is still never written.

What changes is the reader for each platform. A plain fetch does not run a page's scripts, so a calendar whose events load by script looks empty. **An empty-looking page is never reported as an empty source.** Every source ends the sweep with one of four results, and the review names every source that is not `read` or `empty`:

| Result | Means |
|---|---|
| `read` | The source's own list of events was read, with dates |
| `empty` | The source itself says nothing is coming up, or its complete feed holds nothing in the window |
| `partial` | Events were found by a route that can miss some, such as a search |
| `unread` | Nothing could be read, with the cause: no feed found, blocked, events load by script |

Fetches can be split across subagents as before. Connector calls run one at a time. Never try to reach an event site from the sandbox shell; it cannot.

## Use the reader that worked last time

The source list's `notes` column remembers how each source is read without the browser:

- `feed: <address>` is a calendar feed for that source. Fetch it first and skip the search for one.
- `reader: <what worked>` records anything else that worked, such as `reader: page 2 at ?page=2`.

When a run finds a feed or a working route for a source that has no such note, add the note and save the source list after the run. That is not a change to the chapter's sources, so it needs no approval; say in the run report which notes were added.

## The readers

| Platform | Enumerate (Step 1) | Event detail (Step 3) |
|---|---|---|
| Luma | The calendar's own feed: every event, with start and end times | The feed record, plus the event's page for price and status |
| Eventbrite | Plain fetch of the organizer page | Plain fetch of the event page |
| Web sources | Plain fetch, then the feed ladder below when the page loads its events by script | Plain fetch of the event page |
| Submission form | The Airtable connector | By the platform of each submitted link |

### Luma

A plain fetch of a Luma calendar page shows few or no events, and no dates. Do not read events from it. Every Luma calendar publishes a subscription feed that holds all of its events, and that is the reader.

1. **Find the calendar's id.** Use the `feed:` note if the source list has one. Otherwise plain fetch the calendar page and ask for any identifier starting with `cal-`; it sits in the page's app tag as `luma://calendar/cal-...`. If the page does not give it, a Luma connector's lookup on the calendar's address returns it. If neither does, ask the lead once to open the calendar, choose its subscribe or add-to-calendar option, and paste the link; the source is `unread` until then.
2. **Fetch the feed** at `https://api.lu.ma/ics/get?entity=calendar&id=<cal-id>` and record that address as the source's `feed:` note. It is a standard calendar feed holding the calendar's whole history, oldest first, so ask only for events starting on or after today. A long feed arrives in parts: read on to the end, because the upcoming events are last. A feed that is read to its end and holds nothing in the window is `empty`. A feed that cannot be fetched is `unread`.
3. **Each event in the feed carries** its name, start and end in UTC, its location (a venue and street address, or a registration link when the event is hosted somewhere else), the host's name, the description, and usually the event's own Luma link inside the description. Write the start into the candidate's `start` field in `candidates.json` and the event's own link as its `url`, so `plan_candidates.py` windows and dedupes exactly as in a browser run.
4. **Read each date twice.** The fetch returns a reading of the feed, not the feed itself, and a long feed is where a time gets copied wrong. After the first read, fetch the feed again and ask only for the start and end of each event kept, by name. Where the two reads disagree, read a third time; a row whose time will not settle is named in the report.
5. **For each event in `plan.json`,** the row's date, times, location, host and description come from its feed record. Then plain fetch the event's own page for the price and registration status, and to confirm the name; that address is the `landed_url`. Where the session has a Luma connector, its event read returns the same facts plus the event's own timezone, and is the better second read.

**Watch for:**
- Feed times are UTC and the feed gives no timezone. Convert with the city's zone from the settings file. An online event run from another zone still converts to the city's time.
- Every event in the feed is marked tentative. That is how Luma writes the feed and says nothing about whether the event is on. A cancellation shows on the event's page.
- An event hosted somewhere else has its registration link as the location and the calendar's address, not its own, in the description. Its own page is that registration link: fetch it, and if it shows no date, keep the feed's date and say so in the report.
- Multi-city calendars put every city in one feed. Filter on the event's location against the scope rule, as in a browser run.
- The price is not in the feed. With none on the event's page, `Access = Not stated`, never `Free` by default.

Every other "Watch for" note under Luma in `platform-notes.md` still applies.

### Eventbrite

**Organizer pages read by plain fetch.** An organizer with upcoming events lists each one's name, its own link, and its day and time, without the year. That is the enumeration: take every listed event as a candidate. Work out the year as the next date on or after today that falls on the listed weekday, and write that as the candidate's `start`, so the planner can window it; the event page then gives the full date and settles it.

**Event pages read well.** A plain fetch returns start and end with their UTC offset (the page carries them as event tags), the venue, street address, organizer, and whether the event has ended. Price is not always there.

**An organizer page that lists nothing** is usually telling the truth, and sometimes says so ("Nothing planned right now"). When it shows no events and no such message, make one cheap check before calling it `empty`: search the web for the organizer's name with "Eventbrite" and this month, and open any `eventbrite.com/e/` link that turns up, keeping an event only if its page names the registered organizer and its date is in a window. Nothing found: the organizer is `empty`. An event found that the organizer page did not list: keep it, mark the organizer `partial`, and say so in the review.

A plain fetch shows the first screen of an organizer's events. An organizer with more than about a dozen upcoming may be cut short; say so for that source.

### Web sources

A page that reads by plain fetch is unchanged. When the events sit behind a "Load more" button, or the page loads them by script and comes back as a shell, work down this ladder and record what worked as a `feed:` or `reader:` note:

1. **A feed link on the page itself.** Ask the fetch for any link to a calendar feed, RSS feed, "subscribe", "export" or "add to calendar".
2. **The site's standard feed address.** Many event calendars answer at the events address with `?ical=1` added, or at `/feed/`.
3. **A second page by address.** `?page=2`, `/page/2/`, or a month in the address. Read on until a page adds nothing new.
4. **A list view** in place of a calendar grid, where the page offers one.

Nothing on the ladder works: the source is `unread`, with "events load by script" as the cause.

**A site that refuses the fetch** (an error page, a block, a registration wall) is `unread`, with "blocked" as the cause. Do not look for another way in. When it is an event's registration page that refuses, keep the row if its date came from the source's own listing, and say the registration page could not be checked.

### The submission form

The Airtable connector reads it with no browser. Without the connector it cannot be read in this mode. Say so in the review; never report zero submissions for a form that was not read.

## `page_checks` without a browser

| Field | True when |
|---|---|
| `is_this_event` | The event page's name matches the candidate's |
| `date_matches` | The date on the event's page, or in its feed record, equals the listing date |
| `not_passed` | The start is on or after today, and the page does not say ended or cancelled |
| `landed_url` | The final address of the event page fetch |

## The verifier

The by-eye opens in `verifier.md` become a second read of the same rows through the same reader: three Luma rows, three Eventbrite rows, every submitted row, every row the check script warned about. Convert each start time in code and compare it with the cell. Say in the report that the time check was made against data and not a rendered page.

## Building the source list

`ctc-source-map` verifies candidates the same way, and writes the notes the weekly run will use:

- **A Luma calendar.** Find its feed as above and record the `feed:` note. Gate 1 is the feed loading. Gates 2 and 3 are read straight off the feed, which holds past events too: an event in the last 90 days, and a repeating pattern. It is `auto`.
- **An Eventbrite organizer.** Plain fetch the organizer page. It is `auto` if it listed dated events on this visit. An organizer with nothing listed today is checked against Gate 2 by the web search above; with no recent event found it is `unverified`, never dropped for that alone.
- **A web source.** `auto` only if a plain fetch, or a rung of the ladder, returned dated events on this visit; record the rung. Otherwise `manual`.

`method` has to be honest for this chapter's way of collecting. A source this mode cannot read reliably is not `auto`, whatever it would be through a browser.

**Tell the lead the count when they read the source list:** how many sources read fully, how many only partly (name them), and how many not at all (name them). They decide then whether that is enough, or whether to paste the gaps each week or collect through the browser.

## What the lead is told each week

The review message and the run report open with one line, "Collected without the browser this week," followed by:

- how many of the registered sources were `read` or `empty`;
- every `partial` source, by name, with one line that a search may have missed events there;
- every `unread` source, by name, with the cause;
- one closing line: "If you know of an event from any of these, paste its link in your reply and I will add it."

If more than a third of the registered sources are `partial` or `unread`, say plainly that the list is likely thin, and give the count. Never estimate how many events were missed.

The LinkedIn tier of `ctc-opportunities` needs the lead's signed-in browser and is skipped in this mode.

## Scheduled runs

A scheduled run collects under the same rules. It asks nothing, pastes nothing, and names what it could not read.

## What was tested

Live, 22 Nov 2026, one page or record each:

| Read | Result |
|---|---|
| Luma calendar page, plain fetch | No dates. One calendar gave ten names and slugs; another gave no events at all. The calendar's `cal-` id was in the page's app tag |
| Luma calendar feed, plain fetch | Two calendars. 150 events, complete: name, start and end (UTC), location, host, description. A 195-event feed arrived in parts |
| Luma event page, plain fetch | Name, host, price, area. No date or time |
| Luma connector, lookup and public event read | Id, start and end, timezone, hosts, ticket info, description, canonical address |
| Eventbrite event page, plain fetch | Start and end with offset, venue, address, organizer, ended status. No price |
| Eventbrite organizer page, plain fetch | Three organizers. One with events listed all three, with names, links, days and times, no year. Two with nothing upcoming listed nothing; one of those said so |
| Eventbrite city listing search, plain fetch | Readable, but loosely matched and mostly unrelated. Not used as a reader |
| Sandbox shell to luma.com | Refused |

Not tested: an Eventbrite organizer with more than one screen of events; the web feed ladder on a live "Load more" page; a whole run with these readers; a scheduled run in this mode; whether every account's fetch tool will open a feed address it built itself.
