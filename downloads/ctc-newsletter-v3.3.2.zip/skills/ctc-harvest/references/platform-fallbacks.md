# Platform fallbacks

Read this only when the planner prints `PLATFORM READ LOOKS BROKEN`, the first-batch check in SKILL.md Step 3 fails, or no browser is available. A normal week never needs it.

## When a platform read looks broken

The helpers read Luma and Eventbrite from the pages' own structured data, and those pages change without notice. When they do, the failure is quiet: a calendar comes back `ok` with no events, or events come back with no dates. Two checks catch it early, the planner's `PLATFORM READ LOOKS BROKEN` line and the first-batch check in SKILL.md Step 3. When either fires:

1. **Look at one source by eye.** Open one registered calendar or organizer of that platform in the tab. If the page itself shows no upcoming events, the read was right and the week is quiet for that source; check a second one before believing it for the whole platform.
2. **If the page shows events the helper did not return, the page shape moved.** Do not run the remaining batches. Fall back, in this order:
   - the direct `__NEXT_DATA__` read shown under Luma above, one calendar at a time;
   - reading the rendered page: navigate to each calendar, read the page text for each event's name and link, then open each event page and read its date, time and address from what is on screen. Slower, and it is the same information;
   - for a source that will not read either way, ask the lead to open it and paste the page, and record the failure.
3. **Say so in the run report**, by platform: that the structured read failed, which fallback was used, and that the toolkit's helper needs updating. That last line is for the Climate Tech Cities team, and the lead should pass it on.

A fallback read fills the same rows under the same rules: every event's own page, no constructed links, `page_checks` on every record. Never ship a thin sheet without saying why it is thin.

## When the browser is not available

A chapter can collect without the browser, and `no-browser.md` in this folder says how: Luma calendars are read from their own feeds, plain fetches read Eventbrite event pages and the web sources, and an Airtable connector reads the submission form. Read it and follow it. Do not stop the run.

It is a real way to collect, and it is not a free one. Every source that could not be read without the browser is named in the review. A lead whose list keeps coming back thin has two ways to fix it, in order:

1. **Collect through the browser**: install the Claude in Chrome extension, or run the newsletter from the Claude desktop app, which has a browser built in, and say "use my browser from now on". This is the most complete read.
2. **Paste the sources that will not read.** Workable for a handful, miserable at twenty.

Never ship a thin sheet without saying why it is thin.
