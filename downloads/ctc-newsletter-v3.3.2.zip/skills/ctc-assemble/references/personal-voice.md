# The lead's own voice

A chapter lead can give Claude samples of their writing. Claude turns them into one short file, `CTC_Voice_<City>.md`, saves it to the lead's project, and from then on drafts the three personal blocks (opening note, picks, housekeeping) the way that lead writes instead of in the generic house voice.

This is optional and strongly recommended. A lead who skips it gets drafts in the house voice from `voice.md`, exactly as before.

**It does not replace the rewrite.** The yellow `[REWRITE IN YOUR OWN WORDS, then delete this line]` lines stay on all three blocks. A style file can match how someone sounds. It cannot know what they think of this week's events, and that is what readers subscribe for. The file's job is to hand the lead a draft that needs a light edit instead of a full rewrite.

## When to build it

| Moment | What to do |
|---|---|
| The chapter's first run | `ctc-newsletter-cycle` asks for samples in its one setup message. If they come, build the file before the first issue |
| The lead says "learn my writing style", "here are my writing samples", or similar, at any time | Build it then |
| The chapter log says `Not asked` (a chapter that started before this existed) | The review message asks once. If samples come back in the reply, build the file before building the issue |
| The lead declined | Record `no`. Do not ask again. Mention once, when the first issue is delivered, that they can say "learn my writing style" whenever they like |
| The lead sends more samples, or pastes the final version of an issue they edited | Update the file (see "Keeping it current") |

Record the outcome in the chapter log so the question is never asked twice: `chapter_log.py set voice yes` once the file is built, `set voice no` if they decline.

## Asking for samples

Use close to these words, as one item in whatever message is already going out. Never as a separate question of its own, and never as a blocker.

> **Your writing (optional, and worth doing).** Paste three to five things you have written that sound like you: past newsletter notes, LinkedIn posts, emails to a group, anything in your normal voice. I will learn how you write and draft the personal parts of each issue to match, so you edit instead of starting over. Short is fine.

Accept pasted text or attached files. If they point at a public page, read it. Never go looking for their writing without being asked, and never read their email or their LinkedIn for this.

## What makes a usable set

| What they gave | What to do |
|---|---|
| Three or more samples, a few hundred words in all | Build the file |
| One or two short samples | Build it, and say plainly in section 6 and to the lead that it is thin and will sharpen with more |
| Under about 100 words in total | Too little to describe a voice. Say so, keep what they sent for when more arrives, and draft in the house voice for now |
| Writing that is clearly someone else's (a newsletter they admire) | Ask whether they want to sound like that or like themselves. Build only from what they confirm |
| Formal writing only (a report, a grant application) | Build it, and note in section 6 that the samples are formal and a newsletter note is conversational; ask for one casual sample |

## How to read the samples

Describe what is on the page. Do not describe the person.

- **Write only what the samples show.** A pattern goes in when it appears in at least two samples, or it is marked "seen once". Never infer personality, values or background.
- **Be specific enough to imitate.** "Warm and direct" could be anyone. "Opens with one short sentence about the weather or the week, then gets to the point in the second" can be followed.
- **Look for:** how they open and close; sentence length and whether they mix short with long; contractions; first person singular or plural; how they address the reader; punctuation habits (dashes, parentheses, exclamation marks, ellipses); humor and what kind; how they recommend something; words and phrases they reach for; things they conspicuously never do.
- **No flattery.** The file is a working document, not a review of their writing.
- **Quote them exactly.** Section 5 holds three to six short excerpts, each under about 40 words, copied character for character. These do more than any description.
- **Do not store the samples themselves.** The file holds patterns and short excerpts only. It lives in the project and is read every week, so keep it under about 700 words.

## The file

Write it in exactly this shape. `chapter_files.py voice-check` confirms the shape before it is saved.

```markdown
# Climate Tech <City>: how <Lead first name> writes
<!-- ctc-file: voice v3 -->

City: <City>
Lead: <Lead name>
Built from: <N> samples (<what they were, e.g. 2 newsletter notes, 1 LinkedIn post, 1 email>)
Last updated: <YYYY-MM-DD>

Claude drafts the opening note, the picks and the housekeeping in this voice. To change it, send more writing or tell Claude what to change.

## 1. How they sound
<five to eight bullets, each an observable pattern someone could imitate>

## 2. Openings and sign-offs
<how they greet, how they start the first paragraph, how they close>

## 3. Words and phrases they use
<their recurring words, phrases, and ways of recommending something>

## 4. Things they never do
<what is absent from every sample: e.g. no exclamation marks, never says "excited">

## 5. In their own words
<three to six short excerpts, each on its own line as a quote, copied exactly>

## 6. What the samples do not show
<gaps: e.g. no sample of them recommending an event; only formal writing; thin set>
```

Then:

```bash
python3 $SKILL/../ctc-newsletter-cycle/scripts/chapter_files.py voice-check CTC_Voice_<City>.md
python3 $SKILL/../ctc-newsletter-cycle/scripts/chapter_log.py set CTC_Chapter_Log_<City>.md voice yes
```

Save the voice file and the log to the project (`../../ctc-newsletter-cycle/references/chapter-files.md`). Tell the lead in two or three lines what you picked up, in plain words, and that they can correct any of it. A worked example is `sample-output/CTC_Voice_SAMPLE.md`.

## Drafting with it

When `CTC_Voice_<City>.md` is in the project, read it before drafting blocks 2, 3 and 4, and draft them the way that lead writes.

**It applies to three blocks only.** Opening note, picks, housekeeping. The event descriptions in block 9, the opportunities, the subtitle and every listing stay in the house voice, so listings read the same in every chapter.

**Where the two files disagree:**

| Question | Which file decides |
|---|---|
| Greeting, sentence rhythm, vocabulary, humor, how they recommend something, how they close a paragraph | The lead's voice file |
| The sign-off line | The settings file |
| The shape and length of each block (`voice.md` section 6: the opening note's two paragraphs, one pick bullet per day) | The house voice |
| The banned words and constructions (`voice.md` section 5), including em dashes | The house voice. If the lead uses a banned construction in their own samples, do not imitate that one habit; they can add it back when they rewrite |
| Facts: no invented weather, news, verdicts or reasons for excitement | The house rules, always. A voice file never licenses a claim |

**Imitate the pattern, never reuse the excerpt.** The quotes in section 5 are there to hear the voice. Do not lift a sentence from them into a draft.

**Do not overdo it.** A habit that appears once per sample appears about once per issue. A draft that uses every listed phrase reads as a parody of the lead, which is worse than the house voice.

**The markers stay.** Every drafted block still carries its yellow line.

## Keeping it current

- **More samples:** fold them in, update `Built from` and `Last updated`, re-run the check, save.
- **The lead pastes the issue as they sent it:** compare their three blocks with the drafts. What they consistently changed is the most reliable evidence there is. Add those patterns, with one or two new excerpts replacing weaker ones. Keep the file under its length limit.
- **The lead says a draft does not sound like them:** ask what was off, change the file to match, and say what you changed.
- Never rebuild from nothing when a file exists.
