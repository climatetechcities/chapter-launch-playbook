# Issue verifier

A second pass over the issue before it goes to the lead. The scripts have already settled the mechanical questions: `draft_issue.py verify` proved the listings match the rows the lead kept, and `issue_checks.js` proved every date, weekday, day word and deadline. This pass covers what a script cannot: a link that resolves to the wrong page, a description that quietly editorializes, and a draft that states something nobody told it.

## How to run it

Three parts, in this order.

**Part 1, the scripts.** All three must have run clean on the `issue.json` being delivered, after its last edit:

```
python3 $SKILL/scripts/draft_issue.py verify issue.json events_final.json
node $SKILL/scripts/build_issue_html.js issue.json <out.html>
node $SKILL/scripts/check_voice.js issue.json
```

No `ISSUE DOES NOT MATCH`, no `DATE CHECKS FAILED`, nothing left under `CHECK BEFORE DELIVERING`. The voice checker reads the banned list from `references/voice.md` section 5, so the list lives in one place. Fix every hit in `issue.json`, rebuild, re-run. A hit inside a fixed block is impossible (the scripts insert those); a hit inside an event title is the organizer's wording and stays.

**Part 2, the links.** `draft_issue.py verify` prints `NOT RE-CHECKED` for any listed row with no link re-check on record. Every listed row was fetched again before the build and compared with its row (SKILL.md, "Re-check every link that ships"), or is named in the delivery message as not re-checked. Then open, by eye, in the tab: every row the re-check changed, and three listed rows chosen at random, at least two of them from Upcoming. Confirm the page is that event on that date. In one reviewed issue every one of fourteen link failures was in Upcoming.

**Part 3, the fresh read.** Run this as a pass with no memory of the assembly. If the session has a subagent or task tool, launch one with exactly this file, the built `.html`, `events_final.json`, the lead's reply, the settings file, and the lead's voice file if there is one, and nothing else. If it does not, run it yourself as a separate step: read this file, open the HTML cold, and read it as a subscriber and then as an editor.

## Checks for the fresh read

**Structure.** Ten blocks in this order: title and subtitle; opening note; picks; housekeeping and sign-off; platforms block; opportunities; This Week's Events; Upcoming Events; This Week in Detail; Join the fun. The platforms block follows the sign-off directly. Join the fun is the last thing on the page.

**Descriptions.** Every block 9 description is the row's description, tidied, not rewritten: nothing in it that is not in the row. Any venue or neighborhood named in a pick is in that row's Location or City / Neighborhood.

**Editorial blocks.** Each of blocks 2, 3, and 4 has the marker line directly above it, exactly `[REWRITE IN YOUR OWN WORDS, then delete this line]`. The greeting is above the marker, not inside it. Nothing in the drafts states a fact the lead did not give or that is not in the rows: no weather, no local news, no verdict on an event, no reason for excitement. Where the draft says something about the city, find where it came from.

**Voice.** If the project holds `CTC_Voice_<City>.md`, read blocks 2, 3 and 4 against it: they should sound like that lead (their greeting, their rhythm, their way of recommending), use no sentence lifted from the file's excerpts, and not pile every listed habit into one note. Blocks 6 and 9 stay in the house voice regardless. Then read blocks 2, 3, 4, 6, and 9 against `voice.md` sections 2 and 5. The checker catches words; this catches patterns: three adjectives in a row, a why-you-should-care closing sentence, a summary sentence, a metaphor carried past two sentences, a promise about the reader's feelings.

**Opportunities.** Each one is an entry the lead chose (or one of the proposed three, if they chose none), with the list's description and the deadline line from `open.json`.

**Subtitle.** Names the picks, closes with "and more upcoming events", sentence case except proper nouns.

## What to report

A short list: what was fixed, what the link re-check changed or dropped, any row not re-checked, what was flagged for the lead (with the block and the reason), and a one-line verdict. Then deliver the `.html`.
