/**
 * issue_checks.js -- date and deadline checks for an assembled issue.
 *
 * Both build scripts call runChecks(issue) before writing anything. A FAIL
 * stops the build: nothing is written until issue.json is fixed. A FLAG is
 * printed under CHECK BEFORE DELIVERING and the file is still written.
 *
 * These are the errors readers punish and a person misses: an event that has
 * already happened, a deadline that has lapsed, "Wednesday, Aug 12" on a date
 * that is a Thursday, "Tomorrow" on an event three days out. They are checked
 * here by arithmetic, never by eye.
 *
 * What issue.json has to carry for this to work (see SKILL.md, "issue.json"):
 *   send_date                         "2026-08-11"
 *   cadence                           "weekly" (default) or "biweekly"
 *   this_week[].date                  ISO date of that day header
 *   upcoming[].date_iso               ISO date of that event
 *   this_week_in_detail[].date_iso    ISO date of that event
 *   picks[].date_iso                  ISO date of the events in that bullet
 *   opportunities[].deadline_date     ISO date, or "Rolling", or "Unconfirmed"
 *
 * Standalone:  node issue_checks.js issue.json     (exit 1 on any FAIL)
 */

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const ISO = /^\d{4}-\d{2}-\d{2}$/;

function parse(s) {
  if (typeof s !== 'string' || !ISO.test(s)) return null;
  const [y, m, d] = s.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d));
  // Reject dates that do not exist, such as 2026-02-30.
  if (t.getUTCFullYear() !== y || t.getUTCMonth() !== m - 1 || t.getUTCDate() !== d) return null;
  return t;
}
const addDays = (t, n) => new Date(t.getTime() + n * 86400000);
const diff = (a, b) => Math.round((a.getTime() - b.getTime()) / 86400000);
const dayHeader = t => `${DAYS[t.getUTCDay()]}, ${MON[t.getUTCMonth()]} ${t.getUTCDate()}`;
const shortDate = t => `${MON[t.getUTCMonth()]} ${t.getUTCDate()}`;
const iso = t => t.toISOString().slice(0, 10);

function runChecks(issue) {
  const fails = [];
  const flags = [];
  const send = parse(issue.send_date);
  if (!send) {
    fails.push(`send_date is missing or not a real YYYY-MM-DD date ("${issue.send_date || ''}"). Every date check hangs off it.`);
    return { fails, flags };
  }
  const biweekly = String(issue.cadence || 'weekly').toLowerCase().startsWith('bi') ||
    /two weeks/i.test(String(issue.cadence || ''));
  const week = biweekly ? 14 : 7;
  const thisEnd = addDays(send, week - 1);
  const upEnd = addDays(send, (biweekly ? 42 : 28) - 1);

  // Title window: "Chapter: Aug 11 - Aug 18" starts on the send date.
  const tm = /:\s*([A-Z][a-z]{2} \d{1,2})\s*-\s*([A-Z][a-z]{2} \d{1,2})\s*$/.exec(String(issue.title || ''));
  if (!tm) {
    flags.push(`Title "${issue.title}" does not end in the house window form ": Aug 11 - Aug 18".`);
  } else {
    if (tm[1] !== shortDate(send)) fails.push(`Title window starts "${tm[1]}" but the send date is ${shortDate(send)} (${issue.send_date}).`);
    const wantEnd = shortDate(addDays(send, 7));
    if (!biweekly && tm[2] !== wantEnd) flags.push(`Title window ends "${tm[2]}"; for a weekly issue sent ${shortDate(send)} it reads "${wantEnd}".`);
  }

  // This Week's Events.
  let prev = null;
  const thisWeekDates = new Set();
  (issue.this_week || []).forEach(d => {
    const t = parse(d.date);
    if (!t) { fails.push(`This Week day "${d.day}" has no ISO "date". Add it so the day can be checked.`); return; }
    thisWeekDates.add(d.date);
    if (d.day !== dayHeader(t)) fails.push(`Day header "${d.day}" does not match its date ${d.date}, which is "${dayHeader(t)}".`);
    if (t < send) fails.push(`This Week has ${d.day} (${d.date}), which is before the send date ${issue.send_date}. A past event cannot ship.`);
    else if (t > thisEnd) flags.push(`${d.day} (${d.date}) is past the this-week window, which ends ${iso(thisEnd)}. It belongs in Upcoming.`);
    if (prev && t <= prev) flags.push(`This Week days are out of order at "${d.day}".`);
    prev = t;
    if (!(d.events || []).length) flags.push(`Day header "${d.day}" has no events under it.`);
  });

  // Upcoming Events.
  prev = null;
  (issue.upcoming || []).forEach(e => {
    const t = parse(e.date_iso);
    if (!t) { fails.push(`Upcoming "${e.title}" has no ISO "date_iso". Add it so the date can be checked.`); return; }
    if (e.date !== shortDate(t)) fails.push(`Upcoming "${e.title}" prints "${e.date}" but its date is ${e.date_iso}, which is "${shortDate(t)}".`);
    if (t < send) fails.push(`Upcoming "${e.title}" is dated ${e.date_iso}, before the send date. A past event cannot ship.`);
    else if (t <= thisEnd) flags.push(`Upcoming "${e.title}" (${e.date_iso}) falls inside the this-week window. It belongs in This Week's Events, with a detail entry.`);
    else if (t > upEnd) flags.push(`Upcoming "${e.title}" (${e.date_iso}) is past the upcoming window, which ends ${iso(upEnd)}.`);
    if (prev && t < prev) flags.push(`Upcoming is out of date order at "${e.title}".`);
    prev = t;
  });

  // This Week in Detail.
  (issue.this_week_in_detail || []).forEach(e => {
    const t = parse(e.date_iso);
    if (!t) { fails.push(`Detail entry "${e.title}" has no ISO "date_iso".`); return; }
    if (e.when !== dayHeader(t)) fails.push(`Detail entry "${e.title}" says When "${e.when}" but its date ${e.date_iso} is "${dayHeader(t)}".`);
    if (!thisWeekDates.has(e.date_iso)) flags.push(`Detail entry "${e.title}" is dated ${e.date_iso}, a day with no header in This Week's Events.`);
    if (!String(e.where || '').trim()) flags.push(`Detail entry "${e.title}" has an empty Where line.`);
    if (!String(e.description || '').trim()) flags.push(`Detail entry "${e.title}" has no description.`);
  });

  // Picks: the day word has to be true on the send date.
  (issue.picks || []).forEach(p => {
    const t = parse(p.date_iso);
    const word = String(p.day || '').trim();
    if (!t) { fails.push(`Pick bullet "${word}" has no ISO "date_iso". Add the date of the events in that bullet.`); return; }
    const n = diff(t, send);
    if (n < 0) { fails.push(`Pick bullet "${word}" is dated ${p.date_iso}, before the send date.`); return; }
    const weekday = DAYS[t.getUTCDay()];
    let want;
    if (n === 0) want = ['Today', weekday];
    else if (n === 1) want = ['Tomorrow', weekday];
    else if (n < 7) want = [weekday];
    else if (n < 14) want = biweekly ? [`Next ${weekday}`, dayHeader(t)] : [`Next ${weekday}`];
    else want = [dayHeader(t)];
    if (!want.includes(word)) fails.push(`Pick bullet says "${word}" but its date ${p.date_iso} is ${n} day(s) after the send date; the day word is "${want[0]}".`);
  });

  // Opportunities: no lapsed deadline, ever.
  (issue.opportunities || []).forEach(o => {
    const raw = String(o.deadline_date == null ? '' : o.deadline_date).trim();
    if (/^(rolling|unconfirmed)$/i.test(raw)) return;
    const t = parse(raw);
    if (!t) { fails.push(`Opportunity "${o.title}" has no "deadline_date" (an ISO date, "Rolling", or "Unconfirmed").`); return; }
    if (t < send) fails.push(`Opportunity "${o.title}" closed on ${raw}, before the send date ${issue.send_date}. Drop it.`);
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const re = new RegExp('\\b(' + months.join('|') + ')\\s+(\\d{1,2})\\b');
    const same = m => m && months.indexOf(m[1]) === t.getUTCMonth() && Number(m[2]) === t.getUTCDate();
    const inLine = re.exec(String(o.deadline || ''));
    const inTitle = re.exec(String(o.title || ''));
    const want = `${months[t.getUTCMonth()]} ${t.getUTCDate()}`;
    if (inLine && !same(inLine)) fails.push(`Opportunity "${o.title}" prints "${inLine[0]}" but its deadline_date is ${raw}, which is ${want}.`);
    else if (!inLine && !same(inTitle)) flags.push(`Opportunity "${o.title}" has a dated deadline (${raw}) but does not print it. The house form is "Applications due ${want}."`);
  });

  // One link, one listing.
  const seen = new Map();
  const note = (url, where) => {
    const u = String(url || '').trim().replace(/\/+$/, '').toLowerCase();
    if (!u) { flags.push(`A listing in ${where} has no link.`); return; }
    if (seen.has(u) && seen.get(u) !== where) flags.push(`The same link is listed in both ${seen.get(u)} and ${where}: ${url}`);
    else if (seen.has(u)) flags.push(`The same link is listed twice in ${where}: ${url}`);
    seen.set(u, where);
  };
  (issue.this_week || []).forEach(d => (d.events || []).forEach(e => note(e.url, "This Week's Events")));
  (issue.upcoming || []).forEach(e => note(e.url, 'Upcoming Events'));

  return { fails, flags };
}

/** Print the result. Returns true when the build may go ahead. */
function report(issue) {
  const { fails, flags } = runChecks(issue);
  if (fails.length) {
    console.error('DATE CHECKS FAILED. Nothing was written. Fix issue.json and run again:');
    fails.forEach(f => console.error('  X ' + f));
  } else {
    console.log(`date checks: passed for send date ${issue.send_date}`);
  }
  if (flags.length) {
    console.log('CHECK BEFORE DELIVERING (dates):');
    flags.forEach(f => console.log('  ! ' + f));
  }
  return fails.length === 0;
}

module.exports = { runChecks, report };

if (require.main === module) {
  const fs = require('fs');
  const p = process.argv[2];
  if (!p) { console.error('usage: node issue_checks.js issue.json'); process.exit(1); }
  process.exit(report(JSON.parse(fs.readFileSync(p, 'utf8'))) ? 0 : 1);
}
