#!/usr/bin/env python3
"""
draft_issue.py -- write the listing blocks of issue.json straight from the
rows the lead kept, so no event name, link or date is ever retyped.

  python3 draft_issue.py start events_final.json issue.json \
        --send-date YYYY-MM-DD --chapter "Portland Climate Tech" [--cadence biweekly]

    Writes issue.json with the title, send_date, cadence, This Week's Events,
    Upcoming Events and This Week in Detail filled in from the rows, every
    date in both its printed and its ISO form. It applies the recurring-event
    rule (an event listed on several dates appears once, at its earliest).
    It also writes "_picks_to_write": one entry per row the lead picked, with
    the correct day word, for the picks block.

    Before running it, put an "Emoji" on every row (house-style.md section 3).
    Still to write by hand afterwards: subtitle, opening_note, picks_intro,
    picks, housekeeping, signoff, opportunities.

  python3 draft_issue.py verify issue.json events_final.json

    Run after the editorial blocks are written and before building. Confirms
    every kept row is in the issue with its own name, link and date, nothing
    is in the issue that the lead did not keep, every this-week event has its
    detail entry with the sheet's description, and every pick the lead chose
    is in the picks block. Exit 1 on any mismatch.
"""
import argparse
import json
import re
import sys
from datetime import date, timedelta

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def day_header(d):
    return f"{DAYS[d.weekday()]}, {MON[d.month - 1]} {d.day}"


def short(d):
    return f"{MON[d.month - 1]} {d.day}"


def load_rows(path):
    data = json.load(open(path, encoding="utf-8"))
    return data["events"] if isinstance(data, dict) else data


def is_pick(r):
    return r.get("Pick") is True or str(r.get("Pick", "")).strip().lower() in ("true", "yes", "pick")


def norm(s):
    s = re.sub(r"[^a-z0-9 ]+", " ", str(s or "").lower())
    return re.sub(r"\s+", " ", s).strip()


def title_of(r):
    name = str(r.get("Event Name") or "").strip()
    emoji = str(r.get("Emoji") or "").strip()
    return f"{emoji} {name}".strip()


def where_of(r):
    if str(r.get("Event Type") or "").strip().lower() == "online":
        return "Online"
    return str(r.get("Location") or "").strip()


def day_word(d, send, biweekly):
    n = (d - send).days
    if n == 0:
        return "Today"
    if n == 1:
        return "Tomorrow"
    if n < 7:
        return DAYS[d.weekday()]
    if n < 14:
        return f"Next {DAYS[d.weekday()]}"
    return day_header(d)


def sort_key(r):
    return (r["_d"], str(r.get("Start Time") or "99:99"), norm(r.get("Event Name")))


def prepare(rows, send, biweekly):
    week = 14 if biweekly else 7
    this_end = send + timedelta(days=week - 1)
    up_end = send + timedelta(days=(42 if biweekly else 28) - 1)
    problems = []
    for r in rows:
        try:
            r["_d"] = date.fromisoformat(str(r.get("Date") or "")[:10])
        except ValueError:
            problems.append(f"{r.get('Event Name')}: Date '{r.get('Date')}' is not YYYY-MM-DD")
            continue
        if not str(r.get("Registration Link") or "").strip():
            problems.append(f"{r.get('Event Name')}: no Registration Link; a listing with no link cannot ship")
        if not str(r.get("Emoji") or "").strip():
            problems.append(f"{r.get('Event Name')}: no Emoji; give every row one before drafting")
        want = "this_week" if send <= r["_d"] <= this_end else "upcoming" if this_end < r["_d"] <= up_end else None
        if r["_d"] < send:
            problems.append(f"{r.get('Event Name')} ({r.get('Date')}): before the send date; drop it")
        elif want is None:
            problems.append(f"{r.get('Event Name')} ({r.get('Date')}): past the upcoming window, which ends {up_end}")
        elif str(r.get("Block") or "").strip() != want:
            problems.append(f"{r.get('Event Name')} ({r.get('Date')}): Block is '{r.get('Block')}' but the date "
                            f"puts it in {want}")
    return this_end, up_end, problems


def split(rows):
    tw = sorted([r for r in rows if r.get("Block") == "this_week"], key=sort_key)
    up_all = sorted([r for r in rows if r.get("Block") == "upcoming"], key=sort_key)
    # Recurring rule: same name and same host is one series. It appears once,
    # at its earliest date; if that date is this week, it is not in Upcoming.
    series = lambda r: (norm(r.get("Event Name")), norm(r.get("Host Organization(s)")))
    seen = {series(r) for r in tw}
    up, held = [], []
    for r in up_all:
        k = series(r)
        if k in seen:
            held.append(r)
        else:
            seen.add(k)
            up.append(r)
    return tw, up, held


def cmd_start(a):
    rows = load_rows(a.events)
    send = date.fromisoformat(a.send_date)
    biweekly = a.cadence == "biweekly"
    _, _, problems = prepare(rows, send, biweekly)
    if problems:
        print("FIX events_final.json FIRST. Nothing was written:", file=sys.stderr)
        for p in problems:
            print("  X " + p, file=sys.stderr)
        sys.exit(1)
    tw, up, held = split(rows)
    this_week = []
    for r in tw:
        hdr = day_header(r["_d"])
        if not this_week or this_week[-1]["day"] != hdr:
            this_week.append({"day": hdr, "date": r["_d"].isoformat(), "events": []})
        this_week[-1]["events"].append({"title": title_of(r), "url": r["Registration Link"].strip()})
    issue = {
        "send_date": send.isoformat(),
        "cadence": "biweekly" if biweekly else "weekly",
        "title": f"{a.chapter}: {short(send)} - {short(send + timedelta(days=14 if biweekly else 7))}",
        "subtitle": "",
        "opening_note": [],
        "picks_intro": "[REWRITE IN YOUR OWN WORDS, then delete this line]",
        "picks": [],
        "housekeeping": [],
        "signoff": [],
        "opportunities": [],
        "this_week": this_week,
        "upcoming": [{"title": title_of(r), "url": r["Registration Link"].strip(),
                      "date": short(r["_d"]), "date_iso": r["_d"].isoformat()} for r in up],
        "this_week_in_detail": [{"title": title_of(r), "url": r["Registration Link"].strip(),
                                 "when": day_header(r["_d"]), "date_iso": r["_d"].isoformat(),
                                 "where": where_of(r), "description": str(r.get("Description") or "").strip()}
                                for r in tw],
        "_picks_to_write": [{"day": day_word(r["_d"], send, biweekly), "date_iso": r["_d"].isoformat(),
                             "title": title_of(r), "link": r["Registration Link"].strip(),
                             "block": r.get("Block")}
                            for r in sorted([r for r in rows if is_pick(r)], key=sort_key)],
    }
    json.dump(issue, open(a.issue, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print(f"wrote {a.issue}: {len(tw)} this week across {len(this_week)} day(s), {len(up)} upcoming, "
          f"{len(tw)} detail entries, {len(issue['_picks_to_write'])} pick(s) to write")
    if held:
        print(f"held back {len(held)} later date(s) of a recurring event (they surface in later issues):")
        for r in held:
            print(f"  - {r.get('Date')}  {r.get('Event Name')}")
    blanks = [r for r in tw if not str(r.get("Description") or "").strip()]
    for r in blanks:
        print(f"  ! no description for this-week event: {r.get('Event Name')}. Write it from the event's page.")
    nowhere = [r for r in tw if not where_of(r)]
    for r in nowhere:
        print(f"  ! no Location for this-week event: {r.get('Event Name')}.")
    late = [p for p in issue["_picks_to_write"] if p["block"] == "upcoming" and not p["day"].startswith("Next ")]
    for p in late:
        print(f"  ! pick \"{p['title']}\" is more than a week past the this-week window. Check with the lead.")
    print("still to write: subtitle, opening_note, picks, housekeeping, signoff, opportunities")


def cmd_verify(a):
    issue = json.load(open(a.issue, encoding="utf-8"))
    rows = load_rows(a.events)
    send = date.fromisoformat(issue["send_date"])
    biweekly = str(issue.get("cadence", "weekly")).lower().startswith("bi")
    _, _, problems = prepare(rows, send, biweekly)
    bad = ["events_final.json: " + p for p in problems if "no Emoji" not in p]
    tw, up, held = split([r for r in rows if "_d" in r])
    link = lambda u: str(u or "").strip().rstrip("/").lower()

    got_tw = [(link(e.get("url")), e.get("title"), d.get("date"))
              for d in issue.get("this_week") or [] for e in d.get("events") or []]
    got_up = [(link(e.get("url")), e.get("title"), e.get("date_iso")) for e in issue.get("upcoming") or []]
    for label, want_rows, got in (("This Week's Events", tw, got_tw), ("Upcoming Events", up, got_up)):
        want = {link(r["Registration Link"]): r for r in want_rows}
        got_links = [g[0] for g in got]
        for u, r in want.items():
            if u not in got_links:
                bad.append(f"{label}: the lead kept \"{r.get('Event Name')}\" ({r.get('Date')}) and it is not listed")
        for u, title, d in got:
            r = want.get(u)
            if not r:
                bad.append(f"{label}: \"{title}\" is listed but is not a row the lead kept in that block")
                continue
            name = str(r.get("Event Name") or "").strip()
            if not str(title or "").endswith(name):
                bad.append(f"{label}: title \"{title}\" does not end with the harvested name \"{name}\"")
            if d != r["_d"].isoformat():
                bad.append(f"{label}: \"{title}\" is dated {d} in the issue and {r.get('Date')} in the rows")

    detail = {link(e.get("url")): e for e in issue.get("this_week_in_detail") or []}
    for r in tw:
        e = detail.get(link(r["Registration Link"]))
        if not e:
            bad.append(f"This Week in Detail: no entry for \"{r.get('Event Name')}\"")
            continue
        if not str(e.get("description") or "").strip():
            bad.append(f"This Week in Detail: \"{r.get('Event Name')}\" has no description")
        want_where = where_of(r)
        if want_where and str(e.get("where") or "").strip() != want_where:
            bad.append(f"This Week in Detail: \"{r.get('Event Name')}\" Where reads \"{e.get('where')}\"; "
                       f"the row says \"{want_where}\"")
    for u, e in detail.items():
        if u not in {link(r["Registration Link"]) for r in tw}:
            bad.append(f"This Week in Detail: \"{e.get('title')}\" is not a this-week row the lead kept")

    listed = {g[0] for g in got_tw + got_up}
    pick_links = [link(s.get("link")) for p in issue.get("picks") or []
                  for s in p.get("segments") or [] if s.get("link")]
    for r in rows:
        if is_pick(r) and link(r.get("Registration Link")) not in pick_links:
            bad.append(f"Picks: the lead picked \"{r.get('Event Name')}\" and it is not in the picks block")
    chosen = {link(r.get("Registration Link")) for r in rows if is_pick(r)}
    for u in pick_links:
        if u not in chosen:
            bad.append(f"Picks: a pick links to {u}, which the lead did not pick")
        if u not in listed:
            bad.append(f"Picks: a pick links to {u}, which is in neither listing block")
    for key in ("subtitle", "opening_note", "signoff"):
        if not issue.get(key):
            bad.append(f"\"{key}\" is empty")
    if held:
        print(f"{len(held)} later date(s) of recurring events are correctly held back")
    listed_rows = tw + up
    unchecked = [r for r in listed_rows if not (isinstance(r.get("link_recheck"), dict) and r["link_recheck"].get("ok"))]
    if unchecked:
        print(f"NOT RE-CHECKED: {len(unchecked)} of {len(listed_rows)} listed rows have no link re-check on record. "
              f"Re-check them (SKILL.md, \"Re-check every link that ships\"), or name each one in the "
              f"delivery message:")
        for r in unchecked:
            print(f"  ! {r.get('Date')}  {r.get('Event Name')}")
    if bad:
        print("ISSUE DOES NOT MATCH THE ROWS THE LEAD KEPT. Fix before building:", file=sys.stderr)
        for b in bad:
            print("  X " + b, file=sys.stderr)
        sys.exit(1)
    print(f"issue matches the kept rows: {len(got_tw)} this week, {len(got_up)} upcoming, "
          f"{len(detail)} detail entries, {len(pick_links)} pick link(s)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("start"); p.add_argument("events"); p.add_argument("issue")
    p.add_argument("--send-date", required=True); p.add_argument("--chapter", required=True)
    p.add_argument("--cadence", default="weekly", choices=["weekly", "biweekly"]); p.set_defaults(fn=cmd_start)
    p = sub.add_parser("verify"); p.add_argument("issue"); p.add_argument("events"); p.set_defaults(fn=cmd_verify)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
