---
name: ctc-newsletter-cycle
description: Run the Climate Tech Cities weekly newsletter end to end for a city chapter, sequencing setup, the source list, the opportunities, the harvest, the lead's review, and the assembly, and stopping only where the chapter lead has to decide something. Use this skill whenever someone wants to produce this week's issue, says "run the newsletter", "let's do this week's newsletter", "start the weekly cycle", "make this week's issue for [city]", asks what to do first with their newsletter, or is a new chapter lead who has installed the toolkit and wants the whole newsletter workflow rather than one piece of it. Also use it when someone replies to a review message, is midway through the cycle and asks what comes next, reports last week's numbers, says "learn my writing style" or shares writing samples, asks to schedule or automate the newsletter, or when a scheduled run starts the weekly newsletter. Always use it even if they only mention one city or one week. Do NOT use it for partners, which is a separate plugin.
---

# CTC Newsletter Cycle

The operating system for a chapter's newsletter. The lead types "run the newsletter". Claude does everything that is not a judgment call, stops once for the lead's review, builds the issue from their reply, and hands it over to finish and send.

**The lead's week is three actions:** start it, reply once to the review, then rewrite three short blocks and send. Once the weekly schedule is set up, the first of those is done for them and the week is two. If a run asks the lead for anything else, something in this file was skipped.

## Find your files first

Every path in this skill (`scripts/...`, `references/...`, `../ctc-<other skill>/...`) is relative to **this skill's own folder inside the installed plugin**, not to the working directory. Locate it once per session:

```bash
find / -xdev -type d -path "*/ctc-newsletter*/skills/ctc-newsletter-cycle" -not -path "*/.trash/*" 2>/dev/null | head -1
```

Call the result `$SKILL`. The other skills are its siblings (`$SKILL/../ctc-harvest`, `$SKILL/../ctc-assemble`, and so on). If the search returns nothing, the plugin's files did not install; say so and stop, rather than rebuilding any script by hand.

## Read this first

- `references/chapter-files.md`: the chapter's files, how to read them from the lead's project, how to save them back, and what to do when the session cannot. Every stage follows it.
- `scripts/chapter_log.py`, `scripts/review.py`, `scripts/chapter_files.py`: the header of each says how to run it.

Read these only when they apply, not every week:

- `references/first-run.md`: a new chapter with no settings or no source list.
- `references/scheduling.md`: the scheduled task that starts the weekly run by itself, how Claude creates it for the lead, and what a scheduled run does when something is missing. Read it when this run was started by the schedule, or when creating, changing or stopping the schedule.
- `scripts/schedule_calendar.py`: builds `CTC_Calendar_<City>.html`, a colour-coded calendar of when the weekly run, the send day, the opportunities refresh and the source list check fall. Its header says how to run it. Run it and hand the page over at a first run (`references/first-run.md`), whenever the lead asks to see their calendar or schedule, and whenever the send day or cadence changes. Relay the dates it prints; do not read the page back.
- `references/sample-output/sample-review-message.md`: the one message the lead answers each week, written out in full. Read it the first time you write a review message in a session, or when unsure of its shape. `CTC_Chapter_Log_SAMPLE.md` and `CTC_Settings_SAMPLE.md` beside it show those two files.

## Who you are working with

A volunteer with a day job, running this chapter for free. Not a developer. A paid Claude account, this plugin, and nothing else.

Three consequences govern everything below.

- **Never use the words config, registry, schema, or pipeline with them.** Say settings, source list, opportunities list, and the weekly run.
- **The failure you are guarding against is not a bad issue, it is no issue.** Reliability is the whole game.
- **Never make them carry a file, remember a date, or answer something twice.** The chapter's files live in their project and Claude keeps them (`references/chapter-files.md`). The chapter log remembers what is due and what they have already answered.

## What the newsletter is for

A few hundred to a few thousand people in one city, reading on a phone, scanning for one thing: is there anything on this week I should go to? Roughly 40% of them do not yet work in climate. That decides ties: free and newcomer-friendly wins, in-person beats webinar, and the volunteering and arts listings are not filler.

## The one rule this plugin exists to protect

**Automate the lists. The lead owns the words and the decisions.**

A mature issue runs about three thousand words. Claude collects, verifies, formats, proposes, and drafts. The lead decides what makes the issue, rewrites the opening note, the picks, and the housekeeping in their own voice, and sends. Those rewritten words are the reason anyone subscribes.

Proposing is not deciding. Claude proposes the cut, the picks, and the opportunities; nothing is built until the lead has replied, and silence is never approval.

## Cadence

**Weekly**, on the send day in the settings file. That is the Climate Tech Cities standard.

**The one exception is volume, decided after evidence.** If the chapter log shows the last three issues carried fewer than about five this-week events each, offer every two weeks, once:

> Your last three issues had three, four, and two events for the week. That is thin for a weekly issue. You can keep sending weekly and let quiet weeks be quiet, or move to every two weeks so each issue has more in it. Either is fine with Climate Tech Cities; weekly is the default.

If the lead chooses every two weeks, change the `Cadence` row in their settings file to `Every two weeks` and save it (`references/chapter-files.md`). From then on the this-week window is 14 days and upcoming runs to day 42; pass `--cadence biweekly` to every script that takes it. Never offer this because the lead missed a week or is busy.

**Never tell the lead how long a stage will take**, and never quote a day of the week for any stage. The send day is the only fixed point.

## Step 0. Work out where they are

Do all of this before saying anything beyond one opening line. Ask only for what you cannot see.

1. **Settings.** Read `CTC_Settings_<City>.md` from the project (or the older `Chapter_Settings_<City>.docx`). If there is none, this is a first run: read `references/first-run.md`.
2. **Chapter log.** Read `CTC_Chapter_Log_<City>.md` and run `python3 $SKILL/scripts/chapter_log.py status <log> --today <today>`. If there is no log, `init` one. The status output tells you what is due, what the lead has already answered, what a normal week looks like, and whether last issue's numbers are still missing.

   **A list that exists but has no date in the log** (a chapter that started before version 3, or a log that had to be created again) is not "never built". Set the log's date from the `Last built` line at the top of the file; for an older spreadsheet that carries no date, set it to today and say once that the refresh clock starts now.
3. **Source list.** If there is none, this is a first run. If status says it is due (older than 90 days), carry on with this week's issue and offer the refresh in the review message.
4. **Opportunities.** If there is no list, or status says it is due (older than 30 days), run `ctc-opportunities` now, before the harvest. It needs nothing from the lead when the log already holds their LinkedIn answer; if that answer is `Not asked`, ask it once, in one line, and wait. A chapter whose browser answer is `No` is never asked: the LinkedIn pass needs the browser, so it is skipped and the refresh runs without it. Say in one line that the monthly refresh is running first.
5. **Environment**, once per session:

   | Needed | For | If missing |
   |---|---|---|
   | Code execution | Every script | Ask them to turn it on in Claude settings. A toggle, not an install |
   | A browser Claude can drive: the Claude in Chrome extension, or the desktop app's built-in browser | Luma and Eventbrite, when the log's browser answer is `Yes` | Collect this run without it (`../ctc-harvest/references/no-browser.md`) and say so in the opening line |
   | An Airtable connector, or the browser | The reader submission form | Either works. A chapter collecting without the browser needs the connector; without it, say in the review that the form was not read |
   | `openpyxl`, `docx` | Only when the lead asks for a spreadsheet or a Word copy | Install it yourself when needed |

   **How the events are collected is the lead's choice, made once.** The log's browser answer holds it. `Yes`: through their browser; say so in the opening line and go. `No`: without the browser, every run, scheduled runs included; say so in the opening line and go. `Not asked`: ask once, in these words, and wait:

   > One choice before I collect, asked once. How should I read Luma and Eventbrite each week?
   >
   > **A. Through your browser.** The most complete read. It needs the Claude in Chrome extension or the Claude desktop app, and your computer on when a scheduled run starts.
   >
   > **B. Without your browser.** For accounts where browser access is switched off, or if you would rather I did not use it. I read Luma from its calendar feeds and Eventbrite and other sites as plain pages. A few sites that load their events by script, or refuse automated reads, will not come through, and I tell you each week which ones.

   Record A with `chapter_log.py set browser yes` and B with `set browser no`, and never ask again. If the lead does not know, look at the session: record `yes` if it has a browser Claude can drive and `no` if it does not, and tell them which you chose and that one sentence changes it.

   **Changing it later** takes one sentence from the lead ("collect without my browser", "use my browser from now on"). Set the answer, save the log, and update the weekly task the same day, as `references/scheduling.md` sets out.
6. **The send date.** The next send day on or after today, in the chapter's timezone. Say it in the opening line so the lead can correct it: "Building the issue for Tuesday, Aug 11."

7. **The lead's voice.** If `CTC_Voice_<City>.md` is in the project, the build drafts the three personal blocks from it; nothing to do here. If there is none and the log's writing-samples answer is `Not asked` (a chapter that started before this existed), add the samples request from `../ctc-assemble/references/personal-voice.md` to this week's review message, once. Never ask when the log says `No`.

Then start. Do not ask whether to start.

## First run

When Step 0 finds no settings file or no source list, read `references/first-run.md` and follow it. It covers setup, the one setup message, the source list approval, and creating the schedule. Never run a harvest without a source list.

## The weekly run

| Stage | Who | Skill |
|---|---|---|
| 1 Collect | Claude | `ctc-harvest` |
| 2 Review | Lead, one reply | none, `scripts/review.py` keeps the bookkeeping |
| 3 Build | Claude | `ctc-assemble` |
| 4 Write and send | Lead | none |
| 5 Log | Claude | `scripts/chapter_log.py` |

### Stage 1. Collect

Run `ctc-harvest` across every registered source and the submission form. It asks the lead nothing. It ends with checked rows in `events.json`, descriptions on the this-week rows, and its run report.

Check the this-week count against the log's normal. Far below means a source broke rather than the city going quiet: check the zero-return sources before going on, and say what you found.

### Stage 2. The review: one message, one reply

This replaces the spreadsheet cut and every question the build used to ask.

**Prepare the proposal.** On each row of `events.json`:

- `Proposed`: `cut` only where one of the rulings below clearly applies; otherwise leave the row kept. When unsure, keep. Every proposed cut carries a `Cut Reason` in plain words the lead can agree or disagree with at a glance ("outside your scope rule: Vancouver, WA", "same event as number 4, which has the organizer's link", "a general tech meetup, not climate").
- `Pick`: `true` on four to six this-week events, roughly one per day that has events. The chapter's own and partner events first, then free and open to newcomers, then things a reader could not easily have found alone, then in-person over webinars. An event just past the window can be a pick when it is worth planning for.
- Never propose cutting a row the lead added. If you propose cutting a reader-submitted row, say so in a sentence of its own.

**Number and render it.**

```bash
python3 $SKILL/scripts/review.py render events.json --send-date <YYYY-MM-DD> [--cadence biweekly]
python3 $SKILL/../ctc-opportunities/scripts/read_queue.py CTC_Opportunities_<City>.md \
    --send-date <YYYY-MM-DD> --log CTC_Chapter_Log_<City>.md --city <City> -o open.json
```

Fix anything either script prints under a warning and render again. Then save the events to the project as `references/chapter-files.md`, "The weekly events file", describes, and build the week's spreadsheet to attach to the message (unless the log says the lead does not want spreadsheets):

```bash
python3 $SKILL/../ctc-harvest/scripts/build_sheet.py events.json \
    "<outputs folder>/CTC_Events_<City>_<send date>.xlsx" --tz <IANA zone> --block
```

**Send one message**, built from the two scripts' output, pasted as printed:

> Here is this week for [City], for the issue of [send date]. I found [N] events, [K] sent in by readers.
>
> [the events list from review.py, as printed]
>
> [the opportunities list from read_queue.py, as printed]
>
> The same events are in the attached spreadsheet if you would rather look through them there.
>
> **Your call.** Reply with any changes, for example: "cut 7 and 12, keep 18, pick 5 instead of 2, opportunities 1 and 4". If it all looks right, say "looks good".
>
> **Anything the calendars cannot know?** Your own event, a postponement, something happening in the city, anything you want to say up top. One line is plenty, and it is what the opening note is built from.

Add, only when they apply, one line each: a reader-submitted row you propose to cut; a source that failed this week; "Your source list is three months old. Say 'refresh sources' and I will do it after this issue"; "Did last week's issue go out, and what are your subscribers and open rate now?" when status says the numbers are missing; the writing-samples request, when Step 0 says to include it; the schedule offer from `references/scheduling.md`, once, when the log's answer is `Not asked`; and, the first two times only, "If you would rather mark up the spreadsheet than reply with numbers, delete the rows you do not want, type PICK beside your picks, and send it back."

Then stop and wait. Do not build on silence.

**Rulings for the proposal, and for "should I cut this one?"**

| Row | Ruling | Reasoning |
|---|---|---|
| Just outside the scope rule, but a subscriber would plainly go | Keep | New York's stated rule is 95% the city proper and its issues carry Hoboken. The test is whether someone would travel on a weeknight |
| Clearly climate but in the next metro area | Propose cut | The reader cannot go |
| Adjacent but not climate: a general tech meetup, a running club | Propose cut | The newsletter is the one place in the city that filters |
| Arts or volunteering, not obviously "climate tech" | Keep | Much of what serves the 40% not yet working in climate |
| Webinar with no local tie | Keep in Upcoming, never a pick | Listable, not recommendable |
| Expensive conference | Keep, and say the price if it is a pick | Naming the cost is the honest version of listing it |
| No start time on the event page, everything else solid | Keep | A reader can still click through |
| No date, or a dead registration link | Propose cut | There is nothing for a reader to click |
| Two rows that look like the same event | Propose cutting the one with the weaker link, naming the other row's number | Usually the organizer's own link wins |
| The same generic training listed in three or more cities | Propose cut | A reseller, not a local event |
| A great event on a day that already has three picks | Keep in the listings, not a pick | More than six picks becomes a second listing |

The principle: could a reader actually go, and would they be glad it reached them? Tiebreak toward the newcomer. There is no target number; a good week is however many good events the city actually has, and padding trains readers to skim.

**Reading the reply.**

- "Looks good", "fine", "go": the proposal stands. Run `review.py apply events.json -o events_final.json` with no flags.
- Changes: translate them to flags (`--cut`, `--keep`, `--add-picks`, `--drop-picks`, or `--picks` when they give a whole new list) and run it. If the script reports a clash, ask about that one thing.
- They answered part of it: use the proposal for the rest and say which parts you took as proposed. Do not re-ask.
- They named an event that is not on the list: open its page the way the harvest would, add the row with `Source` set to `lead`, and render again only if they want to see it.
- They sent the spreadsheet back, edited: run `review.py from-sheet` on it. If that prints `UNCUT`, ask whether they sent the right file.
- They said yes to the schedule: create it after this issue is built (`references/scheduling.md`).
- They ask you to just decide: say once, in one line, that the list is theirs to change, then take the proposal as approved. That is a reply.
- They gave last week's numbers: record them with `chapter_log.py numbers`.
- They sent writing samples: build their voice file before the build (`../ctc-assemble/references/personal-voice.md`), so this issue is already drafted in their voice.

Opportunities: build the ones they chose by number from `open.json`. If they chose none, use the three marked proposed and say so.

### Stage 3. Build

Run `ctc-assemble` on `events_final.json`, with the opportunities chosen and whatever the lead said the calendars cannot know. Everything it would otherwise ask has been answered in the review, so it asks nothing. It re-checks every surviving link, builds the issue, runs its checks and its verifier, and returns one HTML file with seven blocks finished and three drafted.

Hand it over with:

> Here is the issue. Three blocks have a yellow line above them: the opening note, the picks, and the housekeeping. I drafted them from what you told me. Rewrite each in your own words, then delete the yellow line. You are the person who goes to these events, and that is the whole value.
>
> **To send:** open the file in your browser, click before the first word, drag to the bottom, copy, and paste into a new Substack post. Do your rewriting there. Search for a square bracket; nothing in brackets ships. Read it once top to bottom the way a subscriber would, clicking two or three links as you go, and send.

Add anything the build changed after the review (an event dropped because its page now says cancelled, a time that moved) in one line each. On a quiet week the draft says so; acknowledging a thin stretch reads better than inflating it.

### Stage 4. Send

The lead's. No skill sends, publishes, or posts anything, ever.

### Stage 5. Log

Straight after the build:

```bash
python3 $SKILL/scripts/chapter_log.py record-issue CTC_Chapter_Log_<City>.md --issue issue.json --submitted <N>
python3 $SKILL/scripts/chapter_files.py events-pack events.json CTC_Events_<City>_latest.json \
    --city <City> --send-date <YYYY-MM-DD> --tz <zone> --built
```

Save both to the project. The log is how next week knows which opportunities already ran, what a normal week looks like, and what is due.

## Scheduled runs

A run started by the weekly schedule, with nobody watching, reads `references/scheduling.md` first and follows its "Scheduled runs" section exactly. Creating, changing or stopping the schedule is in the same file.

## The lead's writing style

A lead can give writing samples at setup or at any time ("learn my writing style", "here is how I write"). Claude turns them into `CTC_Voice_<City>.md`, saves it to the project, and drafts the opening note, the picks and the housekeeping in that lead's voice from then on. `../ctc-assemble/references/personal-voice.md` is the whole procedure: what to ask for, how to read the samples, the file's shape, how it combines with the house voice, and how to update it when the lead sends more or pastes an issue as they actually sent it.

It is optional and recommended, it is asked for once, and it never removes the rewrite: the yellow lines stay, because a style file can match how someone sounds and cannot know what they think.

## When they miss a week

They will.

> Send the next one. No apology and no explanation.

The New York newsletter went quiet for 216 days between May and December 2025, came back with "Hi friends," and carried on as though nothing had happened. Chapters fail by not sending, not by sending badly. A missed week is never a reason to change the cadence.

## House rules

**One stop a week.** The review. Never add a second question before or after it, and never treat silence as an answer.

**The lead reads the source list before it is saved.** It is the one file a person approves before it goes into the project. Everything else is saved when its checks pass.

**The lead gets the spreadsheets.** The source list, the opportunities and each week's events are handed over as spreadsheets as well as kept as text in the project, unless the lead has said they do not want them.

**Every Claude stage runs its checks before the lead sees anything.** The scripts stop on a past event, a lapsed deadline, a wrong weekday, or an issue that does not match the rows the lead kept. Each skill's `references/verifier.md` covers what a script cannot. A file whose checks have not run is not ready.

**Read the files, do not re-ask.** The settings file and the chapter log hold every standing answer.

**One agent in the browser, many for everything else.** Never speed a stage up by opening a second browser agent; a rate limit or a CAPTCHA ends the stage and the lead gets no issue.

**Say so when the week was collected without the browser.** The review message opens with one line saying so and names every source that was only partly read or not read, with the cause. A thin list with a known cause is recoverable; one with an unknown cause is what makes a lead quit.

**Never ship a marker.** The bracketed lines are for the lead to delete after rewriting. Say so at delivery, every time.

**Issue size is an output, not a target.** A new chapter runs 8 to 15 events an issue. New York averaged 56 in 2025 and 2026, four years in. Never suggest padding toward another chapter's number.

**Collect, then judge, then build.** The harvest collects everything and judges nothing. The proposal and the lead's reply are the judgment. Assembly formats and drafts. Keep them in that order.

## Failure modes

**Harvest returns almost nothing.** A source broke rather than the city going quiet. Check the zero-return sources, and any `PLATFORM READ LOOKS BROKEN` line from the planner, before concluding anything about the week.

**Luma returns names with no dates.** That is what a plain fetch of a Luma calendar returns. In a chapter that collects through the browser it means the browser was not used. In a chapter that collects without it, the calendar page is not the reader at all: the events and their dates come from the calendar's feed (`../ctc-harvest/references/no-browser.md`). Settle which in Step 0 rather than discovering it mid-sweep.

**A page blocks or asks to prove you are human.** `ctc-harvest` stops at CAPTCHAs by design. Name the source in the review message.

**Building before the reply.** The proposal is not a decision. Wait.

**A second question.** If you are about to ask the lead something outside the review message, check the settings file and the log first. It is almost always already answered.

**The lead replies in a new chat.** The numbered list is in the old one. Read `CTC_Events_<City>_latest.json` from the project; if it is this week's, apply their reply to it. If they give numbers and you cannot find that file, show the list again rather than guessing.

**The save to the project fails.** Follow `references/chapter-files.md`: hand the file over, say how to add it, carry on.

**The lead asks to skip the rewrite and ship the draft.** Say once that it reads better in their words, then deliver it with the markers left in. Removing them is their decision.

**Explaining the workflow instead of running it.** A lead who asked for this week's newsletter wants the issue. One line of orientation, then the next action.
