#!/usr/bin/env python3
"""
chapter_log.py -- the chapter's memory, so the lead does not have to be it.

One file, CTC_Chapter_Log_<City>.md, kept in the lead's project. It records
when the source list and the opportunities were last built, the lead's standing
answers (so nothing is asked twice), one line per issue, and which
opportunities ran in which issue.

  python3 chapter_log.py init   LOG --city Boston [--today YYYY-MM-DD]
  python3 chapter_log.py set    LOG <key> <value>
        keys: sources-built, opportunities-refreshed (value: YYYY-MM-DD)
              browser, linkedin, voice, schedule, spreadsheets (value: yes / no)
  python3 chapter_log.py record-issue LOG --issue issue.json [--submitted N]
  python3 chapter_log.py numbers LOG --send-date YYYY-MM-DD
        [--subscribers N] [--open-rate "41%"] [--sent yes|no]
  python3 chapter_log.py status LOG [--today YYYY-MM-DD]

`init` leaves an existing log untouched. Every other command rewrites the file
in place; save it back to the project afterwards.
"""
import argparse
import json
import os
import sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chapter_files as cf  # noqa: E402

DATE_ITEMS = [("sources-built", "Source list last built"),
              ("opportunities-refreshed", "Opportunities last refreshed")]
ANSWER_ITEMS = [("browser", "Use my browser to read Luma and Eventbrite"),
                ("linkedin", "Read my LinkedIn feed for opportunities"),
                ("voice", "Gave writing samples for a personal style file"),
                ("schedule", "Start the weekly run automatically on a schedule"),
                ("spreadsheets", "Send me the spreadsheets as well")]
ISSUE_HEADS = ["Send date", "This week", "Upcoming", "Reader-submitted", "Picks",
               "Opportunities", "Sent", "Subscribers", "Open rate"]
OPP_HEADS = ["Send date", "Opportunity", "URL"]

SOURCES_DUE_DAYS = 90
OPPS_DUE_DAYS = 30


def load(path):
    if not os.path.exists(path):
        sys.exit(f"There is no chapter log at {path}. Read it from the project first, or create it with: "
                 f"chapter_log.py init {path} --city <City>")
    text = open(path, encoding="utf-8").read()
    secs = cf.parse_sections(text)
    dates = {r.get("Item", ""): r.get("Date", "") for r in secs.get("Dates", [])}
    answers = {r.get("Question", ""): r.get("Answer", "") for r in secs.get("Standing answers", [])}
    return {
        "city": cf.meta(text, "City"),
        "dates": {k: dates.get(label, "") for k, label in DATE_ITEMS},
        "answers": {k: answers.get(label, "Not asked") or "Not asked" for k, label in ANSWER_ITEMS},
        "issues": secs.get("Issues", []),
        "opps": secs.get("Opportunities run", []),
    }


def save(path, log):
    issues = sorted(log["issues"], key=lambda r: r.get("Send date", ""))
    opps = sorted(log["opps"], key=lambda r: (r.get("Send date", ""), r.get("Opportunity", "")))
    parts = [
        f"# {log['city']}: chapter log",
        cf.MARK.format(kind="log"),
        "",
        f"City: {log['city']}",
        "",
        "Claude keeps this file. It is how the weekly run knows what is due, what "
        "already ran, and what you have already answered.",
        "",
        "## Dates",
        "",
        cf.table(["Item", "Date"], [[label, log["dates"].get(k, "")] for k, label in DATE_ITEMS]),
        "",
        "## Standing answers",
        "",
        cf.table(["Question", "Answer"],
                 [[label, log["answers"].get(k, "Not asked")] for k, label in ANSWER_ITEMS]),
        "",
        "## Issues",
        "",
        cf.table(ISSUE_HEADS, [[r.get(h, "") for h in ISSUE_HEADS] for r in issues]),
        "",
        "## Opportunities run",
        "",
        cf.table(OPP_HEADS, [[r.get(h, "") for h in OPP_HEADS] for r in opps]),
        "",
    ]
    open(path, "w", encoding="utf-8").write("\n".join(parts))


def _day(s):
    return date.fromisoformat(s)


def cmd_init(a):
    if os.path.exists(a.log):
        print(f"{a.log} already exists; left as it is")
        return
    save(a.log, {"city": a.city, "dates": {}, "answers": {}, "issues": [], "opps": []})
    print(f"wrote {a.log}")


def cmd_set(a):
    log = load(a.log)
    if a.key in dict(DATE_ITEMS):
        _day(a.value)  # raises on a malformed date
        log["dates"][a.key] = a.value
    elif a.key in dict(ANSWER_ITEMS):
        v = a.value.strip().lower()
        if v not in ("yes", "no"):
            sys.exit("value must be yes or no")
        log["answers"][a.key] = v.capitalize()
    else:
        sys.exit("unknown key. Use one of: " + ", ".join(k for k, _ in DATE_ITEMS + ANSWER_ITEMS))
    save(a.log, log)
    print(f"{a.key} = {a.value}")


def cmd_record(a):
    issue = json.load(open(a.issue, encoding="utf-8"))
    send = issue.get("send_date")
    if not send:
        sys.exit("issue.json has no send_date; nothing recorded")
    _day(send)
    log = load(a.log)
    tw = sum(len(d.get("events") or []) for d in issue.get("this_week") or [])
    opps = issue.get("opportunities") or []
    row = {"Send date": send, "This week": str(tw),
           "Upcoming": str(len(issue.get("upcoming") or [])),
           "Reader-submitted": "" if a.submitted is None else str(a.submitted),
           "Picks": str(sum(1 for p in issue.get("picks") or []
                            for s in p.get("segments") or [] if s.get("link"))),
           "Opportunities": str(len(opps)), "Sent": "", "Subscribers": "", "Open rate": ""}
    old = next((r for r in log["issues"] if r.get("Send date") == send), None)
    if old:  # rebuilt issue: keep anything the lead reported afterwards
        for k in ("Sent", "Subscribers", "Open rate"):
            row[k] = old.get(k, "")
        if a.submitted is None:
            row["Reader-submitted"] = old.get("Reader-submitted", "")
    log["issues"] = [r for r in log["issues"] if r.get("Send date") != send] + [row]
    log["opps"] = [r for r in log["opps"] if r.get("Send date") != send] + [
        {"Send date": send, "Opportunity": o.get("title", ""), "URL": o.get("url", "")} for o in opps]
    save(a.log, log)
    print(f"recorded the {send} issue: {tw} this week, {row['Upcoming']} upcoming, "
          f"{row['Picks']} picks, {len(opps)} opportunities")


def cmd_numbers(a):
    log = load(a.log)
    row = next((r for r in log["issues"] if r.get("Send date") == a.send_date), None)
    if not row:
        sys.exit(f"no issue recorded for {a.send_date}")
    if a.sent:
        row["Sent"] = a.sent.capitalize()
    if a.subscribers is not None:
        row["Subscribers"] = str(a.subscribers)
    if a.open_rate:
        row["Open rate"] = a.open_rate
    save(a.log, log)
    print(f"updated the {a.send_date} issue")


def cmd_status(a):
    log = load(a.log)
    today = _day(a.today) if a.today else date.today()
    print(f"CHAPTER LOG STATUS for {log['city']} on {today.isoformat()}")
    for key, label, limit, skill in (
            ("sources-built", "Source list", SOURCES_DUE_DAYS, "ctc-source-map"),
            ("opportunities-refreshed", "Opportunities", OPPS_DUE_DAYS, "ctc-opportunities")):
        v = log["dates"].get(key, "")
        if not v:
            print(f"  DUE      {label}: never built. Run {skill} before the harvest.")
            continue
        age = (today - _day(v)).days
        if age > limit:
            print(f"  DUE      {label}: last built {v}, {age} days ago (refresh after {limit}). Run {skill}.")
        else:
            print(f"  ok       {label}: last built {v}, {age} days ago")
    for key, label in ANSWER_ITEMS:
        print(f"  answer   {label}: {log['answers'].get(key, 'Not asked')}")
    mode = {"yes": "through the browser", "no": "without the browser (ctc-harvest/references/no-browser.md)"}.get(
        str(log["answers"].get("browser", "")).strip().lower(), "not chosen yet; ask once (cycle Step 0)")
    print(f"  collect  {mode}")
    issues = sorted(log["issues"], key=lambda r: r.get("Send date", ""))
    if not issues:
        print("  issues   none recorded yet. This is the first issue.")
        return
    last = issues[-1]
    print(f"  issues   {len(issues)} recorded. Last: {last['Send date']} "
          f"({last.get('This week', '?')} this week, {last.get('Upcoming', '?')} upcoming)")
    recent = [int(r["This week"]) for r in issues[-3:] if str(r.get("This week", "")).isdigit()]
    if recent:
        print(f"  normal   this-week counts for the last {len(recent)} issue(s): "
              + ", ".join(str(n) for n in recent))
    if not (last.get("Sent") or "").strip() or not (last.get("Subscribers") or "").strip():
        print(f"  ASK      the {last['Send date']} issue has no numbers yet. Ask once, in the "
              f"review message: did it go out, subscribers now, open rate.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init"); p.add_argument("log"); p.add_argument("--city", required=True)
    p.add_argument("--today"); p.set_defaults(fn=cmd_init)
    p = sub.add_parser("set"); p.add_argument("log"); p.add_argument("key"); p.add_argument("value")
    p.set_defaults(fn=cmd_set)
    p = sub.add_parser("record-issue"); p.add_argument("log"); p.add_argument("--issue", required=True)
    p.add_argument("--submitted", type=int); p.set_defaults(fn=cmd_record)
    p = sub.add_parser("numbers"); p.add_argument("log"); p.add_argument("--send-date", required=True)
    p.add_argument("--subscribers", type=int); p.add_argument("--open-rate")
    p.add_argument("--sent", choices=["yes", "no"]); p.set_defaults(fn=cmd_numbers)
    p = sub.add_parser("status"); p.add_argument("log"); p.add_argument("--today")
    p.set_defaults(fn=cmd_status)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
