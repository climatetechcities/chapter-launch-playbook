#!/usr/bin/env python3
"""
chapter_files.py -- the chapter's files as plain text, so Claude can keep them
in the lead's project and nobody carries a spreadsheet by hand.

The chapter's files, all markdown a person can read:

  CTC_Settings_<City>.md        written once by ctc-chapter-setup
  CTC_Source_List_<City>.md     written by ctc-source-map (build_registry.py --md)
  CTC_Opportunities_<City>.md   written by ctc-opportunities (build_queue.py --md)
  CTC_Chapter_Log_<City>.md     written by chapter_log.py
  CTC_Voice_<City>.md           how the lead writes, built from their samples
                                (ctc-assemble/references/personal-voice.md)

This module is the one place that knows how those files are laid out. The other
scripts import it. It also reads the older spreadsheets
(CTC_Source_Registry_<City>.xlsx, Opportunities_<City>.xlsx) so a chapter that
started before version 3 carries on without rebuilding anything.

Command line:

  python3 chapter_files.py sources-import <CTC_Source_List.md | old .xlsx> sources.json
  python3 chapter_files.py queue-import   <CTC_Opportunities.md | old .xlsx> queue.json
  python3 chapter_files.py settings       chapter_data_<city>.json CTC_Settings_<City>.md
  python3 chapter_files.py events-pack    events.json CTC_Events_<City>_latest.json \
        --city <City> --send-date YYYY-MM-DD --tz <IANA zone> [--cadence biweekly] [--built]
      (--built writes the same file with no events in it, for after the issue is
      built: the project copy is only needed while a review is waiting.)
  python3 chapter_files.py voice-check    CTC_Voice_<City>.md
  python3 chapter_files.py selftest
"""
import json
import re
import sys
from datetime import date

MARK = "<!-- ctc-file: {kind} v3 -->"

SOURCE_COLUMNS = [
    ("name", "Source Name"), ("url", "URL"), ("platform", "Platform"),
    ("method", "Method"), ("tier", "Tier"), ("category", "Category"),
    ("cadence", "Cadence"), ("last_event", "Last Event"),
    ("confidence", "Confidence"), ("origin", "Origin"), ("notes", "Notes"),
]

QUEUE_COLUMNS = [
    ("name", "Opportunity"), ("org", "Organization"), ("type", "Type"),
    ("deadline", "Deadline"), ("who", "Who it is for"), ("scope", "Scope"),
    ("description", "Description"), ("url", "URL"),
]


# ------------------------------------------------------------------ tables

def _cell(v):
    """One table cell. Pipes are escaped and line breaks flattened, so any
    text survives a round trip through a markdown table."""
    s = "" if v is None else str(v)
    s = re.sub(r"\s*[\r\n]+\s*", " ", s).strip()
    return s.replace("|", "\\|")


def _uncell(s):
    return s.strip().replace("\\|", "|")


def table(headers, rows):
    """rows is a list of lists, already in header order."""
    out = ["| " + " | ".join(_cell(h) for h in headers) + " |",
           "|" + "|".join(["---"] * len(headers)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(_cell(v) for v in r) + " |")
    return "\n".join(out)


def _split_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|") and not line.endswith("\\|"):
        line = line[:-1]
    return [_uncell(c) for c in re.split(r"(?<!\\)\|", line)]


def parse_sections(text):
    """Return {section heading: [row dict, ...]} for every '## ' section that
    holds a table, plus '' for a table before the first heading. Row dicts are
    keyed by the table's own header text."""
    sections, current, lines = {}, "", text.splitlines()
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("## "):
            current = ln[3:].strip()
        elif ln.lstrip().startswith("|") and i + 1 < len(lines) and \
                re.match(r"^\s*\|?\s*:?-{3,}", lines[i + 1]):
            headers = _split_row(ln)
            rows = []
            i += 2
            while i < len(lines) and lines[i].lstrip().startswith("|"):
                cells = _split_row(lines[i])
                cells += [""] * (len(headers) - len(cells))
                rows.append(dict(zip(headers, cells)))
                i += 1
            sections.setdefault(current, []).extend(rows)
            continue
        i += 1
    return sections


def meta(text, label):
    """Read a 'Label: value' line from the top of a file."""
    m = re.search(r"^" + re.escape(label) + r":\s*(.+?)\s*$", text, re.M)
    return m.group(1) if m else ""


def safe_city(city):
    return re.sub(r"[^A-Za-z0-9]+", "_", city or "City").strip("_")


# ------------------------------------------------------------- source list

def sources_to_md(city, rows, built=None):
    built = built or date.today().isoformat()
    body = [[r.get(k, "") for k, _ in SOURCE_COLUMNS] for r in rows]
    return "\n".join([
        f"# {city}: source list",
        MARK.format(kind="sources"),
        "",
        f"City: {city}",
        f"Last built: {built}",
        "",
        "Every place events get announced for this chapter. The weekly harvest reads "
        "this file. Claude keeps it up to date; refresh it every three months by "
        "saying \"refresh my source list\".",
        "",
        "## Sources",
        "",
        table([h for _, h in SOURCE_COLUMNS], body),
        "",
    ])


def md_to_sources(text):
    rows = parse_sections(text).get("Sources", [])
    by_header = {h: k for k, h in SOURCE_COLUMNS}
    out = [{by_header[h]: v for h, v in r.items() if h in by_header} for r in rows]
    return {"city": meta(text, "City"), "built": meta(text, "Last built"), "sources": out}


def xlsx_to_sources(path):
    import openpyxl
    ws = openpyxl.load_workbook(path).active
    headers = [c.value for c in ws[1]]
    by_header = {h: k for k, h in SOURCE_COLUMNS}
    out = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or not row[0]:
            continue
        rec = {}
        for h, v in zip(headers, row):
            if h in by_header:
                if hasattr(v, "isoformat"):
                    v = v.isoformat()[:10]
                rec[by_header[h]] = "" if v is None else str(v)
        out.append(rec)
    return {"city": "", "built": "", "sources": out}


def load_sources(path):
    if path.lower().endswith((".xlsx", ".xlsm")):
        return xlsx_to_sources(path)
    with open(path, encoding="utf-8") as fh:
        return md_to_sources(fh.read())


# ------------------------------------------------------- opportunities queue

def queue_to_md(city, open_rows, closed_rows, built=None):
    built = built or date.today().isoformat()
    heads = [h for _, h in QUEUE_COLUMNS]

    def body(rows):
        return [[r.get(k, "") for k, _ in QUEUE_COLUMNS] for r in rows]
    parts = [
        f"# {city}: opportunities",
        MARK.format(kind="opportunities"),
        "",
        f"City: {city}",
        f"Last built: {built}",
        "",
        "Grants, fellowships, accelerators and open calls for this chapter's "
        "newsletter, most local first. Claude refreshes this once a month and "
        "reads it every week. Anything past its deadline moves to Closed.",
        "",
        "## Open",
        "",
        table(heads, body(open_rows)),
        "",
    ]
    if closed_rows:
        parts += ["## Closed", "", table(heads, body(closed_rows)), ""]
    return "\n".join(parts)


def md_to_queue(text):
    secs = parse_sections(text)
    by_header = {h: k for k, h in QUEUE_COLUMNS}

    def conv(rows):
        return [{by_header[h]: v for h, v in r.items() if h in by_header} for r in rows]
    return {"city": meta(text, "City"), "built": meta(text, "Last built"),
            "open": conv(secs.get("Open", [])), "closed": conv(secs.get("Closed", []))}


def xlsx_to_queue(path):
    """Read a pre-v3 Opportunities_<City>.xlsx (title row, header row, data)."""
    import openpyxl
    wb = openpyxl.load_workbook(path)
    by_header = {h: k for k, h in QUEUE_COLUMNS}
    out = {"city": "", "built": "", "open": [], "closed": []}
    for sheet in wb.sheetnames:
        ws = wb[sheet]
        hrow = None
        for r in (1, 2):
            if ws.max_row >= r and "Opportunity" in [c.value for c in ws[r]]:
                hrow = r
                break
        if not hrow:
            continue
        headers = [c.value for c in ws[hrow]]
        bucket = out["closed"] if sheet.strip().lower() == "closed" else out["open"]
        for row in ws.iter_rows(min_row=hrow + 1, values_only=True):
            if not row or not row[0]:
                continue
            rec = {}
            for h, v in zip(headers, row):
                if h in by_header:
                    if hasattr(v, "isoformat"):
                        v = v.isoformat()[:10]
                    rec[by_header[h]] = "" if v is None else str(v)
            bucket.append(rec)
    return out


def load_queue(path):
    if path.lower().endswith((".xlsx", ".xlsm")):
        return xlsx_to_queue(path)
    with open(path, encoding="utf-8") as fh:
        return md_to_queue(fh.read())


# ------------------------------------------------------------ settings file

def settings_to_md(d):
    """d is the chapter data file ctc-chapter-setup fills in."""
    def kv(pairs):
        return table(["Setting", "Value"], pairs)
    parts = [
        f"# {d['chapterName']}: chapter settings",
        MARK.format(kind="settings"),
        "",
        f"Created {d['startDate']}. Every Climate Tech Cities skill reads this file "
        "from the project instead of asking. To change anything, tell Claude what "
        "to change and it updates the file.",
        "",
        "## 1. Identity",
        "",
        kv([["City", d["city"]], ["Chapter name", d["chapterName"]],
            ["Chapter lead", d["leadName"]], ["Timezone", d["timezone"]],
            ["Started", d["startDate"]]]),
        "",
    ]
    if (d.get("cityNotes") or "").strip():
        parts += ["Notes on this city: " + d["cityNotes"].strip(), ""]
    parts += [
        "## 2. Newsletter",
        "",
        kv([["Send day", d["sendDay"]], ["Cadence", d.get("cadence", "Weekly")],
            ["Scope rule", d["scopeRule"]],
            ["Grouping", "Day headers for this week. Flat chronological for upcoming. No topic categories."],
            ["Web address", d["webAddress"]], ["Sender name", d["leadName"]],
            ["Sign-off", d["signOff"]]]),
        "",
        "Cadence stays Weekly unless the newsletter cycle offers every two weeks "
        "after the first few harvests come back thin.",
        "",
    ]
    if not d.get("webAddressConfirmed"):
        parts += ["Confirm the web address with the Climate Tech Cities team before "
                  "publishing. Two patterns are in use across chapters and there is no "
                  "published rule. Changing it later breaks links other chapters have shared.", ""]
    parts += [
        "## 3. To update later",
        "",
        kv([["Substack URL", d.get("substackUrl", "")], ["Reply-to email", d.get("replyTo", "")]]),
        "",
    ]
    return "\n".join(parts)


# -------------------------------------------------------------- voice file

VOICE_SECTIONS = ["1. How they sound", "2. Openings and sign-offs", "3. Words and phrases they use",
                  "4. Things they never do", "5. In their own words", "6. What the samples do not show"]
VOICE_MAX_WORDS = 900


def voice_problems(text):
    """Shape checks on the lead's voice file. It is written by hand from their
    samples, so this is what keeps it readable by the weekly run."""
    bad = []
    if MARK.format(kind="voice") not in text:
        bad.append("the marker line <!-- ctc-file: voice v3 --> is missing")
    for label in ("City", "Lead", "Built from", "Last updated"):
        v = meta(text, label)
        if not v or "<" in v:
            bad.append(f'the "{label}:" line is missing or still a placeholder')
    lu = meta(text, "Last updated")
    if lu and "<" not in lu:
        try:
            date.fromisoformat(lu)
        except ValueError:
            bad.append(f'"Last updated: {lu}" is not a YYYY-MM-DD date')
    heads = [ln[3:].strip() for ln in text.splitlines() if ln.startswith("## ")]
    for s in VOICE_SECTIONS:
        if s not in heads:
            bad.append(f'section "## {s}" is missing')
    body = {}
    current = None
    for ln in text.splitlines():
        if ln.startswith("## "):
            current = ln[3:].strip()
            body[current] = []
        elif current is not None:
            body[current].append(ln)
    for s in VOICE_SECTIONS:
        lines = [l for l in body.get(s, []) if l.strip()]
        if s in heads and not lines:
            bad.append(f'section "## {s}" is empty')
        if any(l.strip().startswith("<") and l.strip().endswith(">") for l in lines):
            bad.append(f'section "## {s}" still holds template text in angle brackets')
    quotes = [l for l in body.get("5. In their own words", []) if l.strip().startswith(">")]
    if "5. In their own words" in heads and len(quotes) < 2:
        bad.append("section 5 needs at least two excerpts, each on its own line starting with >")
    for q in quotes:
        if len(q.split()) > 60:
            bad.append("an excerpt in section 5 is over about 60 words; keep each one short")
    words = len(text.split())
    if words > VOICE_MAX_WORDS:
        bad.append(f"the file is {words} words; keep it under {VOICE_MAX_WORDS}. It is read every week")
    return bad


# --------------------------------------------------------------------- cli

def _selftest():
    nasty = "a | b \\ c\nsecond line"
    rows = [{"name": "X | Y", "url": "https://e.org/a?b=1|2", "platform": "web",
             "method": "auto", "tier": "core", "category": "arts", "cadence": "weekly",
             "last_event": "2026-08-01", "confidence": "verified", "origin": "user",
             "notes": nasty}]
    back = md_to_sources(sources_to_md("Test City", rows, "2026-08-02"))
    assert back["city"] == "Test City" and back["built"] == "2026-08-02", back
    assert back["sources"][0]["name"] == "X | Y", back
    assert back["sources"][0]["url"] == "https://e.org/a?b=1|2", back
    assert back["sources"][0]["notes"] == "a | b \\ c second line", back
    q = [{"name": "G", "org": "O", "type": "Grant", "deadline": "2026-09-01",
          "who": "w", "scope": "Local", "description": "d | e", "url": "https://x.org"}]
    qb = md_to_queue(queue_to_md("Test City", q, q, "2026-08-02"))
    assert qb["open"] == q and qb["closed"] == q, qb
    qb2 = md_to_queue(queue_to_md("Test City", q, [], "2026-08-02"))
    assert qb2["open"] == q and qb2["closed"] == [], qb2
    empty = md_to_queue(queue_to_md("Test City", [], [], "2026-08-02"))
    assert empty["open"] == [] and empty["closed"] == [], empty
    print("chapter_files selftest: ok")


def main(argv):
    if len(argv) >= 1 and argv[0] == "selftest":
        return _selftest()
    if len(argv) == 3 and argv[0] == "sources-import":
        data = load_sources(argv[1])
        json.dump(data, open(argv[2], "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print(f"read {len(data['sources'])} sources -> {argv[2]}"
              + (f" (last built {data['built']})" if data["built"] else ""))
        return
    if len(argv) == 3 and argv[0] == "queue-import":
        data = load_queue(argv[1])
        json.dump(data, open(argv[2], "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print(f"read {len(data['open'])} open and {len(data['closed'])} closed -> {argv[2]}")
        return
    if len(argv) >= 3 and argv[0] == "events-pack":
        import argparse
        ap = argparse.ArgumentParser(prog="chapter_files.py events-pack")
        ap.add_argument("events"); ap.add_argument("out")
        ap.add_argument("--city", required=True); ap.add_argument("--send-date", required=True)
        ap.add_argument("--tz", required=True)
        ap.add_argument("--cadence", default="weekly", choices=["weekly", "biweekly"])
        ap.add_argument("--built", action="store_true")
        a = ap.parse_args(argv[1:])
        date.fromisoformat(a.send_date)
        import os
        rows = []
        if not (a.built and not os.path.exists(a.events)):
            rows = json.load(open(a.events, encoding="utf-8"))
        if isinstance(rows, dict):
            rows = rows.get("events", [])
        # The page text is only needed while descriptions are being written.
        # Leaving it out keeps the project copy small.
        # Google Maps is derived from Location and is rebuilt on demand.
        drop = ("source_description", "Google Maps")
        lean = [] if a.built else [{k: v for k, v in r.items() if k not in drop} for r in rows]
        doc = {"city": a.city, "send_date": a.send_date, "tz": a.tz, "cadence": a.cadence,
               "status": "built" if a.built else "waiting for the lead's review", "events": lean}
        with open(a.out, "w", encoding="utf-8") as fh:
            fh.write(json.dumps(doc, ensure_ascii=False, separators=(",", ":")) if not lean else
                     "{" + ",".join(f"{json.dumps(k)}:{json.dumps(v, ensure_ascii=False)}"
                                    for k, v in doc.items() if k != "events")
                     + ',"events":[\n' + ",\n".join(json.dumps(r, ensure_ascii=False, separators=(",", ":"))
                                                    for r in lean) + "\n]}")
        print(f"wrote {a.out}: " + (f"cleared, the {a.send_date} issue is built" if a.built
                                    else f"{len(lean)} events for the {a.send_date} issue"))
        return
    if len(argv) == 2 and argv[0] == "voice-check":
        text = open(argv[1], encoding="utf-8").read()
        bad = voice_problems(text)
        if bad:
            print("VOICE FILE NOT READY. Fix these before saving it:", file=sys.stderr)
            for b in bad:
                print("  X " + b, file=sys.stderr)
            sys.exit(1)
        print(f"voice file ok: {meta(text, 'Lead')}, {meta(text, 'Built from')}, {len(text.split())} words")
        return
    if len(argv) == 3 and argv[0] == "settings":
        d = json.load(open(argv[1], encoding="utf-8"))
        open(argv[2], "w", encoding="utf-8").write(settings_to_md(d))
        print(f"wrote {argv[2]}")
        return
    sys.exit(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
