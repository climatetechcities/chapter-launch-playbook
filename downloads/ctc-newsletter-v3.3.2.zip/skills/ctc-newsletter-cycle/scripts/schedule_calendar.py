#!/usr/bin/env python3
"""
schedule_calendar.py -- a picture of the chapter's schedule, so the lead can
see when everything runs instead of working it out.

Reads the chapter's settings file and chapter log and writes one self-contained
HTML page, CTC_Calendar_<City>.html: month grids with four kinds of day marked,
each in its own colour and with its own label.

  Collect   the day before each send day: the weekly run collects the events
            and sends the review message
  Send      the send day
  Opps      the weekly run that also refreshes the opportunities list
            (the first run more than 30 days after the last refresh)
  Sources   the weekly run that offers the source list refresh
            (the first run more than 90 days after the list was built)

  python3 schedule_calendar.py SETTINGS.md LOG.md -o CTC_Calendar_<City>.html
        [--today YYYY-MM-DD] [--first-send YYYY-MM-DD] [--schedule yes|no]

--first-send  the first issue's send date, when the lead said to start next
              week rather than this one. Default: the next send day on or after
              today.
--schedule    the lead's answer about the automatic weekly run, when the log
              does not hold it yet (at a first run the log is set only once
              the task exists).

The dates are the same arithmetic chapter_log.py status uses, so the calendar
and the weekly run cannot disagree. It also prints the next dates as plain
text; relay those in the chat instead of opening the page.
"""
import argparse
import calendar
import html
import os
import sys
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chapter_files as cf  # noqa: E402
import chapter_log as cl  # noqa: E402

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
RUN_TIME = "about 1:40 pm"


def read_settings(path):
    text = open(path, encoding="utf-8").read()
    out = {}
    for rows in cf.parse_sections(text).values():
        for r in rows:
            if "Setting" in r:
                out[r["Setting"]] = r.get("Value", "")
    for need in ("City", "Send day"):
        if not out.get(need, "").strip():
            sys.exit(f"The settings file has no {need}. Nothing written.")
    day = out["Send day"].strip().capitalize()
    if day not in DAYS:
        sys.exit(f"Send day '{out['Send day']}' is not a weekday. Nothing written.")
    out["Send day"] = day
    return out


def plan(settings, log, today, first_send=None, schedule=None):
    """Every marked date, as {date: [kinds]}, plus the facts the page prints."""
    wd = DAYS.index(settings["Send day"])
    biweekly = "two" in settings.get("Cadence", "").lower()
    step = 14 if biweekly else 7
    if first_send is None:
        first_send = today + timedelta(days=(wd - today.weekday()) % 7)
    elif first_send.weekday() != wd:
        sys.exit(f"--first-send {first_send} is not a {settings['Send day']}. Nothing written.")

    def last(key):
        v = log["dates"].get(key, "")
        return date.fromisoformat(v) if v else None

    opps, srcs = last("opportunities-refreshed"), last("sources-built")
    built = {"opps": opps, "sources": srcs}
    marks, sends, opp_days, src_days = {}, [], [], []
    send = first_send
    horizon = today + timedelta(days=cl.SOURCES_DUE_DAYS + 3 * step)
    while send <= horizon:
        run = send - timedelta(days=1)
        marks.setdefault(run, []).append("collect")
        marks.setdefault(send, []).append("send")
        sends.append(send)
        if opps is None or (run - opps).days > cl.OPPS_DUE_DAYS:
            if run >= today:
                marks[run].append("opps"); opp_days.append(run)
            opps = run
        if srcs is None or (run - srcs).days > cl.SOURCES_DUE_DAYS:
            if run >= today:
                marks[run].append("sources"); src_days.append(run)
            srcs = run
        send += timedelta(days=step)
    for key, kind in (("opps", "opps-built"), ("sources", "sources-built")):
        d = built[key]
        if d and d >= today.replace(day=1):
            marks.setdefault(d, []).append(kind)
    answer = (schedule or log["answers"].get("schedule", "Not asked")).strip().lower()
    return {"marks": marks, "sends": sends, "opp_days": opp_days, "src_days": src_days,
            "auto": answer == "yes", "biweekly": biweekly, "last": sends[-1],
            "needs_computer": str(log["answers"].get("browser", "")).strip().lower() != "no"}


def fmt(d):
    return f"{d.strftime('%a')} {d.strftime('%b')} {d.day}"


def labels(auto):
    return {
        "collect": ("Collect", "Claude collects the events and sends you the list to review"
                    if auto else "You say \"run the newsletter\"; Claude collects the events"),
        "send": ("Send", "You send the issue"),
        "opps": ("Opps", "Opportunities list refreshed, inside that day's run"),
        "sources": ("Sources", "Claude offers to refresh your source list"),
        "opps-built": ("Opps", "Opportunities list last built"),
        "sources-built": ("Sources", "Source list last built"),
    }


CSS = """
:root{--bg:#fff;--fg:#1c1c1a;--mut:#6b6b66;--line:#dedcd3;--cell:#fafaf7;
--collect:#1f5fa8;--send:#1c7a45;--opps:#a35a00;--sources:#6a3fa0;--built:#5f5f5a}
@media(prefers-color-scheme:dark){:root{--bg:#1a1a18;--fg:#eceae3;--mut:#a3a199;--line:#3a3a36;--cell:#222220;
--collect:#7db4f0;--send:#6fd09a;--opps:#f0b060;--sources:#c3a1f0;--built:#a3a199}}
*{box-sizing:border-box}body{margin:0;padding:24px;background:var(--bg);color:var(--fg);
font:15px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:980px;margin:0 auto}h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:0 0 8px}
p{margin:0 0 12px}.mut{color:var(--mut)}
.legend{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:8px 20px;margin:16px 0 24px;padding:0;list-style:none}
.legend li{display:flex;gap:10px;align-items:baseline}
.chip{display:inline-block;font-size:11px;font-weight:600;line-height:1;padding:4px 6px;border-radius:4px;
border:1.5px solid var(--c);background:var(--c);color:var(--bg);white-space:nowrap}
.collect{--c:var(--collect)}.send{--c:var(--send)}.opps{--c:var(--opps)}.sources{--c:var(--sources)}
.opps-built{--c:var(--opps)}.sources-built{--c:var(--sources)}
.opps-built,.sources-built{background:transparent;color:var(--c);border-style:dashed}
.months{display:grid;grid-template-columns:repeat(auto-fit,minmax(440px,1fr));gap:28px}
table{width:100%;border-collapse:collapse;table-layout:fixed}
th{font-size:12px;font-weight:600;color:var(--mut);padding:4px 0;text-align:left}
td{height:68px;vertical-align:top;border:1px solid var(--line);padding:4px;background:var(--cell)}
td.out{background:transparent;border-color:transparent}td.today{outline:2px solid var(--fg);outline-offset:-2px}
.n{display:block;font-size:12px;color:var(--mut);margin-bottom:3px}td .chip{margin:0 2px 2px 0}
.next{margin-top:28px}.next td,.next th{height:auto;padding:6px 8px;border:0;border-bottom:1px solid var(--line);background:transparent;font-size:14px}
@media(max-width:520px){body{padding:12px}.months{grid-template-columns:1fr}td{height:60px}.chip{font-size:10px;padding:2px 4px}}
@media print{body{padding:0}.months{grid-template-columns:1fr 1fr}}
"""


def render(settings, p, today):
    city, lab = settings["City"], labels(p["auto"])
    e = html.escape
    cad = "every two weeks" if p["biweekly"] else "every week"
    out = ["<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\">",
           "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">",
           f"<title>{e(city)} newsletter calendar</title><style>{CSS}</style></head><body><main>",
           f"<h1>{e(settings.get('Chapter name') or city)}: when everything runs</h1>",
           f"<p class=\"mut\">Sends {cad} on {e(settings['Send day'])}. Made {fmt(today)} {today.year}. "
           "If you change your send day, ask Claude to \"show my calendar\" for a new one.</p>",
           "<ul class=\"legend\">"]
    for kind in ("collect", "send", "opps", "sources"):
        short, long = lab[kind]
        extra = ""
        if kind == "collect" and p["auto"]:
            extra = f" ({RUN_TIME}, your computer on with Claude open)" if p["needs_computer"] else f" ({RUN_TIME})"
        out.append(f"<li><span class=\"chip {kind}\">{short}</span><span>{e(long)}{extra}</span></li>")
    out.append("<li><span class=\"chip opps-built\">Opps</span> <span class=\"chip sources-built\">Sources</span>"
               "<span>Dashed outline: the day that list was last built</span></li>")
    out.append("</ul><div class=\"months\">")
    cal = calendar.Calendar(firstweekday=0)
    y, m = today.year, today.month
    while (y, m) <= (p["last"].year, p["last"].month):
        out.append(f"<section><h2>{calendar.month_name[m]} {y}</h2><table><thead><tr>"
                   + "".join(f"<th>{d[:3]}</th>" for d in DAYS) + "</tr></thead><tbody>")
        for week in cal.monthdatescalendar(y, m):
            out.append("<tr>")
            for d in week:
                if d.month != m:
                    out.append("<td class=\"out\"></td>"); continue
                kinds = p["marks"].get(d, []) if d <= p["last"] else []
                chips = "".join(f"<span class=\"chip {k}\" title=\"{e(lab[k][1])}\">{lab[k][0]}</span>" for k in kinds)
                cls = " class=\"today\"" if d == today else ""
                out.append(f"<td{cls}><span class=\"n\">{d.day}{' today' if d == today else ''}</span>{chips}</td>")
            out.append("</tr>")
        out.append("</tbody></table></section>")
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    out.append("</div><section class=\"next\"><h2>The same dates as a list</h2><table><tbody>")
    for d in sorted(k for k in p["marks"] if today <= k <= p["last"]):
        what = "; ".join(lab[k][1] for k in p["marks"][d])
        out.append(f"<tr><th scope=\"row\">{fmt(d)}</th><td>{e(what)}</td></tr>")
    out.append("</tbody></table></section>")
    out.append("<p class=\"mut\" style=\"margin-top:20px\">Opportunities refresh in the first weekly run more than "
               f"{cl.OPPS_DUE_DAYS} days after the last one, and the source list check comes up in the first run more than "
               f"{cl.SOURCES_DUE_DAYS} days after the list was built. Both happen inside the normal weekly run, never as a "
               "separate task. If a run is late, these move with it.</p></main></body></html>")
    return "\n".join(out)


def summary(settings, p):
    who = "Claude collects events" if p["auto"] else "You start the run"
    lines = [f"CALENDAR for {settings['City']} ({'every two weeks' if p['biweekly'] else 'weekly'}, "
             f"send day {settings['Send day']})"]
    for s in p["sends"][:4]:
        lines.append(f"  {who} {fmt(s - timedelta(days=1))}  ->  send {fmt(s)}")
    lines.append("  Opportunities refresh: " + (", ".join(fmt(d) for d in p["opp_days"][:3]) or "none in this period"))
    lines.append("  Source list check: " + (", ".join(fmt(d) for d in p["src_days"][:2]) or "none in this period"))
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("settings"); ap.add_argument("log"); ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--today"); ap.add_argument("--first-send")
    ap.add_argument("--schedule", choices=["yes", "no"])
    a = ap.parse_args()
    today = date.fromisoformat(a.today) if a.today else date.today()
    settings, log = read_settings(a.settings), cl.load(a.log)
    p = plan(settings, log, today,
             date.fromisoformat(a.first_send) if a.first_send else None, a.schedule)
    open(a.out, "w", encoding="utf-8").write(render(settings, p, today))
    print(summary(settings, p))
    print(f"wrote {a.out}")


if __name__ == "__main__":
    main()
