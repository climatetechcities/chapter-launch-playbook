#!/usr/bin/env python3
"""
review.py -- the one weekly review: the lead decides the cut and the picks by
replying to a numbered list, instead of editing a spreadsheet.

  python3 review.py render events.json --send-date YYYY-MM-DD [--cadence biweekly]
      Sorts the harvested rows, numbers them (the number is written back into
      events.json as "No", so it never shifts), and prints the list to show the
      lead. Before running it, put Claude's proposal on each row:
          "Proposed":   "keep" or "cut"      (default keep)
          "Cut Reason": one short plain reason, required on every proposed cut
          "Pick":       true on the four to six proposed picks

  python3 review.py apply events.json -o events_final.json
        [--cut 3,7] [--keep 12] [--picks 1,4,9 | --add-picks 6 --drop-picks 4]
      Applies the lead's reply on top of the proposal and writes the rows that
      go in the issue. With no flags the proposal stands as it is, which is
      what "looks good" means. --picks replaces the whole pick list.

  python3 review.py from-sheet edited.xlsx events.json -o events_final.json
      For a lead who asked for the spreadsheet instead: reads the sheet they
      edited, keeps the rows still in it, and reads their PICK marks. Prints
      EDITED or UNCUT so an untouched sheet is never mistaken for a cut one.

Nothing here decides anything. The proposal is Claude's, the decision is the
lead's, and this script only keeps the numbering and the bookkeeping exact.
"""
import argparse
import json
import sys
from datetime import date, timedelta

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def day_header(d):
    return f"{DAYS[d.weekday()]}, {MONTHS[d.month - 1]} {d.day}"


def short(d):
    return f"{MONTHS[d.month - 1]} {d.day}"


def windows(send, cadence):
    week = 14 if cadence == "biweekly" else 7
    this_end = send + timedelta(days=week - 1)
    up_end = send + timedelta(days=(42 if week == 14 else 28) - 1)
    return this_end, up_end


def load_rows(path):
    data = json.load(open(path, encoding="utf-8"))
    return data["events"] if isinstance(data, dict) else data, data


def save_rows(path, rows, original):
    if isinstance(original, dict):
        original["events"] = rows
        out = original
    else:
        out = rows
    json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)


def parse_date(s):
    try:
        return date.fromisoformat(str(s).strip()[:10])
    except ValueError:
        return None


def is_cut(r):
    return str(r.get("Proposed", "keep")).strip().lower() == "cut"


def is_pick(r):
    return r.get("Pick") is True or str(r.get("Pick", "")).strip().lower() in ("true", "yes", "pick")


def line(r, show_date=False):
    name = (r.get("Event Name") or "(no name)").replace("[", "(").replace("]", ")")
    link = (r.get("Registration Link") or "").strip()
    title = f"[{name}]({link})" if link else f"{name} (no link)"
    bits = [b for b in (r.get("Host Organization(s)"), r.get("City / Neighborhood"),
                        r.get("Event Type"), r.get("Access")) if str(b or "").strip()]
    tag = ""
    src = str(r.get("Source", "")).strip().lower()
    if src == "submitted":
        tag = " · sent in by a reader"
    elif src == "lead":
        tag = " · added by you"
    body = " · ".join([title] + [str(b).strip() for b in bits]) + tag
    d = parse_date(r.get("Date"))
    if show_date and d:
        body = f"{short(d)} · {body}"
    n = r["No"]
    if is_cut(r):
        return f"{n}. ✂ {body}. **Proposed cut:** {r.get('Cut Reason') or 'NO REASON GIVEN'}"
    return f"{n}. {'⭐ ' if is_pick(r) else ''}{body}"


def cmd_render(a):
    rows, original = load_rows(a.events)
    send = date.fromisoformat(a.send_date)
    this_end, up_end = windows(send, a.cadence)
    problems = []
    for r in rows:
        d = parse_date(r.get("Date"))
        r["_d"] = d
        if d is None:
            problems.append(f"{r.get('Event Name')}: no usable Date; it cannot be placed")
            continue
        want = "this_week" if send <= d <= this_end else "upcoming" if this_end < d <= up_end else "out"
        got = str(r.get("Block", "")).strip()
        if want == "out":
            problems.append(f"{r.get('Event Name')} ({r.get('Date')}): outside both windows; "
                            f"cut it, or correct the date")
        elif got != want:
            problems.append(f"{r.get('Event Name')} ({r.get('Date')}): Block says '{got}' but the "
                            f"date puts it in {want}. Fix Block before showing the list")
        if is_cut(r) and not str(r.get("Cut Reason", "")).strip():
            problems.append(f"{r.get('Event Name')}: proposed cut with no Cut Reason")
        if is_cut(r) and is_pick(r):
            problems.append(f"{r.get('Event Name')}: proposed as both a cut and a pick")
    order = {"this_week": 0, "upcoming": 1}
    rows.sort(key=lambda r: (order.get(str(r.get("Block", "")).strip(), 2),
                             r["_d"] or date.max, str(r.get("Start Time", "")),
                             str(r.get("Event Name", "")).lower()))
    for i, r in enumerate(rows, start=1):
        r["No"] = i
    out = []
    for block, label, lo, hi in (("this_week", "This week", send, this_end),
                                 ("upcoming", "Upcoming", this_end + timedelta(days=1), up_end)):
        brows = [r for r in rows if str(r.get("Block", "")).strip() == block]
        kept = sum(1 for r in brows if not is_cut(r))
        out.append(f"**{label}, {short(lo)} to {short(hi)}: {len(brows)} found, keeping {kept}**")
        out.append("")
        if not brows:
            out.append("Nothing found for this stretch.")
            out.append("")
        current = None
        for r in brows:
            if block == "this_week" and r["_d"] != current:
                current = r["_d"]
                out += ["", f"**{day_header(current) if current else 'No date'}**", ""]
            out.append(line(r, show_date=(block == "upcoming")))
        out.append("")
    other = [r for r in rows if str(r.get("Block", "")).strip() not in order]
    if other:
        out.append("**Not placed (fix before showing the list)**")
        out += [line(r) for r in other] + [""]
    for r in rows:
        r.pop("_d", None)
    save_rows(a.events, rows, original)
    picks = [r for r in rows if is_pick(r) and not is_cut(r)]
    cuts = [r for r in rows if is_cut(r)]
    import re as _re
    print(_re.sub(r"\n{3,}", "\n\n", "\n".join(out)))
    print(f"⭐ marks the {len(picks)} proposed pick(s). ✂ marks the {len(cuts)} proposed cut(s), "
          f"each with its reason.")
    notes = list(problems)
    if not 4 <= len(picks) <= 6 and len([r for r in rows if not is_cut(r)]) >= 6:
        notes.append(f"{len(picks)} picks proposed; the house range is four to six, roughly one "
                     f"per day that has events")
    lost = [r for r in cuts if str(r.get("Source", "")).strip().lower() in ("submitted", "lead")]
    for r in lost:
        notes.append(f"proposing to cut a reader-submitted or lead-added row: {r.get('Event Name')}. "
                     f"Say so plainly in the message; that decision is the lead's")
    if notes:
        print("\nFIX OR SAY BEFORE SENDING THE LIST (not for the lead to read as is):", file=sys.stderr)
        for n in notes:
            print("  ! " + n, file=sys.stderr)


def nums(s):
    if not s:
        return []
    out = []
    for part in str(s).replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            lo, hi = part.split("-", 1)
            out += list(range(int(lo), int(hi) + 1))
        else:
            out.append(int(part))
    return out


def finish(kept, cut, out_path, verdict=None):
    json.dump(kept, open(out_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    tw = [r for r in kept if str(r.get("Block", "")).strip() == "this_week"]
    up = [r for r in kept if str(r.get("Block", "")).strip() == "upcoming"]
    picks = [r for r in kept if is_pick(r)]
    if verdict:
        print(verdict)
    print(f"wrote {out_path}: {len(tw)} this week, {len(up)} upcoming, {len(cut)} cut")
    print(f"picks ({len(picks)}): " + ("; ".join(f"{r.get('Date')} {r.get('Event Name')}" for r in picks) or "none"))
    if not picks:
        print("  ! no picks. Ask the lead for four to six before building.")
    elif not 4 <= len(picks) <= 6 and len(tw) >= 6:
        print(f"  ! {len(picks)} picks; the house range is four to six. Build what the lead chose and say so once.")
    for r in cut:
        if str(r.get("Source", "")).strip().lower() == "submitted":
            print(f"  ! cut a reader-submitted event: {r.get('Event Name')}. Worth a reply to whoever sent it.")
    need = [r for r in kept if str(r.get("Block", "")).strip() == "this_week"
            and not str(r.get("Description", "")).strip()]
    for r in need:
        print(f"  ! this-week row with no Description: {r.get('Event Name')}. Write it before building.")
    unchecked = [r for r in kept if not isinstance(r.get("page_checks"), dict)]
    for r in unchecked:
        print(f"  ! no page check on record: {r.get('Event Name')}. Open its page before building.")


def cmd_apply(a):
    rows, _ = load_rows(a.events)
    if any("No" not in r for r in rows):
        sys.exit("events.json has rows with no number. Run `review.py render` first, "
                 "and apply the lead's reply to the same file.")
    by_no = {int(r["No"]): r for r in rows}
    for label, lst in (("--cut", nums(a.cut)), ("--keep", nums(a.keep)), ("--picks", nums(a.picks)),
                       ("--add-picks", nums(a.add_picks)), ("--drop-picks", nums(a.drop_picks))):
        bad = [n for n in lst if n not in by_no]
        if bad:
            sys.exit(f"{label}: no row numbered {bad}. Numbers run 1 to {len(rows)}.")
    both = set(nums(a.cut)) & set(nums(a.keep))
    if both:
        sys.exit(f"rows {sorted(both)} are in both --cut and --keep")
    if a.picks and (a.add_picks or a.drop_picks):
        sys.exit("use --picks (replace the list) or --add-picks/--drop-picks (adjust it), not both")
    explicit_cut = set(nums(a.cut))
    explicit_pick = set(nums(a.picks)) | set(nums(a.add_picks))
    clash = explicit_cut & explicit_pick
    if clash:
        sys.exit(f"rows {sorted(clash)} are both cut and picked in the same reply. Ask the lead which they meant.")
    for n in sorted(explicit_cut):
        r = by_no[n]
        if is_pick(r):
            print(f"  note: row {n} ({r.get('Event Name')}) was a proposed pick and is now cut, so it is no longer a pick")
        r["Proposed"], r["Pick"] = "cut", False
        if not str(r.get("Cut Reason", "")).strip():
            r["Cut Reason"] = "cut by the lead"
    for n in nums(a.keep):
        by_no[n]["Proposed"] = "keep"
    if a.picks:
        chosen = set(nums(a.picks))
        for n, r in by_no.items():
            r["Pick"] = n in chosen
    for n in nums(a.add_picks):
        by_no[n]["Pick"] = True
    for n in nums(a.drop_picks):
        by_no[n]["Pick"] = False
    for n in sorted(explicit_pick):
        r = by_no[n]
        if is_cut(r):
            print(f"  note: row {n} ({r.get('Event Name')}) was a proposed cut; the lead picked it, so it is kept")
            r["Proposed"] = "keep"
    for r in rows:
        if is_cut(r):
            r["Pick"] = False
    kept = [dict(r, Pick=is_pick(r)) for r in rows if not is_cut(r)]
    cut = [r for r in rows if is_cut(r)]
    for r in kept:
        r.pop("Proposed", None)
        r.pop("Cut Reason", None)
    finish(kept, cut, a.out)


def _cell_text(v):
    """A spreadsheet cell as the text the harvest would have written."""
    import datetime as _dt
    if v is None:
        return ""
    if isinstance(v, _dt.datetime):
        return v.date().isoformat() if (v.hour, v.minute, v.second) == (0, 0, 0) else v.strftime("%Y-%m-%d %H:%M")
    if isinstance(v, _dt.date):
        return v.isoformat()
    if isinstance(v, _dt.time):
        return v.strftime("%H:%M")
    return str(v).strip()


def cmd_from_sheet(a):
    import openpyxl
    rows, _ = load_rows(a.events)
    ws = openpyxl.load_workbook(a.sheet).active
    headers = [str(c.value or "").strip() for c in ws[1]]
    norm = [h.split(" (")[0] if h.startswith(("Start Time", "End Time")) else h for h in headers]
    if "Event Name" not in norm or "Registration Link" not in norm:
        sys.exit("this does not look like the events sheet (no Event Name or Registration Link column)")
    known = set(norm) & {"Event Name", "Date", "Start Time", "End Time", "Registration Link",
                         "Event Type", "Access", "Location", "City / Neighborhood", "Format",
                         "Host Organization(s)", "Description", "Categories", "Block", "Source"}

    def key(link, d):
        return (str(link or "").strip().rstrip("/").lower(), str(d or "").strip()[:10])
    by_key = {key(r.get("Registration Link"), r.get("Date")): r for r in rows}
    kept, added, pick_marks = [], [], 0
    for raw in ws.iter_rows(min_row=2, values_only=True):
        cells = [_cell_text(v) for v in raw]
        if not any(cells):
            continue
        rec = dict(zip(norm, cells))
        if not rec.get("Event Name"):
            continue
        picked = any(c.strip().upper() == "PICK" for c in cells)
        pick_marks += picked
        base = by_key.get(key(rec.get("Registration Link"), rec.get("Date")))
        row = dict(base) if base else {"Source": "lead"}
        for h in known:
            if rec.get(h, "") != "" or h in ("End Time",):
                row[h] = rec.get(h, "")
        row["Pick"] = picked
        row.pop("Proposed", None)
        row.pop("Cut Reason", None)
        kept.append(row)
        if not base:
            added.append(row)
    kept_keys = {key(r.get("Registration Link"), r.get("Date")) for r in kept}
    cut = [r for r in rows if key(r.get("Registration Link"), r.get("Date")) not in kept_keys]
    if not cut and not pick_marks and not added:
        verdict = ("UNCUT: this sheet has every harvested row and no PICK marks. It looks like the "
                   "file as it was handed over. Ask the lead whether they meant to send the edited one.")
    else:
        verdict = (f"EDITED: {len(cut)} row(s) removed, {pick_marks} PICK mark(s), "
                   f"{len(added)} row(s) the lead added.")
    finish(kept, cut, a.out, verdict)
    for r in added:
        print(f"  ! added by the lead, not harvested: {r.get('Event Name')}. Open its page and fill "
              f"the row the way the harvest would.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("render"); p.add_argument("events"); p.add_argument("--send-date", required=True)
    p.add_argument("--cadence", default="weekly", choices=["weekly", "biweekly"]); p.set_defaults(fn=cmd_render)
    p = sub.add_parser("apply"); p.add_argument("events"); p.add_argument("-o", "--out", required=True)
    p.add_argument("--cut"); p.add_argument("--keep"); p.add_argument("--picks")
    p.add_argument("--add-picks"); p.add_argument("--drop-picks"); p.set_defaults(fn=cmd_apply)
    p = sub.add_parser("from-sheet"); p.add_argument("sheet"); p.add_argument("events")
    p.add_argument("-o", "--out", required=True); p.set_defaults(fn=cmd_from_sheet)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
