# First run: a new chapter

Read this only when Step 0 finds no settings file or no source list. A normal week never needs it.

*Paths here are relative to this skill's own folder (`$SKILL`), the same as in SKILL.md.*

A new chapter needs three things before its first harvest: settings, a source list, and an opportunities list. Get them in one sitting with one stop. Skip any step whose file already exists.

1. **Settings.** Run `ctc-chapter-setup`. It asks its eight questions in one message and saves the settings file.
2. **One message for everything else:**

   > Two things to build before your first issue: your source list, which is every place events get announced in your city, and your opportunities list, which is the grants and programs the newsletter features. Paste any event calendars you already check and any grants or programs you already know, or say "go" and I will research both.
   >
   > **Your writing (optional, and worth doing).** Paste three to five things you have written that sound like you: past newsletter notes, LinkedIn posts, emails to a group, anything in your normal voice. I will learn how you write and draft the personal parts of each issue to match, so you edit instead of starting over. Short is fine.
   >
   > Three quick questions, asked once:
   > 1. How should I read Luma and Eventbrite each week? **A, through your browser**: the most complete read; it needs the Claude in Chrome extension or the Claude desktop app. **B, without your browser**: for accounts where browser access is switched off; I read Luma from its calendar feeds and Eventbrite and other sites as plain pages. A few sites that load their events by script, or refuse automated reads, will not come through, and I tell you each week which ones.
   > 2. OK for me to read your LinkedIn feed once a month for programs people in your network are posting about? (This one needs your browser, so skip it if you chose B.)
   > 3. Want this to start by itself each week? I will set it up so the events are collected the day before your send day and you get a notification with the list ready to review. You never have to remember to start it.

   Record all three answers in the log (for the first, A is `set browser yes` and B is `set browser no`; a lead who chose B is not asked the second, and no LinkedIn answer is recorded for them; for the third, record `schedule yes` only once the task exists; see step 6). Whatever they pasted is the answer to the opening question of `ctc-source-map` and `ctc-opportunities`; do not ask either again.

   **If they sent writing samples**, build their voice file now, as `../ctc-assemble/references/personal-voice.md` sets out: write `CTC_Voice_<City>.md`, check it, save it to the project, record `voice yes`. If they sent none, record `voice no`, carry on, and do not ask again; mention once, when the first issue is delivered, that they can say "learn my writing style" at any time.
3. **Run `ctc-source-map`, then `ctc-opportunities`,** each through its own verifier. Do not stop between them. The opportunities list is saved to the project as soon as its checks pass. **The source list is not saved yet**: the lead reads it first.
4. **One stop.** Build the chapter's calendar: `python3 $SKILL/scripts/schedule_calendar.py <settings> <log> -o CTC_Calendar_<City>.html --today <today> --schedule <their answer to question 3>` (add `--first-send <date>` if they said the first issue goes out a later week). Hand over both spreadsheets and the calendar, give the source list summary, and wait:

   > Your source list has [N] sources across [M] categories, plus the Climate Tech Cities submission form, and your opportunities list has [K] open. Both spreadsheets are attached. Read the source list before I save it. You live there and the research does not, so tell me what to add and what to drop: the meetup everyone goes to that is not here, a calendar that looks dead to you. If it looks right, say so and I will collect this week's events.
   >
   > The calendar attached shows when everything runs from here: the day I collect events each week, your send day, and the weeks the opportunities and the source list come up for a refresh. Next up: [the first two lines the script printed].

5. **On their reply,** apply what they said to the source list the way `ctc-source-map` sets out ("Show it, then save it"): verify anything they add, drop what they drop, rebuild, then save it to the project and set the log's date. Only then go to the weekly run. Tell them once that a first issue should look small: New York's launch issue carried three events and a long personal note about why the newsletter existed. That is the correct shape for week one.
6. **After the first issue is built,** if they said yes to the schedule, create it now, as `references/scheduling.md` sets out, and tell them when it will run. Creating it after the first issue means a scheduled run is never also a first run.

Never run a harvest without a source list. It returns almost nothing and the lead concludes the tool is broken.

