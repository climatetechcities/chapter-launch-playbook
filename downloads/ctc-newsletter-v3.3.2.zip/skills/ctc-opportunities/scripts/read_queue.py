#!/usr/bin/env python3
"""
read_queue.py -- the weekly read of the opportunities queue.

  python3 read_queue.py CTC_Opportunities_<City>.md --send-date YYYY-MM-DD \
      [--log CTC_Chapter_Log_<City>.md] [--city <City>] [-o open.json]

The queue file is built once a month, so anything in it about "how soon" is
stale by the second issue. This script works it out fresh, against the send
date of the issue being built:

  * drops every entry whose deadline falls before the send date, and says how
    many, so a lapsed deadline can never be offered or printed
  * works out "closes in" from the send date
  * reads the chapter log for when each entry last ran, so the lead is not
    asked to remember
  * proposes three for this issue: first what closes within three weeks and
    did not run last issue, then what has never run (most local first), then
    whatever ran longest ago

It prints the numbered list to show the lead and writes the same entries, with
their numbers, to open.json. Each entry there carries `deadline_date` (an ISO
date, "Rolling" or "Unconfirmed") and `deadline_text` (the line that prints),
ready to copy into issue.json. The lead picks; this only
proposes. Also accepts an older Opportunities_<City>.xlsx.
"""
import argparse
import json
import os
import re
import sys
from datetime import date

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                "..", "..", "ctc-newsletter-cycle", "scripts"))
import chapter_files as cf  # noqa: E402

MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August",
          "September", "October", "November", "December"]
SOON_DAYS = 21
PROPOSE = 3


def scope_rank(scope, city):
    v = str(scope or "").strip().lower()
    if not v:
        return 2
    if city and city.strip().lower() in v:
        return 0
    if v.startswith(("local", "city", "metro")):
        return 0
    if v.startswith(("regional", "state", "province")):
        return 1
    if v.startswith(("national", "federal", "countrywide")):
        return 2
    if v.startswith(("global", "international", "worldwide")):
        return 3
    return 1


def kind(deadline):
    d = str(deadline or "").strip().lower()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", d):
        return "date"
    if d.startswith("rolling"):
        return "rolling"
    return "unconfirmed"


def norm_url(u):
    return re.sub(r"^https?://(www\.)?", "", str(u or "").strip().lower()).rstrip("/")


def norm_name(n):
    return re.sub(r"[^a-z0-9]+", " ", str(n or "").lower()).strip()


def long_date(d):
    return f"{MONTHS[d.month - 1]} {d.day}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("queue")
    ap.add_argument("--send-date", required=True)
    ap.add_argument("--log")
    ap.add_argument("--city", help="the chapter's city; used when the list itself does not name one")
    ap.add_argument("-o", "--out", default="open.json")
    a = ap.parse_args()

    send = date.fromisoformat(a.send_date)
    q = cf.load_queue(a.queue)
    city = q.get("city") or a.city or ""

    ran = {}  # key -> sorted list of send dates
    last_issue = ""
    if a.log and os.path.exists(a.log):
        text = open(a.log, encoding="utf-8").read()
        secs = cf.parse_sections(text)
        for r in secs.get("Opportunities run", []):
            d = r.get("Send date", "")
            if not d or d >= a.send_date:
                continue  # a rebuild of this same issue is not history
            for key in (norm_url(r.get("URL")), "name:" + norm_name(r.get("Opportunity"))):
                if key and key != "name:":
                    ran.setdefault(key, []).append(d)
        earlier = sorted(r.get("Send date", "") for r in secs.get("Issues", [])
                         if r.get("Send date", "") and r.get("Send date", "") < a.send_date)
        last_issue = earlier[-1] if earlier else ""

    open_rows, lapsed = [], []
    for e in q["open"]:
        k = kind(e.get("deadline"))
        if k == "date" and date.fromisoformat(e["deadline"]) < send:
            lapsed.append(e)
            continue
        e = dict(e)
        e["deadline_kind"] = k
        if k == "date":
            dl = date.fromisoformat(e["deadline"])
            e["deadline_date"] = e["deadline"]
            e["closes_in_days"] = (dl - send).days
            e["deadline_text"] = f"Applications due {long_date(dl)}."
        elif k == "rolling":
            e["deadline_date"] = "Rolling"
            e["closes_in_days"] = None
            e["deadline_text"] = "Rolling applications"
        else:
            e["deadline_date"] = "Unconfirmed"
            e["closes_in_days"] = None
            e["deadline_text"] = ""
        dates = sorted(set(ran.get(norm_url(e.get("url")), []) + ran.get("name:" + norm_name(e.get("name")), [])))
        e["ran_on"] = dates
        e["last_ran"] = dates[-1] if dates else ""
        e["scope_rank"] = scope_rank(e.get("scope"), city)
        open_rows.append(e)

    def soon_key(e):
        return (e["closes_in_days"], e["scope_rank"])

    def fresh_key(e):
        return (e["scope_rank"], e["closes_in_days"] if e["closes_in_days"] is not None else 10 ** 6)

    proposed = []
    soon = sorted([e for e in open_rows
                   if e["closes_in_days"] is not None and e["closes_in_days"] <= SOON_DAYS
                   and not (last_issue and e["last_ran"] == last_issue)],
                  key=soon_key)
    for e in soon[:2]:
        proposed.append(e)
    for e in sorted([e for e in open_rows if not e["ran_on"] and e not in proposed], key=fresh_key):
        if len(proposed) >= PROPOSE:
            break
        proposed.append(e)
    for e in sorted([e for e in open_rows if e["ran_on"] and e not in proposed],
                    key=lambda e: (e["last_ran"], e["scope_rank"])):
        if len(proposed) >= PROPOSE:
            break
        proposed.append(e)

    for i, e in enumerate(open_rows, start=1):
        e["No"] = i
        e["proposed"] = any(e is p for p in proposed)
    json.dump({"city": city, "send_date": a.send_date, "open": open_rows},
              open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    print(f"**Opportunities: {len(open_rows)} open**")
    print()
    for e in open_rows:
        if e["deadline_kind"] == "date":
            n = e["closes_in_days"]
            when = f"closes {long_date(date.fromisoformat(e['deadline']))} ({'today' if n == 0 else str(n) + (' day' if n == 1 else ' days')})"
        elif e["deadline_kind"] == "rolling":
            when = "rolling"
        else:
            when = "deadline unconfirmed"
        hist = f"last ran {e['last_ran']}" + (f", {len(e['ran_on'])} times" if len(e["ran_on"]) > 1 else "") \
            if e["ran_on"] else "not run yet"
        name = str(e.get("name", "")).replace("[", "(").replace("]", ")")
        bits = [f"[{name}]({e.get('url', '')})", e.get("type", ""), e.get("scope", ""), when, hist]
        print(f"{e['No']}. {'⭐ ' if e['proposed'] else ''}" + " · ".join(b for b in bits if str(b).strip()))
    print()
    print(f"⭐ marks the {len(proposed)} proposed for this issue.")
    if lapsed:
        print(f"{len(lapsed)} dropped because the deadline passed before {a.send_date}: "
              + "; ".join(str(e.get("name")) for e in lapsed))
    built = q.get("built", "")
    if built:
        age = (send - date.fromisoformat(built)).days
        if age > 30:
            print(f"\nQUEUE IS {age} DAYS OLD (built {built}). The monthly refresh is due: "
                  f"run ctc-opportunities.", file=sys.stderr)
    if not open_rows:
        print("\nNOTHING OPEN. The block is omitted from this issue; the monthly refresh is due.",
              file=sys.stderr)
    unconf = [e for e in open_rows if e["deadline_kind"] == "unconfirmed" and e["proposed"]]
    for e in unconf:
        print(f"\nnote: {e.get('name')} is proposed with an unconfirmed deadline; it prints with no "
              f"deadline line.", file=sys.stderr)
    print(f"wrote {a.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
