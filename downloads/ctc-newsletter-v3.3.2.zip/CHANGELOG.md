# Changelog

## 3.3.2 (2026-11-22): Eventbrite organizers read directly; Luma dates read twice

- **Correction to 3.3.1.** It said Eventbrite organizer pages do not list events to a plain fetch. That rested on two organizers that had nothing scheduled. An organizer with events (tested) lists all of them, with names, links, days and times. The organizer page is the reader again, organizers are `auto` when they list dated events, and the search ladder is reduced to one check on an organizer page that lists nothing and does not say why.
- **Luma feed dates are read twice.** The fetch returns a reading of the feed, not the feed, so each kept event's start and end are confirmed by a second, narrower read before the row is written.
- The A/B question and the README no longer say Eventbrite comes through only partly.

## 3.3.1 (2026-11-22): the readers for collecting without the browser, rebuilt after a first run

The first whole run without the browser (Chicago) reported Luma calendars and an Eventbrite organizer as holding no events, could not press a "Load more" button, and was refused by two sites. A plain fetch does not run a page's scripts, and 3.3.0 read calendar pages that way. `ctc-harvest/references/no-browser.md` is rewritten:

- **Luma is read from each calendar's own feed**, not its page. The calendar's id is in the page's app tag; the feed holds every event with start and end times, location, host and description. No connector is needed. Tested on two calendars, one of them a Chicago calendar the run had reported as empty: the feed returned its 150 events, none upcoming, so it really was empty and can now be told apart from unread.
- **Eventbrite organizer pages do not list events to a plain fetch** (tested on two). They now go through a ladder: the organizer page, Eventbrite's own city listing search, a web search, then every event page opened and kept only if its organizer is the registered one. Such a source is reported as partly read.
- **Web pages that load events by script or "Load more"** go through a feed ladder: a feed link on the page, the site's standard feed address, a second page by address, a list view.
- **Four results per source**: read, empty, partial, unread. An empty-looking page is never reported as an empty source. A blocked site is unread, and no other way in is tried.
- **The source list remembers what worked**, as `feed:` and `reader:` notes, so later weeks go straight there. The source list build records them, marks Eventbrite organizers `manual` for a chapter collecting this way, and tells the lead how many sources read fully, partly, or not at all before they approve it.
- The A/B question, the README and the fallback notes now describe option B accurately, including that Eventbrite organizers come through only partly.
- **Not tested:** the Eventbrite ladder finding a registered organizer's real event; the feed ladder on a live "Load more" page; a whole run with these readers; a scheduled run in this mode.

## 3.3.0 (2026-11-22): collect with or without the browser

Some leads are on accounts where an organization has switched off browser access. Until now the plugin treated that as a broken harvest and stopped. It is now a standing choice.

- **One choice, made once.** At setup, or the first time an existing chapter runs with no answer on file, the lead chooses how Luma and Eventbrite are read: A, through their browser, or B, without it. The answer is the chapter log's existing browser row (`Yes` / `No`), so no chapter file changes shape and chapters with an answer on file are not asked again. One sentence changes it later.
- **New: `ctc-harvest/references/no-browser.md`.** The readers for collecting without the browser: Luma calendar pages by plain fetch for names and slugs, the Luma connector for every event's dates and details, Eventbrite event pages by plain fetch, the Airtable connector for the submission form. Read only in that mode.
- **Same rows, same rules.** Every row still comes from the event's own record, `page_checks` is still filled, and a row with no date is never written. What cannot be read is named in the review, by source.
- **Scheduled runs follow the choice.** `No`: the run collects without the browser and does not need the lead's computer. `Yes` with no browser reachable: the run now collects without it that once and says so, instead of not collecting. `Not asked`: one short message, no collection.
- **`chapter_log.py status`** prints one `collect` line saying which way the chapter collects.
- **The calendar** (`schedule_calendar.py`) no longer says the lead's computer must be on for collection days when the chapter collects without the browser.
- Also touched: the source list and its verifier (how to verify Luma and Eventbrite candidates without the browser), the assemble link re-check, the opportunities LinkedIn tier (skipped without asking when the chapter does not use the browser), the launch plan's install line, and the README.
- **A chapter whose log said `No`** was previously offered three fallback options every week. It now simply collects without the browser.
- **Tested live, 22 Nov 2026, one page or record each:** every reader in `no-browser.md`; its last section lists them. **Not tested:** a whole run without the browser, a scheduled run without the browser, an Eventbrite organizer listing with upcoming events by plain fetch, and an account whose organization also restricts connectors.

## 3.2.5 (2026-11-20): a calendar of when everything runs

- New: `ctc-newsletter-cycle/scripts/schedule_calendar.py` builds `CTC_Calendar_<City>.html` from the chapter's settings and log. Month grids with four colour-coded, labelled kinds of day: the weekly collection (day before the send day), the send day, the runs that refresh the opportunities, and the run that offers the source list refresh. A plain list of the same dates sits under the grids.
- Handed over at setup with the two spreadsheets, on request ("show my calendar"), and again when the send day or cadence changes.
- The dates use the same 30-day and 90-day rules as the chapter log, so the calendar and the weekly run cannot disagree. With a weekly send, the opportunities refresh lands every fifth week and the source list check in week 14.
- No change to any other output. A normal week reads about 70 more words of instruction.

## 3.2.4 (2026-11-20): less reading in a normal week

- Sections a normal week never uses now live in their own files and are read only when they apply: `ctc-newsletter-cycle/references/first-run.md` (new chapter setup), the "Scheduled runs" behaviour (now in `references/scheduling.md`), and the broken-platform and no-browser fallbacks (`ctc-harvest/references/platform-fallbacks.md`). The schedule file and the sample review message are no longer read every week.
- Nothing was rewritten or removed: the text moved word for word, checked by script against 3.2.3 (every instruction line still exists; the only changed lines are the pointers to the new files).
- A normal week's instruction reading drops from about 30,100 to about 26,600 words (12%).

## 3.2.3 (2026-11-20): one scheduled run a week

- Removed the six-tries schedule from 3.2.1. The weekly task runs once, the day before the send day, early afternoon in the chapter's timezone.
- If it misses because the computer is off or Claude is closed, the run leaves one short message and the lead starts it themselves: "Run now" on the task in Claude's Scheduled section, or "run the newsletter" in the chapter's project.
- Kept: a run that finds this week already handled (started by hand, or "Run now" pressed twice) stops silently, so a manual run never produces a duplicate review.
- Chapters with a 3.2.1 task: say "update my newsletter schedule" in the chapter's project and Claude changes it to the single weekly time.

## 3.2.2 (2026-11-20): official playbook address

- The launch plan and the setup skill now link to the official playbook, `https://climatetechcities.github.io/chapter-launch-playbook/`. The earlier personal address is gone from the plugin.
- No other change. The two Airtable forms were moved into the Climate Tech Cities Airtable account on 19 Nov; their links did not change, so nothing in the plugin needed updating.

## 3.2.1 (2026-11-19): the schedule retries

- A scheduled task cannot wait for a computer to come back on, so the weekly task now tries six times: morning, early afternoon and evening on the day before the send day and on the send day. The first try that finds the lead's computer on does the work. Every other try sees the week is already handled and stops silently.
- A try that cannot reach the computer stays quiet; only the last try of the send day tells the lead the week could not be collected.
- A chapter on every two weeks uses the same schedule and stops silently in its off weeks, from the chapter log.
- Not tested live.

## 3.2.0 (2026-11-18): the run that starts itself, spreadsheets back, source list approved first

- **Weekly schedule, created by Claude.** At a chapter's first run the lead is asked once whether the newsletter should start by itself. On a yes, Claude creates one scheduled task on their account (after the first issue is built) that runs the day before the send day: it refreshes the opportunities when due, collects the events, and sends the review message with the spreadsheet, then waits for the lead. The lead never builds an automation by hand. `ctc-newsletter-cycle/references/scheduling.md` is the procedure; the cycle skill's new "Scheduled runs" section says how an unattended run behaves.
  - The collection reads Luma and Eventbrite through a browser on the lead's computer, so the computer has to be on with Claude open when the task fires. If it is not, the run does not collect and says so in one short message instead of producing a list with no dates.
  - A scheduled run asks nothing, never does a first run, never builds an issue, and stops if this week's issue already exists.
- **Spreadsheets are a default output again.** The source list, the opportunities and each week's events are handed to the lead as `.xlsx` files as well as kept as text in the project. The weekly events spreadsheet is attached to the review message, and a lead can still mark it up and send it back instead of replying with numbers. `chapter_log.py set spreadsheets no` turns them off for a lead who does not want them.
- **The lead approves the source list before it is saved.** 3.0.0 saved it to the project and then asked the lead to read it. It is now shown first (spreadsheet plus summary), the lead says what to add and drop, and only then is it saved. No harvest runs before that.
- New log entries: `schedule`, `spreadsheets`.
- **Not tested live:** creating a scheduled task on a volunteer's account, and a scheduled run end to end. Whether a scheduled run can reach the chapter's project files and the lead's browser is the first thing to confirm.

## 3.1.0 (2026-11-17): drafts in the lead's own voice

- **New, optional and recommended:** at a chapter's first run the lead is asked for three to five samples of their own writing. Claude turns them into `CTC_Voice_<City>.md` (patterns and a few short excerpts, not the samples themselves), saves it to the project, and drafts the opening note, the picks and the housekeeping in that lead's voice from then on. A lead can also say "learn my writing style" at any time, send more samples, or paste an issue as they actually sent it to sharpen the file. `ctc-assemble/references/personal-voice.md` is the whole procedure.
- The house rules still win where they conflict: block shape and length, the banned list, and no invented facts. The voice file touches three blocks only; listings and event descriptions stay in the house voice.
- The yellow rewrite lines stay on all three blocks.
- A lead who shares nothing gets the house voice, exactly as in 3.0.0. A chapter that started earlier is asked once, in a review message.
- New: `chapter_files.py voice-check`; `chapter_log.py set voice yes|no`.
- Also in this build, from the final check of 3.0.0: a pick from Upcoming takes its lead-in from the page read at the link re-check; `build_registry.py` stops when the source list has no city; `read_queue.py --city`.
- **Not tested live.** The file check and log entry are tested; how well a draft matches a real lead's samples has not been.

## 3.0.0 (2026-11-16): one reply a week

The issue a chapter publishes is unchanged: the same ten blocks, house style, three lead-written blocks, and fixed links. What changed is how much the lead has to do to get there. A normal week was about eleven actions, most of them moving files and answering questions the toolkit could answer itself. It is now three: start the run, reply once to a review message, then rewrite the three marked blocks and send.

This release also rebuilds the fixes planned as 2.6.0, which was never installed.

### Claude keeps the chapter's files
- The settings, the source list, the opportunities list and a new chapter log are plain text files (`CTC_Settings_<City>.md`, `CTC_Source_List_<City>.md`, `CTC_Opportunities_<City>.md`, `CTC_Chapter_Log_<City>.md`) that Claude saves to the lead's project and reads from it. Nobody downloads, uploads or replaces a file. `ctc-newsletter-cycle/references/chapter-files.md` is the one statement of how, including what to do when a session cannot write to the project (hand the file over, as before).
- Spreadsheets are built on request by the same scripts (`--xlsx`).
- Older chapters keep working: `Chapter_Settings_<City>.docx`, `CTC_Source_Registry_<City>.xlsx` and `Opportunities_<City>.xlsx` are still read, and each is replaced by its text file the next time it is rebuilt.

### One review replaces the spreadsheet cut and the build's three questions
- After the harvest, Claude proposes a cut (each with a plain reason) and four to six picks, and sends one numbered list of events and one of opportunities. The lead replies once: "looks good", or "cut 7, keep 18, pick 5 instead of 2, opportunities 1 and 4". The decision is still the lead's; nothing is built on silence.
- New `review.py` numbers the rows so the numbers never shift, applies the reply, and still reads an edited spreadsheet for a lead who prefers one, reporting `EDITED` or `UNCUT` so an untouched sheet is never mistaken for a cut one (2.6.0 H2).
- The harvest no longer opens with a question. Events the lead knows about come in at the review.
- Standing answers (use my browser, read my LinkedIn feed) are asked once and kept in the chapter log. The opportunities and source-map skills no longer present an A/B/C menu on every run.

### The chapter log (2.6.0 H4)
- New `chapter_log.py`: when each list was last built, standing answers, one line per issue, and which opportunities ran in which issue. The weekly run reads it to say what is due, to compare this week's count with the chapter's normal, and to ask for last issue's numbers once.
- The opportunities refresh starts itself, before the harvest, when the list is a month old (2.6.0 H1); the source list refresh is offered at three months.
- New `read_queue.py`: each week it drops lapsed deadlines, works out "closes in" from the send date, shows when each entry last ran, and proposes three. The lead no longer keeps a tally.

### Dates and listings checked by script (2.6.0 H3)
- New `issue_checks.js`, run by both build scripts: a past event, a lapsed deadline, a day header or When line that does not match its date, a wrong day word on a pick, or a missing date stops the build. `issue.json` now carries `send_date` and an ISO date beside every printed one.
- New `draft_issue.py`: writes the three listing blocks straight from the kept rows, so no name, link or date is retyped, and checks the finished issue against those rows before every build (nothing cut comes back, nothing kept goes missing).
- The lead's pre-send checklist is down to what only they can do: rewrite, delete the yellow lines, read it once.

### Checks moved to where they catch more
- The full re-fetch of every link now runs in `ctc-assemble`, on the rows the lead kept, immediately before the build, instead of in the harvest on every row minutes after the sweep. Every published link is still fetched twice. The harvest verifier keeps scope, windows, duplicates, descriptions, submitted rows and the by-eye time check.
- Descriptions are written for this-week rows only, since upcoming rows print none. The carry-forward companion file is gone with them.

### Harvest
- `build_sheet.py`: `--tz` is required and takes the IANA zone; the header abbreviation is derived from the event dates (2.6.0 M2). `--check-only` runs every check without writing a spreadsheet.
- `plan_candidates.py --registered`: prints `PLATFORM READ LOOKS BROKEN` when a platform returns nothing from several registered sources or returns undated events; Step 3 adds a first-batch check; `platform-notes.md` documents the fallback (2.6.0 H5). The scrape dependency itself remains.

### Setup is in the plugin
- `ctc-chapter-setup` is now a sixth skill in this plugin, so installing the plugin is the whole install. A chapter's first run asks for calendars, programs and the two standing answers in one message, builds the source list and the opportunities list back to back, and stops once.
- The launch plan describes the new weekly steps and the files Claude keeps.

### Smaller fixes
- Every command uses `$SKILL/scripts/...` (2.6.0 M3).
- The phantom `relationship` column is gone from the source-map verifier; an email contact goes in `notes` (2.6.0 M4).
- The Word copy of the issue is built on request, not weekly (2.6.0 M6b).
- Staff names removed from `sources.md`.
- The bundled example had three events one day past the 28-day window; corrected in the example files and samples.

### Not changed
- The ten blocks, `voice.md`, `house-style.md`, the rewrite markers, the browser helpers (`harvest_helpers.js`, `decode_transport.py`, last verified live 1 Oct 2026), the no-invented-data rules, the opportunities block being mandatory, and the rule that no skill sends anything.
- Still open: the shared submissions view shows every chapter's rows (needs a view per city in Airtable); verifier weight is not scaled to issue size.

### Tested, and not
- Every script was run on the bundled example week end to end, including failure cases for each date check, a tampered issue, the spreadsheet route, a clock change, a stale list, and reading the older spreadsheets.
- **Not tested: a live harvest, and saving to a project on a second account.** The desktop app's built-in browser is offered as an alternative to the Chrome extension and has not been tested with the helpers.

## 2.5.1 (2026-10-01): skills locate their own files

Installed as a plugin, the five skills' scripts and reference files land under the account's synced-plugins folder, not in the session's working directory, so a relative path like `scripts/build_registry.py` found nothing and a run stopped with "files missing" even though every file was present. Each skill now opens with a "Find your files first" block: one `find` command that locates the skill's own folder inside the installed plugin, after which every `scripts/`, `references/` and `../ctc-<sibling>/` path resolves against it. If the search returns nothing the skill says so and stops rather than rebuilding a script by hand. No other change; tested against the installed 2.5.0 by running `build_registry.py` from the located folder.


## 2.5.0 (2026-10-01): faster research, same checks

The research stages (harvest, source map, opportunities) were slow because every event page was opened one at a time, read as rendered text, and then opened again by the verifier. This release changes how pages are read and in what order, not which checks run. Every rule from 2.4.1 is still in force (including asking before the browser is opened the first time in a session); several moved from prose to a field the build script reads.

### ctc-harvest
- **Phased sweep.** Enumerate every source first (candidates only), then plan which pages to open, then open them in batches, then write rows. Previously the sweep opened each source's events as it went, so duplicates were opened twice and out-of-window events were opened before their date was known.
- **`scripts/harvest_helpers.js`** (new): browser helpers injected once per tab. `__ENUM_LUMA` reads every registered Luma calendar from one tab (vanity slugs and `cal-...` ids); `__PULL_LUMA` reads ten Luma event payloads per call (UTC times with timezone, street address, hosts, ticket info, the full rich description, which 2.4.1 could not read). `__ENUM_EB` / `__PULL_EB` do the same for Eventbrite organizers and events from the page's `__NEXT_DATA__` and JSON-LD, which 2.4.1 had no structured path for. `__EXTRACT_CURRENT` and `__PULL_SAME_ORIGIN` read JSON-LD off any other page. Requests are paced inside the helpers. **Verified live in Chrome on 1 Oct 2026**: three Luma calendar forms, ten Luma events in 17 seconds, two Eventbrite organizer URL forms, one Eventbrite event; the transport came back byte-identical on all of it.
- **`scripts/decode_transport.py`** (new): decodes the helpers' output, keeping record order and refusing to drop a record it cannot parse. Record framing cannot collide with event text (an earlier draft split on `====`, which real descriptions contain).
- **`scripts/plan_candidates.py`** (new): windows and URL dedupe before any page is opened; flags same-day name overlaps for the venue check; never drops a candidate without a date or a submitted or lead row. Optional `--previous` takes last week's companion file (`CTC_Events_<City>_<date>.json`, now written next to the sheet) and marks rows harvested last week; prose is reused only when date, start time, location and the page's own description text all come back unchanged, and every such row is still re-fetched and re-checked.
- **`scripts/build_sheet.py`**: every row now carries `page_checks` (is this event, date matches, not passed, landed URL). A missing or failed check is a named warning. A Registration Link that differs from the page the extractor landed on is a warning.
- **Verifier**: every link is re-fetched and compared as data; pages are opened in the tab by eye for every mismatch, every submitted row, every off-platform row without structured data, every build warning, three Luma and three Eventbrite rows for the rendered local time (independent of the sweep's conversion), at least three carried rows, plus a random sample (at least five rows or fifteen percent). Can be split across subagents; browser work stays with one.
- **Parallel row writing** from `events_raw.json`, ten to fifteen events per subagent (no browser involved, so the batch limit does not apply), with voice.md section 6 in front of each.
- `platform-notes.md` rewritten around the helpers; Eventbrite section added.
- Two failure modes added: two agents in the browser; a half-empty batch.

### ctc-source-map
- Step 2 research runs as three parallel subagents (three categories each) returning candidates; the five gates still run centrally.
- Gate checks for Luma and Eventbrite candidates are batched through the harvest helpers from one tab; a calendar that comes back failed or with zero upcoming items is opened by eye before any gate ruling.
- Verifier re-fetches every row in batches and opens by eye the failed, manual, unverified and relationship rows plus three random auto rows.

### ctc-opportunities
- Tiers 1, 2 and 4 run as parallel subagents; Tier 3 (LinkedIn, the lead's signed-in browser) stays alone and consent-gated as before.
- Verifier re-fetches every URL (splittable across subagents) and uses the browser only where the fetch cannot settle the deadline.

### ctc-newsletter-cycle
- House rule added: one agent in the browser, many for everything else.
- Stage 1 mentions the harvest's companion file and the one optional lead-facing line about it (new lead-facing text; not a time estimate).

### Unchanged
- ctc-assemble, voice.md, house-style.md, the ten-block order, the cut, the three rewrite blocks, every quoted lead-facing prompt, the no-time-estimates rule.

### Verification notes
- Live testing found and fixed three things the sandbox could not: Luma serves its payload at two different depths depending on the calendar URL form; Luma's plain description field is empty and the real text is a rich-text tree; Eventbrite's organizer `showmore` endpoint is gone (403) and the organizer list lives in `__NEXT_DATA__`. The transport also now encodes non-breaking spaces, which the extension's page-text reader normalizes.

### Known trade-off
- A chapter with five sources and ten events gains little from batching and pays a small fixed cost (inject, decode, plan). Quality is unchanged there; the saving grows with the event count.
